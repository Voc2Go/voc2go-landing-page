# Contributing to VOC2GO Landing Page

Thank you for your interest in contributing to the VOC2GO Landing Page project! This document provides guidelines and instructions for contributing to the project's development and maintenance.

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [Getting Started](#getting-started)
3. [Development Workflow](#development-workflow)
4. [Coding Standards](#coding-standards)
5. [Pull Request Process](#pull-request-process)
6. [Project Structure](#project-structure)
7. [Internationalization](#internationalization)
8. [Testing](#testing)
9. [Documentation](#documentation)
10. [Issue Reporting](#issue-reporting)

## Code of Conduct

We expect all contributors to follow our Code of Conduct:

- Be respectful and inclusive
- Value differing viewpoints and experiences
- Accept constructive criticism
- Focus on what's best for the community
- Show empathy towards other community members

## Getting Started

### Prerequisites

Before you begin contributing, you'll need:

- Node.js (version 20.x or later)
- PostgreSQL (version 16.x or later)
- Git

### Setting Up Local Development

1. Fork the repository on GitHub
2. Clone your fork locally:
   ```bash
   git clone https://github.com/your-username/voc2go-landing.git
   cd voc2go-landing
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Set up environment variables by creating a `.env` file (see the [INSTALLATION.md](./INSTALLATION.md) for details)

5. Set up the database:
   ```bash
   npm run db:push
   ```

6. Start the development server:
   ```bash
   npm run dev
   ```

7. Create a new branch for your feature or bugfix:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## Development Workflow

We follow a feature branch workflow:

1. Create a branch from `main` for your work
2. Make your changes in small, logical commits
3. Push your branch to your fork
4. Submit a pull request to the main repository

### Commit Messages

Write clear, concise commit messages following these guidelines:

- Use the imperative mood ("Add feature" not "Added feature")
- First line should be 50 characters or less
- Reference issues or pull requests where appropriate
- Consider using conventional commits format:
  - `feat: add new feature`
  - `fix: resolve issue with X`
  - `docs: update documentation`
  - `style: format code (no functional changes)`
  - `refactor: restructure code without changing behavior`
  - `test: add or update tests`
  - `chore: update dependencies or config files`

## Coding Standards

### JavaScript/TypeScript

- Follow the ESLint configuration in the project
- Use TypeScript for all new code
- Add proper type definitions for all functions and variables
- Use async/await for asynchronous code

### React Components

- Use functional components with hooks
- Keep components small and focused on a single responsibility
- Use the Context API for state that needs to be shared across components
- Follow file naming conventions:
  - Components: `PascalCase.tsx`
  - Hooks: `use-kebab-case.ts`
  - Utilities: `kebab-case.ts`

### CSS/Styling

- Use Tailwind CSS for styling
- Follow responsive design principles
- Ensure accessibility standards are met

## Pull Request Process

1. Update the README.md or documentation with details of changes if appropriate
2. Make sure all tests pass and add new tests for your feature/fix
3. Ensure your code follows the coding standards
4. Request a review from at least one project maintainer
5. The PR will be merged once it receives approval

## Project Structure

Familiarize yourself with the project structure before contributing:

```
├── client/                  # Frontend code
│   ├── src/                 # Source files
│   │   ├── assets/          # Images and media files
│   │   ├── components/      # React components
│   │   ├── context/         # React context providers
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions
│   │   └── styles/          # CSS files
│
├── server/                  # Backend code
│   ├── middleware/          # Express middleware
│   ├── routes/              # API route definitions
│   ├── setup.js             # Setup script
│   └── storage.ts           # Storage interface
│
├── shared/                  # Shared code
│   └── schema.ts            # Database schema
│
├── docs/                    # Documentation
```

## Internationalization

This project supports both English and Hungarian languages:

### Adding New Translations

1. Locate the translations object in `client/src/context/LanguageContext.tsx`
2. Add your new text keys in both `en` and `hu` objects
3. Use the translation function in components: `{t("Your Text Key")}`

### Adding a New Language

To add support for a new language:

1. Extend the `Language` type in `LanguageContext.tsx`
2. Add a new language object in the translations
3. Update the language selector component in the header

## Testing

We encourage test-driven development:

### Running Tests

```bash
npm test
```

### Writing Tests

- Place test files next to the code they test with a `.test.ts` or `.test.tsx` extension
- Write unit tests for utilities and services
- Write component tests for React components
- Focus on testing behavior, not implementation details

## Documentation

Good documentation is crucial to our project:

### Code Documentation

- Add JSDoc comments to functions and components
- Document complex logic within functions
- Keep comments up-to-date when changing code

### Project Documentation

When making significant changes:

1. Update relevant documentation in the `docs/` directory
2. Add examples for new features
3. Update the README.md if necessary

## Issue Reporting

If you find a bug or have a feature request:

1. Check if the issue already exists in the GitHub issues
2. If not, create a new issue using the appropriate template
3. Provide as much context as possible:
   - For bugs: steps to reproduce, expected vs. actual behavior, screenshots, logs
   - For features: detailed description, use cases, and benefits

### Suggesting Enhancements

We welcome ideas for improvements:

1. Clearly describe the enhancement and its value
2. Provide examples of how it would be used
3. Indicate if you're willing to implement it yourself

## Becoming a Maintainer

Active contributors who demonstrate expertise and dedication may be invited to become project maintainers. This typically involves:

1. A history of quality contributions
2. Good communication skills
3. Helping other contributors
4. Understanding of the project goals and architecture

We appreciate your contributions to making the VOC2GO Landing Page better!