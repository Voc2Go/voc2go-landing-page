# VOC2GO Landing Page Documentation

Welcome to the documentation for the VOC2GO Landing Page project. This documentation provides comprehensive information about the project's functionality, technical implementation, and usage guidelines.

## Documentation Index

### General Information
- [README](./README.md) - General overview and introduction to the project
- [USER GUIDE](./USER_GUIDE.md) - Guide for non-technical users and site administrators

### Development and Technical Details
- [TECHNICAL](./TECHNICAL.md) - Detailed technical documentation for developers
- [DATABASE](./DATABASE.md) - Database structure, relationships, and management
- [API](./API.md) - API endpoints, authentication, and usage examples

### Setup and Deployment
- [INSTALLATION](./INSTALLATION.md) - Step-by-step installation instructions
- [DEPLOYMENT](./DEPLOYMENT.md) - Guide for deploying the application to production

### Project Maintenance
- [CONTRIBUTING](./CONTRIBUTING.md) - Guidelines for contributing to the project

## Quick Links

### For Site Administrators
If you're managing the VOC2GO landing page, start with:
1. [User Guide](./USER_GUIDE.md)
2. [Installation Guide](./INSTALLATION.md) (if setting up a new instance)

### For Developers
If you're developing or extending the VOC2GO landing page, start with:
1. [Technical Documentation](./TECHNICAL.md)
2. [API Documentation](./API.md)
3. [Contributing Guidelines](./CONTRIBUTING.md)

### For DevOps / System Administrators
If you're deploying or maintaining the infrastructure, start with:
1. [Installation Guide](./INSTALLATION.md)
2. [Deployment Guide](./DEPLOYMENT.md)
3. [Database Documentation](./DATABASE.md)

## Project Overview

The VOC2GO Landing Page is a bilingual (English/Hungarian) web application designed to promote the VOC2GO language learning app's Indiegogo campaign. The site provides an engaging and interactive experience for potential backers, showcasing the app's features, roadmap, and campaign rewards.

### Key Features

- **Bilingual Support**: Complete English and Hungarian language support
- **Responsive Design**: Mobile-first approach ensures compatibility across devices
- **Campaign Presentation**: Showcase of campaign rewards and tiers
- **User Engagement**: Newsletter subscription and feedback submission
- **Admin Interface**: Protected admin dashboard for content management