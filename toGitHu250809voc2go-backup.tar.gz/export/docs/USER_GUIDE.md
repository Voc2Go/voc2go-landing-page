# VOC2GO Landing Page User Guide

## Introduction

Welcome to the VOC2GO Landing Page! This guide will help you understand how to use and manage your bilingual landing page for the VOC2GO language learning app's Indiegogo campaign.

## Accessing The Website

The website can be accessed at your deployed URL. The landing page is designed to be viewed on any device, from mobile phones to desktop computers.

## Site Sections

### Home Page

The home page is the main entry point for visitors. It includes:

- **Hero Section**: Introduces VOC2GO with a headline, brief description, and a visual display of the app.
- **Features Section**: Highlights the key features of the VOC2GO app.
- **Plan Comparison**: Shows different plans available to users.

### Learners Section

This section targets language learners and showcases:

- **App Screenshots**: Visual examples of the app interface in different contexts.
- **Learning Features**: Detailed explanation of how the app helps with language learning.

### Supporters Section

This section is dedicated to the Indiegogo campaign:

- **Campaign Tiers**: Different support options with their respective rewards.
- **Campaign Goals**: Information about funding goals and what they will enable.

### Project Section

The Project section includes:

- **Roadmap**: Visual timeline showing the development stages of the app.
- **Development Updates**: Information about current progress and upcoming milestones.

### Contact Section

The Contact section provides:

- **Feedback Form**: A form for visitors to submit questions or feedback.
- **Contact Information**: Ways to get in touch with the VOC2GO team.

## Language Toggle

The website is fully bilingual, supporting both English and Hungarian:

1. Look for the language selector in the top-right corner of the header.
2. Click on "EN" for English or "HU" for Hungarian.
3. The entire site content will instantly switch to your selected language.

## Admin Access

As an administrator, you have access to the admin panel:

### Accessing Admin Panel

1. Scroll to the bottom of the page to the footer section.
2. Click on the hidden admin link (small gear icon in the footer).
3. You'll be prompted to log in with your admin credentials.

### Admin Dashboard

Once logged in, you can:

#### Manage Content

- **Settings**: Update site-wide settings like site name, description, and colors.
- **Media**: Upload and manage images used throughout the site.

#### Manage Campaign

- **View Campaigns**: See all current campaign information.
- **Edit Campaign Details**: Update campaign descriptions, goals, and status.
- **Manage Rewards**: Edit campaign reward tiers and benefits.

#### Manage Subscribers

- **View Subscribers**: See all newsletter subscribers.
- **Export Data**: Download subscriber information for use in email campaigns.

#### Manage Feedback

- **View Feedback**: Access all feedback submissions from users.
- **Respond to Messages**: Mark messages as read/responded.

### Logging Out

To log out of the admin panel:

1. Click on the "Logout" button in the admin dashboard.
2. You'll be returned to the main site as a regular visitor.

## Collecting User Data

The website collects two main types of user data:

### Newsletter Subscriptions

Visitors can subscribe to your newsletter:

1. They enter their email (and optionally their name) in the newsletter form.
2. They select their preferred language (English or Hungarian).
3. Their information is stored in the database.
4. You can export this data for email marketing campaigns.

### Feedback Submissions

Visitors can provide feedback:

1. They fill out the feedback form with their name, email, and message.
2. Optionally, they can provide a numerical rating.
3. This feedback is stored in the database and can be reviewed in the admin panel.

## Campaign Management

### Updating Campaign Status

To update your campaign status:

1. Log in to the admin panel.
2. Navigate to the Campaign Management section.
3. Select the campaign you wish to update.
4. Change the status (draft, active, completed) as needed.
5. Save your changes.

### Adding New Campaign Tiers

To add new campaign reward tiers:

1. Log in to the admin panel.
2. Navigate to the Campaign Management section.
3. Select "Add New Tier" option.
4. Fill in the tier details (name, price, benefits, limitations).
5. Save the new tier to make it visible on the site.

## Customization Options

### Site Colors

To change the site colors:

1. Log in to the admin panel.
2. Navigate to the Settings section.
3. Find the color settings (primaryColor, primaryDarkColor, accentColor, ctaColor).
4. Enter new hex color codes.
5. Save changes to update the site appearance.

### Contact Information

To update contact information:

1. Log in to the admin panel.
2. Navigate to the Settings section.
3. Find the contactEmail setting.
4. Update with your current email address.
5. Save changes.

## Troubleshooting

### Language Toggle Not Working

If the language toggle isn't working:

1. Make sure your browser has JavaScript enabled.
2. Try clearing your browser cache.
3. Refresh the page and try again.

### Admin Login Issues

If you're having trouble logging in:

1. Ensure you're using the correct email and password.
2. If you've forgotten your password, contact your site administrator.
3. Check if your browser has cookies enabled (required for login).

### Content Not Updating

If content changes aren't appearing:

1. Make sure you saved your changes in the admin panel.
2. Try refreshing the page with a hard reload (Ctrl+F5 or Cmd+Shift+R).
3. Clear your browser cache and try again.

## Getting Support

If you encounter any issues not covered in this guide:

1. Check the technical documentation for more detailed information.
2. Contact your development team with specific details about the problem.
3. For urgent issues, email support at the contact address provided by your development team.

---

This user guide is designed to help you make the most of your VOC2GO Landing Page. For more technical details about implementation and customization, please refer to the technical documentation.