# VOC2GO Landing Page Documentation

## Overview

The VOC2GO Landing Page is a bilingual (English/Hungarian) web application designed to promote the VOC2GO language learning app's Indiegogo campaign. The site provides an engaging and interactive experience for potential backers, showcasing the app's features, roadmap, and campaign rewards.

## Table of Contents

1. [Project Architecture](#project-architecture)
2. [Technology Stack](#technology-stack)
3. [Key Features](#key-features)
4. [Database Schema](#database-schema)
5. [Frontend Components](#frontend-components)
6. [Language System](#language-system)
7. [Admin Interface](#admin-interface)
8. [API Endpoints](#api-endpoints)
9. [Deployment](#deployment)
10. [Getting Started](#getting-started)

## Project Architecture

The project follows a full-stack JavaScript/TypeScript architecture with a clear separation between frontend and backend:

- **Frontend**: React with TypeScript, responsible for UI rendering and user interactions
- **Backend**: Express.js server handling data persistence and API endpoints
- **Database**: PostgreSQL database for storing user data, settings, and campaign information
- **Shared**: Common TypeScript types and schemas used by both frontend and backend

The application follows modern web patterns with most of the business logic in the frontend, while the backend primarily handles data persistence and authentication.

## Technology Stack

### Frontend
- React (with TypeScript)
- TailwindCSS for styling
- React Router for navigation
- TanStack Query for data fetching
- React Hook Form for form handling
- Context API for state management

### Backend
- Express.js server
- PostgreSQL database
- Drizzle ORM for database operations
- JWT for authentication
- Multer for file uploads

### Development Tools
- Vite for bundling and development server
- TypeScript for type safety
- ESBuild for server-side code bundling

## Key Features

### Bilingual Support
- Complete English and Hungarian language support
- Dynamic language switching without page reload
- Translated content for all UI elements and pages

### Responsive Design
- Mobile-first approach ensures compatibility across devices
- Fluid layouts that adapt to various screen sizes
- Optimized media loading for different devices

### Campaign Presentation
- Showcase of campaign rewards and tiers
- Project roadmap visualization
- Interactive feature demonstrations

### User Engagement
- Newsletter subscription functionality
- Feedback submission form
- Social media integration

### Admin Interface
- Protected admin dashboard
- Content management capabilities
- User and subscription management

## Database Schema

The database is structured around the following main entities:

### Users
```
users
├── id (serial, primary key)
├── email (varchar, unique)
├── name (text)
├── password (text)
├── role (text: "USER" | "ADMIN")
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Settings
```
settings
├── id (serial, primary key)
├── key (varchar, unique)
├── value (text)
└── type (varchar)
```

### Media
```
media_items
├── id (serial, primary key)
├── name (varchar)
├── path (text)
├── type (varchar)
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Campaigns
```
campaigns
├── id (serial, primary key)
├── name (varchar)
├── description (text)
├── platform (varchar)
├── status (varchar: "draft" | "active" | "completed")
├── startDate (timestamp)
├── endDate (timestamp)
├── goal (real)
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Contacts
```
contacts
├── id (serial, primary key)
├── email (varchar, unique)
├── name (text)
├── source (varchar)
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Campaign Contacts
```
campaign_contacts
├── id (serial, primary key)
├── campaignId (serial, foreign key)
├── contactId (serial, foreign key)
├── status (varchar: "subscribed" | "unsubscribed" | "bounced")
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Subscribers
```
subscribers
├── id (serial, primary key)
├── email (varchar, unique)
├── name (text)
├── language (varchar)
├── isActive (boolean)
├── createdAt (timestamp)
└── updatedAt (timestamp)
```

### Feedback
```
feedbacks
├── id (serial, primary key)
├── name (text)
├── email (varchar)
├── message (text)
├── rating (real)
└── createdAt (timestamp)
```

## Frontend Components

### Core Components

#### App (App.tsx)
The main application component that handles routing and page structure. It manages the current page state and renders different sections based on navigation.

#### Header (Header.tsx)
Navigation component with responsive menu and language selector. Handles smooth scrolling to different sections of the page.

#### Footer (Footer.tsx)
Contains contact information, social media links, and admin access. Provides copyright information and additional links.

### Section Components

#### HeroSection
The landing area of the website featuring a prominent call-to-action, brief app description, and a phone mockup displaying the app interface.

#### FeaturesSection
Highlights key features of the VOC2GO application including AI-powered learning, real-life contexts, spaced repetition, and progress tracking.

#### AppScreenshotsSection
Showcases app screenshots in different contexts (café scene, library mode, cooking context) to give visitors a visual understanding of the app's interface.

#### CampaignSection
Presents the Indiegogo campaign tiers and rewards, with pricing and benefit information for each support level.

#### RoadmapSection
Visual timeline of the project development phases, showing completed, in-progress, and planned stages.

#### FeedbackSection
Form for users to submit feedback, questions, or comments about the VOC2GO app.

### Admin Components

#### AdminOverlay
Container component for the admin interface, which appears as an overlay on the main site.

#### AdminLogin
Authentication form for admin access with email and password fields.

#### AdminDashboard
Admin control panel with options for managing content, users, and campaign information.

## Language System

The application implements a comprehensive bilingual system through React's Context API:

### LanguageContext
Provides language switching and translation functionality throughout the application:

- Uses a `language` state (either 'en' or 'hu')
- Provides a `setLanguage` function to change the current language
- Includes a `t` translation function that retrieves the correct string based on the current language

### Translation Object
A structured key-value dictionary containing all text used in the application in both English and Hungarian languages. Organized by sections for easy maintenance.

### Implementation
Components consume the language context using the `useLanguage` hook:
```typescript
const { t, language, setLanguage } = useLanguage();
```

Text elements use the translation function:
```tsx
<h1>{t("Learn Languages on the Go")}</h1>
```

## Admin Interface

The admin interface provides site management capabilities for authorized administrators:

### Authentication
- JWT-based authentication system
- Secure password storage with bcrypt hashing
- Role-based access control (ADMIN vs USER roles)

### Features
- Content management for campaign details
- Subscriber and contact management
- Media uploads and management
- Settings configuration

### Implementation
The admin interface is implemented as an overlay on the main site, accessible through a hidden footer link. It uses the same bilingual system as the main site.

## API Endpoints

### Authentication
- `POST /api/login` - Authenticate user
- `POST /api/logout` - Log out current user

### Settings
- `GET /api/settings` - Retrieve all settings
- `PUT /api/settings` - Update settings (admin only)

### Media
- `GET /api/media` - List all media items
- `POST /api/media` - Upload new media (admin only)
- `DELETE /api/media/:id` - Delete media item (admin only)

### Campaigns
- `GET /api/campaigns` - List all campaigns
- `GET /api/campaigns/:id` - Get campaign details
- `POST /api/campaigns` - Create new campaign (admin only)
- `PUT /api/campaigns/:id` - Update campaign (admin only)
- `DELETE /api/campaigns/:id` - Delete campaign (admin only)

### Contacts
- `GET /api/contacts` - List all contacts (authenticated)
- `POST /api/contacts` - Create new contact
- `PUT /api/contacts/:id` - Update contact (admin only)
- `DELETE /api/contacts/:id` - Delete contact (admin only)

### Newsletter
- `POST /api/subscribe` - Subscribe to newsletter

### Feedback
- `POST /api/feedback` - Submit feedback

## Deployment

The application is configured for deployment on Replit:

### Configuration
- Automatic builds triggered by the Replit deployment system
- Environment variables for sensitive information
- PostgreSQL database setup

### Build Process
- Frontend: Vite builds optimized assets
- Backend: ESBuild bundles server code
- Combined deployment with static serving of frontend assets

## Getting Started

### Prerequisites
- Node.js 20 or later
- PostgreSQL database

### Initial Setup
1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables (see `.env.example`)
4. Initialize the database: `npm run db:push`
5. Create an admin user: `node server/setup.js`

### Development Workflow
1. Start the development server: `npm run dev`
2. Access the application at `http://localhost:5000`
3. Make changes to code (hot reloading enabled)
4. Test changes in the browser

### Admin Access
1. Click on the admin link in the footer
2. Log in with admin credentials created during setup
3. Access admin dashboard to manage content