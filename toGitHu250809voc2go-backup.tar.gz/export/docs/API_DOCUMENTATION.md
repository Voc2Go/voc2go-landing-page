# VOC2GO API Documentation

## Overview

The VOC2GO API provides endpoints for content management, user authentication, campaign data, and administrative functions. All endpoints follow RESTful conventions and return JSON responses.

## Base URL

```
Production: https://[your-replit-domain].replit.app/api
Development: http://localhost:5000/api
```

## Authentication

### Admin Authentication
Admin endpoints require authentication via session cookies. Login using the admin credentials to receive a session token.

### Headers
```
Content-Type: application/json
Cookie: session-token=<session-token>
```

## Admin Endpoints

### Authentication

#### POST /api/admin/login
Authenticate admin user and create session.

**Request Body:**
```json
{
  "loginName": "admin",
  "password": "admin123"
}
```

**Response (200):**
```json
{
  "success": true,
  "admin": {
    "id": 1,
    "loginName": "admin",
    "lastLogin": "2025-01-08T10:30:00.000Z"
  }
}
```

**Response (401):**
```json
{
  "error": "Invalid credentials"
}
```

#### GET /api/admin/me
Get current admin session information.

**Response (200):**
```json
{
  "admin": {
    "id": 1,
    "loginName": "admin",
    "lastLogin": "2025-01-08T10:30:00.000Z"
  }
}
```

**Response (401):**
```json
{
  "error": "Not authenticated"
}
```

#### POST /api/admin/logout
Terminate current admin session.

**Response (200):**
```json
{
  "success": true
}
```

#### POST /api/admin/update-credentials
Update admin login credentials.

**Request Body:**
```json
{
  "currentPassword": "admin123",
  "newLoginName": "new_admin",
  "newPassword": "new_password"
}
```

**Response (200):**
```json
{
  "success": true,
  "admin": {
    "id": 1,
    "loginName": "new_admin"
  }
}
```

### Content Management

#### GET /api/admin/content
List all content sections.

**Query Parameters:**
- `language` (optional): Filter by language (en/hu)

**Response (200):**
```json
{
  "sections": [
    {
      "id": 1,
      "sectionId": "hero-title",
      "title": "VOC2GO: Revolutionary AI Language Learning",
      "content": "Experience the next generation of language learning...",
      "language": "en",
      "lastModified": "2025-01-08T10:30:00.000Z",
      "modifiedBy": "admin"
    }
  ]
}
```

#### PUT /api/admin/content/:sectionId
Update specific content section.

**Request Body:**
```json
{
  "title": "Updated Title",
  "content": "Updated content text",
  "language": "en"
}
```

**Response (200):**
```json
{
  "section": {
    "id": 1,
    "sectionId": "hero-title",
    "title": "Updated Title",
    "content": "Updated content text",
    "language": "en",
    "lastModified": "2025-01-08T10:35:00.000Z",
    "modifiedBy": "admin"
  }
}
```

#### POST /api/admin/content
Create new content section.

**Request Body:**
```json
{
  "sectionId": "new-section",
  "title": "New Section Title",
  "content": "New section content",
  "language": "en"
}
```

**Response (201):**
```json
{
  "section": {
    "id": 15,
    "sectionId": "new-section",
    "title": "New Section Title",
    "content": "New section content",
    "language": "en",
    "lastModified": "2025-01-08T10:40:00.000Z",
    "modifiedBy": "admin"
  }
}
```

#### DELETE /api/admin/content/:sectionId
Delete content section.

**Query Parameters:**
- `language` (optional): Specify language to delete

**Response (200):**
```json
{
  "success": true
}
```

## Public Endpoints

### Newsletter Subscription

#### POST /api/subscribe
Subscribe to newsletter.

**Request Body:**
```json
{
  "email": "user@example.com",
  "name": "John Doe"
}
```

**Response (201):**
```json
{
  "success": true,
  "subscriber": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "subscribed": true,
    "createdAt": "2025-01-08T10:30:00.000Z"
  }
}
```

### Feedback Submission

#### POST /api/feedback
Submit user feedback.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "user@example.com",
  "message": "Great platform! Looking forward to using it.",
  "excitement": "very_excited"
}
```

**Response (201):**
```json
{
  "success": true,
  "feedback": {
    "id": 1,
    "name": "John Doe",
    "email": "user@example.com",
    "message": "Great platform! Looking forward to using it.",
    "excitement": "very_excited",
    "createdAt": "2025-01-08T10:30:00.000Z"
  }
}
```

### Campaign Information

#### GET /api/campaigns
Get all campaigns.

**Response (200):**
```json
{
  "campaigns": [
    {
      "id": 1,
      "name": "VOC2GO Indiegogo Campaign",
      "description": "Revolutionary AI-powered language learning platform",
      "goalAmount": 50000,
      "currentAmount": 12500,
      "status": "active",
      "startDate": "2025-01-01T00:00:00.000Z",
      "endDate": "2025-03-01T00:00:00.000Z"
    }
  ]
}
```

#### GET /api/campaigns/:id
Get specific campaign details.

**Response (200):**
```json
{
  "campaign": {
    "id": 1,
    "name": "VOC2GO Indiegogo Campaign",
    "description": "Revolutionary AI-powered language learning platform",
    "goalAmount": 50000,
    "currentAmount": 12500,
    "status": "active",
    "startDate": "2025-01-01T00:00:00.000Z",
    "endDate": "2025-03-01T00:00:00.000Z",
    "rewards": [
      {
        "id": 1,
        "title": "Early Bird Access",
        "price": 100,
        "description": "15 hours of premium learning",
        "available": true
      }
    ]
  }
}
```

### Contact Management

#### POST /api/contacts
Create new contact.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "user@example.com",
  "phone": "+1234567890",
  "message": "Interested in learning more about VOC2GO",
  "source": "website"
}
```

**Response (201):**
```json
{
  "contact": {
    "id": 1,
    "name": "John Doe",
    "email": "user@example.com",
    "phone": "+1234567890",
    "message": "Interested in learning more about VOC2GO",
    "source": "website",
    "createdAt": "2025-01-08T10:30:00.000Z"
  }
}
```

## Error Responses

### Standard Error Format
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": "Additional error details"
}
```

### Common Error Codes

#### 400 Bad Request
```json
{
  "error": "Invalid input data",
  "code": "VALIDATION_ERROR",
  "details": "Email is required"
}
```

#### 401 Unauthorized
```json
{
  "error": "Not authenticated",
  "code": "AUTH_ERROR"
}
```

#### 403 Forbidden
```json
{
  "error": "Access denied",
  "code": "ACCESS_DENIED"
}
```

#### 404 Not Found
```json
{
  "error": "Resource not found",
  "code": "NOT_FOUND"
}
```

#### 500 Internal Server Error
```json
{
  "error": "Internal server error",
  "code": "SERVER_ERROR"
}
```

## Rate Limiting

### Newsletter Subscription
- **Limit**: 5 requests per minute per IP
- **Window**: 1 minute
- **Response**: 429 Too Many Requests

### Feedback Submission
- **Limit**: 3 requests per minute per IP
- **Window**: 1 minute
- **Response**: 429 Too Many Requests

### Admin Endpoints
- **Limit**: 100 requests per minute per session
- **Window**: 1 minute
- **Response**: 429 Too Many Requests

## Data Validation

### Email Validation
- **Format**: Valid email address format
- **Length**: Maximum 255 characters
- **Required**: Yes for subscription and feedback

### Password Validation
- **Length**: Minimum 8 characters
- **Complexity**: Must contain letters and numbers
- **Special Characters**: Recommended but not required

### Content Validation
- **Title**: Maximum 200 characters
- **Content**: Maximum 5000 characters
- **Language**: Must be 'en' or 'hu'
- **Section ID**: Alphanumeric with hyphens allowed

## Content Section IDs

### Available Section IDs
- `hero` - Hero section
- `hero-title` - Hero title
- `hero-subtitle` - Hero subtitle
- `features` - Features section
- `features-main` - Main features
- `learners` - Learners section
- `learners-benefits` - Learner benefits
- `learners-testimonials` - Learner testimonials
- `vision` - Vision section
- `campaign` - Campaign section
- `support` - Support section
- `project-team` - Project team
- `team-title` - Team title
- `team-content` - Team content
- `roadmap` - Roadmap section
- `feedback` - Feedback section
- `contact-title` - Contact title
- `footer` - Footer section
- `footer-about` - Footer about
- `about-title` - About title
- `about-content` - About content
- `pricing-title` - Pricing title
- `pricing-content` - Pricing content
- `faq-title` - FAQ title
- `newsletter-title` - Newsletter title
- `testimonials-title` - Testimonials title

## SDK Examples

### JavaScript/Node.js
```javascript
// Admin login
const loginResponse = await fetch('/api/admin/login', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    loginName: 'admin',
    password: 'admin123'
  }),
  credentials: 'include'
});

// Update content
const updateResponse = await fetch('/api/admin/content/hero-title', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    title: 'Updated Title',
    content: 'Updated content',
    language: 'en'
  }),
  credentials: 'include'
});
```

### curl Examples
```bash
# Login
curl -X POST http://localhost:5000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"loginName":"admin","password":"admin123"}' \
  -c cookies.txt

# Update content
curl -X PUT http://localhost:5000/api/admin/content/hero-title \
  -H "Content-Type: application/json" \
  -d '{"title":"New Title","content":"New content","language":"en"}' \
  -b cookies.txt

# Subscribe to newsletter
curl -X POST http://localhost:5000/api/subscribe \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","name":"John Doe"}'
```

## Testing

### Admin Authentication Test
```bash
# Test login
curl -X POST http://localhost:5000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"loginName":"admin","password":"admin123"}' \
  -c test-cookies.txt

# Test session
curl -X GET http://localhost:5000/api/admin/me \
  -b test-cookies.txt
```

### Content Management Test
```bash
# Get all content
curl -X GET http://localhost:5000/api/admin/content \
  -b test-cookies.txt

# Update content
curl -X PUT http://localhost:5000/api/admin/content/hero-title \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Title","content":"Test content","language":"en"}' \
  -b test-cookies.txt
```

This API documentation provides comprehensive information for developers and administrators working with the VOC2GO platform API.