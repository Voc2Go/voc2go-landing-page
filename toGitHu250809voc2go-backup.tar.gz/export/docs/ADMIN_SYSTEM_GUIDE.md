# VOC2GO Admin System - Complete Guide

## Overview

The VOC2GO admin system provides comprehensive content management capabilities for the entire website. It features a secure, user-friendly interface for real-time content editing, credential management, and live preview functionality.

## Access and Authentication

### Default Credentials
- **Username**: `admin`
- **Password**: `admin123`

### Accessing the Admin Panel
1. **Footer Link**: Click the admin link in the website footer
2. **Direct URL**: Navigate to `/admin` on the website
3. **Testing Shortcut**: Press `Ctrl+A` for admin testing panel

### Security Features
- **Password Hashing**: Bcrypt with 10 salt rounds
- **Session Management**: Secure HTTP-only cookies
- **Configurable Credentials**: Username and password can be changed
- **Session Timeout**: Automatic logout after inactivity

## Admin Panel Interface

### Navigation Tabs
The admin panel consists of three main tabs:

#### 1. Content Management Tab
- **Purpose**: Edit all website content sections
- **Features**: Real-time editing with instant preview
- **Coverage**: 26 content sections across all menu areas

#### 2. Settings Tab
- **Purpose**: Manage admin credentials and system settings
- **Features**: Change username, password, and other configurations
- **Security**: Current password required for changes

#### 3. Live Preview Tab
- **Purpose**: Preview content changes before publishing
- **Features**: Desktop and mobile responsive preview modes
- **Real-time**: Updates immediately as content is modified

## Content Management System

### Available Content Sections

#### HOME Menu Sections
- **hero**: Main landing page hero section
- **hero-title**: Hero section title
- **hero-subtitle**: Hero section subtitle
- **features**: Platform features overview
- **features-main**: Main features content
- **learners**: Target audience section

#### LEARNERS Menu Sections
- **learners-benefits**: Benefits for language learners
- **learners-testimonials**: User testimonials and feedback

#### SUPPORTERS Menu Sections
- **vision**: Platform vision and mission
- **campaign**: Indiegogo campaign details
- **support**: Support plans and pricing
- **pricing-title**: Pricing section title
- **pricing-content**: Pricing details and options

#### PROJECT Menu Sections
- **project-team**: Team member profiles
- **team-title**: Team section title
- **team-content**: Team information
- **roadmap**: Development roadmap and timeline

#### CONTACT Menu Sections
- **feedback**: Contact form and feedback section
- **contact-title**: Contact section title
- **footer**: Footer information
- **footer-about**: Footer about content

#### Additional Sections
- **about-title**: About section title
- **about-content**: About section content
- **faq-title**: FAQ section title
- **newsletter-title**: Newsletter subscription
- **testimonials-title**: Testimonials section title

### Content Editing Features

#### Real-time Updates
- **Instant Preview**: Changes appear immediately in preview
- **Auto-save**: Content is saved automatically
- **Version Tracking**: Modifications tracked with timestamps
- **User Attribution**: Changes recorded with admin username

#### Content Structure
Each content section includes:
- **Section ID**: Unique identifier for the content area
- **Title**: Section title or heading
- **Content**: Main content text
- **Language**: English (en) or Hungarian (hu)
- **Last Modified**: Timestamp of last change
- **Modified By**: Username of the admin who made changes

#### Editing Interface
- **Rich Text Support**: Full text editing capabilities
- **Character Limits**: Appropriate limits for different content types
- **Validation**: Input validation to prevent errors
- **Preview Mode**: Live preview of changes

## Content Organization by Menu

### HOME Menu Content
Covers the main landing page sections that users first encounter:
- Hero section with main value proposition
- Features highlighting platform capabilities
- Learners section for target audience

### LEARNERS Menu Content
Focused on benefits and testimonials for language learners:
- Detailed benefits for different learner types
- User testimonials and success stories
- Learning methodology explanations

### SUPPORTERS Menu Content
Campaign-focused content for crowdfunding:
- Vision and mission statements
- Campaign details and reward tiers
- Support options and pricing plans

### PROJECT Menu Content
Team and development information:
- Team member profiles and expertise
- Development roadmap and milestones
- Project timeline and progress

### CONTACT Menu Content
Communication and feedback sections:
- Contact forms and feedback collection
- Footer information and legal links
- Newsletter subscription options

## Database Integration

### Content Sections Table
The admin system uses the `content_sections` table with the following structure:

```sql
CREATE TABLE content_sections (
  id SERIAL PRIMARY KEY,
  section_id VARCHAR(255) NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'en',
  modified_by VARCHAR(255),
  last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(section_id, language)
);
```

### Admin Settings Table
Admin credentials are stored in the `admin_settings` table:

```sql
CREATE TABLE admin_settings (
  id SERIAL PRIMARY KEY,
  login_name VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  session_token TEXT,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## API Endpoints

### Authentication Endpoints
- `POST /api/admin/login` - Admin login
- `GET /api/admin/me` - Get current admin session
- `POST /api/admin/logout` - Admin logout
- `POST /api/admin/update-credentials` - Update admin credentials

### Content Management Endpoints
- `GET /api/admin/content` - List all content sections
- `GET /api/admin/content?language=en` - Get content for specific language
- `PUT /api/admin/content/:sectionId` - Update specific content section
- `POST /api/admin/content` - Create new content section
- `DELETE /api/admin/content/:sectionId` - Delete content section

## Usage Examples

### Updating Hero Section Content
1. Log in to admin panel
2. Navigate to Content Management tab
3. Find "hero-title" section
4. Edit the title field
5. Content updates immediately on live site

### Changing Admin Credentials
1. Go to Settings tab
2. Enter current password
3. Provide new username and/or password
4. Save changes
5. Use new credentials for next login

### Previewing Changes
1. Make content changes in Content Management
2. Switch to Live Preview tab
3. Toggle between desktop and mobile views
4. Verify content appears correctly

## Security Considerations

### Access Control
- **Authentication Required**: All admin functions require login
- **Session Management**: Secure session tokens
- **Credential Validation**: Strong password requirements
- **CSRF Protection**: Request token validation

### Data Protection
- **Input Sanitization**: Content is sanitized before saving
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Output escaping
- **Secure Headers**: Security headers in responses

## Troubleshooting

### Common Issues

#### Login Problems
- **Incorrect Credentials**: Verify username/password
- **Session Expired**: Re-login required
- **Database Connection**: Check database status
- **Browser Cache**: Clear cookies and cache

#### Content Not Updating
- **Cache Issues**: Refresh browser cache
- **Database Sync**: Check database connection
- **JavaScript Errors**: Check browser console
- **Network Issues**: Verify API connectivity

#### Preview Not Working
- **JavaScript Disabled**: Enable JavaScript
- **Browser Compatibility**: Use modern browser
- **Network Latency**: Check connection speed
- **Server Response**: Verify API responses

### Debug Steps
1. **Check Browser Console**: Look for JavaScript errors
2. **Verify Network Tab**: Check API request/response
3. **Test Database**: Verify data is saved correctly
4. **Check Server Logs**: Review backend error logs

## Best Practices

### Content Management
- **Regular Backups**: Keep content backups
- **Version Control**: Track content changes
- **Testing**: Preview changes before publishing
- **Consistency**: Maintain consistent tone and style

### Security
- **Strong Passwords**: Use complex admin passwords
- **Regular Updates**: Change credentials periodically
- **Access Monitoring**: Monitor admin access logs
- **Secure Sessions**: Log out when finished

### Performance
- **Optimize Content**: Keep content concise
- **Image Optimization**: Compress images before upload
- **Cache Management**: Clear caches when needed
- **Database Maintenance**: Regular database optimization

## Advanced Features

### Bulk Operations
- **Multi-section Updates**: Update multiple sections at once
- **Language Switching**: Quick language change for all content
- **Export/Import**: Content backup and restore
- **Search Functionality**: Find specific content sections

### Customization
- **Theme Settings**: Customize admin panel appearance
- **User Preferences**: Save individual preferences
- **Workflow Optimization**: Streamline editing process
- **Integration Options**: Connect with external tools

This comprehensive guide covers all aspects of the VOC2GO admin system, providing administrators with the knowledge needed to effectively manage website content and maintain the platform.