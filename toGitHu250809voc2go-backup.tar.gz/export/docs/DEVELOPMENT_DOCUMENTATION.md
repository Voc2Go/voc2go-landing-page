# VOC2GO Landing Page - Complete Development Documentation

## Project Overview

VOC2GO is a comprehensive bilingual (English/Hungarian) language learning platform landing page designed to promote their Indiegogo crowdfunding campaign. The application features a modern React frontend with TypeScript, an Express.js backend, and PostgreSQL database integration using Drizzle ORM.

### Key Features
- **Bilingual Support**: Complete English/Hungarian language switching
- **Admin Content Management**: Real-time content editing with live preview
- **Campaign Management**: Crowdfunding campaign presentation and tracking
- **Newsletter Subscription**: Email collection for campaign updates
- **Feedback System**: User feedback collection and management
- **Media Management**: Image upload and storage system
- **Responsive Design**: Mobile-first approach with comprehensive breakpoint support

## Technical Architecture

### Frontend Stack
- **React 18** with TypeScript for type safety
- **Vite** for fast development and optimized builds
- **Tailwind CSS** with custom design tokens
- **Shadcn/UI** component library with Radix UI primitives
- **TanStack Query** for data fetching and caching
- **Wouter** for client-side routing
- **Framer Motion** for animations and transitions
- **React Hook Form** with Zod validation

### Backend Stack
- **Express.js** with TypeScript
- **Drizzle ORM** for type-safe database operations
- **PostgreSQL** (Neon serverless) for data persistence
- **JWT Authentication** for admin access
- **Bcrypt** for password hashing
- **Multer** for file uploads
- **CORS** enabled for cross-origin requests

### Database Schema
- **admin_settings**: Admin credentials and session management
- **content_sections**: Dynamic content management
- **users**: User authentication and profiles
- **subscribers**: Newsletter subscriptions
- **feedbacks**: User feedback collection
- **campaigns**: Campaign data and tracking
- **contacts**: Contact information management
- **media_items**: File upload and media management

## Project Structure

```
.
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Route-based page components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions and configurations
│   │   └── assets/         # Static assets (images, icons)
│   └── public/             # Public static files
├── server/                 # Backend Express application
│   ├── routes/             # API route handlers
│   ├── middleware/         # Express middleware
│   ├── db.ts              # Database connection and setup
│   ├── storage.ts         # Data access layer
│   └── index.ts           # Server entry point
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Drizzle schema definitions
├── docs/                   # Documentation
├── attached_assets/        # User-provided assets
└── uploads/               # File upload storage
```

## Core Components

### 1. Navigation System
- **Header**: Logo, language toggle, navigation menu
- **Mobile Menu**: Responsive hamburger menu for mobile devices
- **Language Toggle**: Instant English/Hungarian switching
- **Active Section Highlighting**: Visual feedback for current section

### 2. Content Sections

#### Home Menu
- **Hero Section**: Main value proposition with CTA buttons
- **Features Section**: Key platform benefits and capabilities
- **Learners Section**: Target audience information

#### Learners Menu
- **Benefits Section**: Detailed learner advantages
- **Testimonials**: User feedback and success stories

#### Supporters Menu
- **Vision Section**: Platform mission and market positioning
- **Campaign Section**: Indiegogo campaign details and rewards
- **Support Section**: Subscription plans and pricing

#### Project Menu
- **Team Section**: Founder and team member profiles
- **Roadmap Section**: Development timeline and milestones

#### Contact Menu
- **Feedback Form**: User input collection with validation
- **Footer**: Contact information and legal links

### 3. Admin System

#### Authentication
- **Configurable Credentials**: Default admin/admin123, fully changeable
- **Session Management**: Secure cookie-based authentication
- **Password Security**: Bcrypt hashing with salt rounds

#### Content Management
- **Real-time Editing**: Live content updates without page refresh
- **26 Content Sections**: Complete website coverage
- **Language Support**: Separate content for EN/HU
- **Version Tracking**: Modification history and user tracking

#### Admin Panel Features
- **Content Tab**: Edit all website sections
- **Settings Tab**: Update admin credentials
- **Preview Tab**: Live preview with responsive modes
- **Access Control**: Protected routes with middleware

## Development Workflow

### Environment Setup
1. **Database**: PostgreSQL via Replit's managed service
2. **Environment Variables**: AUTO_MANAGED via Replit
3. **Package Management**: npm with locked dependencies
4. **Build Process**: Vite for frontend, tsx for backend

### Development Commands
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run db:push      # Push schema changes to database
npm run db:studio    # Open database studio
```

### Code Quality
- **TypeScript**: Strict type checking across the stack
- **ESLint**: Code linting with React and TypeScript rules
- **Prettier**: Code formatting consistency
- **Zod**: Runtime type validation for API inputs

## Key Features Implementation

### 1. Bilingual Support
- **Context API**: Global language state management
- **Translation System**: Structured content organization
- **URL Persistence**: Language preference storage
- **Instant Switching**: No page reload required

### 2. Admin Content Management
- **Dynamic Content**: Database-driven content sections
- **Real-time Updates**: Live preview functionality
- **Security**: Authentication and session management
- **User-friendly Interface**: Intuitive editing experience

### 3. Campaign Integration
- **Pricing Model**: Pay-per-use hours ($100/15h, $200/30h, $500/75h)
- **Reward Tiers**: Structured campaign incentives
- **Progress Tracking**: Campaign metrics and analytics
- **Call-to-Action**: Strategic placement throughout site

### 4. Mobile Responsiveness
- **Breakpoints**: Mobile-first design approach
- **Touch Targets**: 44px minimum for accessibility
- **Performance**: Optimized for mobile networks
- **Testing Tools**: Built-in mobile testing panel (Ctrl+M)

## Security Implementation

### Authentication Security
- **Password Hashing**: Bcrypt with 10 salt rounds
- **Session Management**: Secure HTTP-only cookies
- **CSRF Protection**: Token-based request validation
- **Input Validation**: Zod schema validation

### Data Protection
- **SQL Injection**: Parameterized queries via Drizzle
- **XSS Prevention**: Input sanitization and escaping
- **CORS Configuration**: Controlled cross-origin access
- **Environment Variables**: Secure credential storage

## Performance Optimization

### Frontend Optimization
- **Code Splitting**: Route-based lazy loading
- **Image Optimization**: Responsive image handling
- **Caching**: TanStack Query for efficient data fetching
- **Bundle Analysis**: Optimized build output

### Backend Optimization
- **Database Indexing**: Optimized query performance
- **Connection Pooling**: Efficient database connections
- **Middleware Optimization**: Minimal request processing
- **Static Asset Serving**: Efficient file delivery

## Testing Strategy

### Development Testing
- **Mobile Testing Panel**: Ctrl+M for responsive testing
- **Admin Testing Panel**: Ctrl+A for admin functionality
- **API Testing**: Comprehensive endpoint validation
- **Database Testing**: Schema and query validation

### Quality Assurance
- **Cross-browser Testing**: Modern browser compatibility
- **Accessibility Testing**: WCAG compliance validation
- **Performance Testing**: Load time and responsiveness
- **Security Testing**: Vulnerability assessment

## Deployment Architecture

### Replit Deployment
- **Database**: Auto-managed PostgreSQL instance
- **Environment**: Automatic variable management
- **Build Process**: Integrated CI/CD pipeline
- **Static Files**: Optimized asset delivery

### Production Configuration
- **Environment Variables**: Secure credential management
- **Database Migrations**: Automated schema updates
- **Error Handling**: Comprehensive error logging
- **Monitoring**: Performance and error tracking

## API Documentation

### Authentication Endpoints
- `POST /api/admin/login` - Admin authentication
- `GET /api/admin/me` - Current admin session
- `POST /api/admin/logout` - Session termination
- `POST /api/admin/update-credentials` - Credential management

### Content Management Endpoints
- `GET /api/admin/content` - List all content sections
- `PUT /api/admin/content/:sectionId` - Update content section
- `POST /api/admin/content` - Create new content section
- `DELETE /api/admin/content/:sectionId` - Delete content section

### Public Endpoints
- `POST /api/subscribe` - Newsletter subscription
- `POST /api/feedback` - Feedback submission
- `GET /api/campaigns` - Campaign information
- `POST /api/contacts` - Contact form submission

## Maintenance and Updates

### Regular Maintenance
- **Database Backups**: Automated daily backups
- **Security Updates**: Regular dependency updates
- **Performance Monitoring**: Continuous optimization
- **Content Updates**: Admin-driven content management

### Update Procedures
- **Schema Changes**: Migration-based updates
- **Feature Additions**: Incremental development
- **Bug Fixes**: Rapid deployment pipeline
- **Security Patches**: Priority update process

## Troubleshooting Guide

### Common Issues
1. **Admin Login Issues**: Check database connection and password hash
2. **Content Not Updating**: Verify cache invalidation and database sync
3. **Language Switching**: Ensure context provider and state management
4. **Mobile Responsiveness**: Check Tailwind breakpoints and CSS

### Debug Tools
- **Browser DevTools**: Network, console, and element inspection
- **Database Studio**: Direct database access and queries
- **Server Logs**: Express middleware logging
- **Error Boundaries**: React error handling

## Future Enhancements

### Planned Features
- **Analytics Dashboard**: User engagement tracking
- **A/B Testing**: Campaign optimization tools
- **SEO Enhancement**: Advanced meta tag management
- **Performance Metrics**: Real-time monitoring dashboard

### Technical Improvements
- **Caching Strategy**: Redis implementation for performance
- **CDN Integration**: Global asset delivery
- **Microservices**: Service-oriented architecture
- **API Rate Limiting**: Enhanced security measures

## Changelog

### January 08, 2025 - Enhanced Admin System
- Implemented configurable admin login system
- Created comprehensive admin panel with Content, Settings, Preview tabs
- Added real-time content management with database-backed sections
- Built live preview functionality with responsive modes
- Enhanced security with session-based authentication and password hashing
- Updated hero section navigation to link to PROJECT menu
- Integrated admin routes with proper error handling and validation
- Database schema expanded with admin_settings and content_sections tables
- Default admin credentials: admin/admin123 (fully configurable)

### January 08, 2025 - Testing Infrastructure and Design Updates
- Added comprehensive mobile responsivity testing tools (Ctrl+M)
- Implemented admin functionality testing panel (Ctrl+A)
- Fixed project cards gradient colors to be darker and less pinky
- Updated contact email to voc2go@gmail.com in footer
- Created real-time breakpoint analysis and touch target validation
- Added development testing tools with visual summary widget
- Verified 44px minimum touch target requirements met
- Comprehensive mobile optimization across all breakpoints

### January 08, 2025 - Major SEO and Campaign Optimization Update
- Added comprehensive Open Graph and Twitter meta tags
- Implemented JSON-LD structured data for search engines
- Created Team Section with founder credentials and expertise
- Added Testimonials Section with beta tester feedback and stats
- Built FAQ Section addressing crowdfunding concerns
- Added Comparison Table showing VOC2GO vs competitors
- Integrated Countdown Timer for campaign urgency
- Enhanced hero section with stronger value proposition
- Optimized content with target keywords for SEO
- Added proper heading hierarchy and schema markup

This documentation provides a complete reference for the VOC2GO landing page development, covering all technical, architectural, and functional aspects of the project.