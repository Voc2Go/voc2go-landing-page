# VOC2GO Deployment Guide

This document provides detailed instructions for deploying the VOC2GO landing page application to production environments, with a special focus on Replit deployment.

## Deployment Options

The VOC2GO application can be deployed in several ways:

1. **Replit** - Cloud-based development and hosting platform (recommended)
2. **Traditional server** - Self-hosted on a VPS or dedicated server
3. **Docker containers** - Containerized deployment

This guide focuses primarily on Replit deployment, which is the recommended and simplest option.

## Deploying on Replit

Replit provides an integrated development and hosting environment, making it ideal for this application.

### Prerequisites

- A Replit account (sign up at [replit.com](https://replit.com))
- The VOC2GO codebase (either imported or created on Replit)

### Step 1: Configure Environment

Ensure your Replit has the following:

1. **PostgreSQL database** enabled in your Repl
2. Required environment variables set up in the Secrets panel

### Step 2: Set Required Secrets

In your Repl, navigate to the Secrets tab (lock icon) and add the following:

- `JWT_SECRET` - A secure random string for signing authentication tokens
- Any other sensitive configuration values not included in the codebase

The `DATABASE_URL` is automatically provided by Replit when PostgreSQL is enabled.

### Step 3: Run Database Migrations

Before deploying, ensure your database schema is up to date:

1. In the Replit shell, run:
   ```bash
   npm run db:push
   ```

2. This will create or update your database tables based on the schema in `shared/schema.ts`

### Step 4: Initialize Admin User (First Deployment Only)

If this is your first deployment, you'll need to create an admin user:

1. In the Replit shell, run:
   ```bash
   node server/setup.js
   ```

2. Follow the prompts to create your admin user credentials

### Step 5: Deploy the Application

Replit makes deployment straightforward:

1. Click the "Run" button in your Repl to start the application
2. Click the "Deploy" button to make your application publicly accessible
3. Replit will generate a public URL for your application

Your application will now be accessible via the Replit-provided URL.

### Step 6: Custom Domain Setup (Optional)

To use a custom domain with your Replit deployment:

1. In your Repl, go to the "Deploy" tab
2. Click "Settings" and choose "Custom domain"
3. Enter your domain name and follow the instructions to set up DNS records
4. Replit will automatically provision an SSL certificate for your domain

### Managing Deployments

Replit makes managing your deployment simple:

1. **Updates**: Make changes to your code and click "Run" to update the development version
2. **Redeploy**: After testing, click "Deploy" to update the production version
3. **Rollbacks**: In the "Deploy" tab, you can view deployment history and roll back if needed

## Performance Optimization

For optimal performance in production:

### 1. Enable Caching

Replit deployments include automatic edge caching. To optimize:

- Add appropriate Cache-Control headers for static assets
- Consider implementing client-side caching for API responses

### 2. Optimize Assets

- Ensure images are properly compressed
- Use the production build of React (automatically done in build process)
- Enable gzip compression (handled automatically by Replit)

### 3. Database Optimization

- Add indexes for frequently queried fields
- Optimize complex queries
- Consider connection pooling for high-traffic scenarios

## Monitoring and Maintenance

### Uptime Monitoring

- Use Replit's built-in uptime monitoring in the "Deploy" tab
- Consider additional external monitoring services for critical deployments

### Error Tracking

- Implement proper error logging in your application
- Review Replit logs regularly for issues

### Database Backups

- Regularly export database data for safekeeping
- Consider setting up scheduled backups via a Replit Cron job

## Security Best Practices

### 1. Keep Dependencies Updated

Regularly update npm packages to patch security vulnerabilities:

```bash
npm update
```

### 2. Secure Authentication

- Use HTTPS for all traffic (provided automatically by Replit)
- Set secure and HttpOnly flags on cookies
- Implement proper CORS policies

### 3. Input Validation

- Validate all user inputs both client-side and server-side
- Use parameterized queries to prevent SQL injection

### 4. Environment Variables

- Store sensitive information in Replit Secrets, not in code
- Use different values for development and production environments

## Continuous Deployment (Advanced)

For larger teams or more complex workflows, consider setting up continuous deployment:

1. Connect your Replit to a GitHub repository
2. Use GitHub Actions to run tests and linting
3. Configure Replit to automatically deploy on pushes to the main branch

## Troubleshooting Deployment Issues

### Application Won't Start

If your application fails to start after deployment:

1. Check Replit logs for error messages
2. Verify that all required environment variables are set
3. Ensure database migrations have been applied

### Database Connection Issues

If you're experiencing database problems:

1. Verify the `DATABASE_URL` environment variable is correctly set
2. Check if the database server is running
3. Ensure your application has proper credentials to access the database

### Performance Problems

If your application is running slowly:

1. Check server resource usage in the Replit dashboard
2. Look for slow queries in the database logs
3. Consider optimizing resource-intensive operations

## Post-Deployment Checklist

After deploying, verify:

- [ ] The application loads correctly at the deployed URL
- [ ] All features work as expected in the production environment
- [ ] Authentication and authorization are functioning correctly
- [ ] Forms submit data properly
- [ ] Admin interface is accessible and secure
- [ ] Bilingual content switches properly
- [ ] Mobile responsiveness works correctly

## Scaling Considerations

As your application grows:

1. **Horizontal Scaling**: Replit automatically scales your application based on traffic
2. **Database Scaling**: Consider upgrading to a larger database plan if needed
3. **CDN**: Use a CDN for static assets for global distribution

## Rollback Procedure

If a deployment introduces critical issues:

1. In the Replit "Deploy" tab, find your previous working deployment
2. Click "Rollback" to revert to that version
3. Investigate and fix the issues before attempting to redeploy

## Support and Resources

If you encounter issues with your Replit deployment:

- Replit documentation: [docs.replit.com](https://docs.replit.com)
- Replit support: Available through the Replit interface
- Community forum: [replit.com/talk](https://replit.com/talk)