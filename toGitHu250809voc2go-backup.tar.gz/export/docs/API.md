# VOC2GO API Documentation

This document provides detailed information about the VOC2GO application's API endpoints, their functionality, request/response formats, and authentication requirements.

## API Overview

The VOC2GO application exposes a RESTful API that enables:
- User authentication and authorization
- Content management
- Newsletter subscription
- Feedback submission
- Campaign and contact management

All API endpoints are prefixed with `/api`.

## Authentication

Most API endpoints require authentication. The application uses JWT (JSON Web Token) for authentication.

### Obtaining a Token

To obtain a JWT token, make a POST request to the login endpoint:

```
POST /api/login
```

Request body:
```json
{
  "email": "admin@example.com",
  "password": "********"
}
```

Response:
```json
{
  "message": "Logged in successfully",
  "user": {
    "id": 1,
    "email": "admin@example.com",
    "name": "Admin User",
    "role": "ADMIN"
  }
}
```

The token is set as an HTTP-only cookie named `token`.

### Using the Token

The token is automatically included in subsequent requests via the cookie. No additional headers are required.

### Logging Out

To invalidate the token, make a POST request to the logout endpoint:

```
POST /api/logout
```

This will clear the token cookie.

## Authorization

Some endpoints require specific roles to access. The application supports two roles:
- `USER`: Basic authenticated user
- `ADMIN`: User with administrative privileges

Endpoints that require admin privileges are noted in their descriptions.

## API Endpoints

### Authentication Endpoints

#### Login
```
POST /api/login
```
Authenticates a user and sets a JWT token cookie.

Request body:
```json
{
  "email": "string",
  "password": "string"
}
```

#### Logout
```
POST /api/logout
```
Clears the authentication token cookie.

### Settings Endpoints

#### Get All Settings
```
GET /api/settings
```
Retrieves all application settings.

Response:
```json
{
  "siteName": "VOC2GO",
  "siteDescription": "Learn languages word by word, story by story",
  "primaryColor": "#5C37C7",
  "primaryDarkColor": "#2D0051",
  "accentColor": "#44d1c6",
  "ctaColor": "#FF7518",
  "contactEmail": "hello@voc2go.com"
}
```

#### Update Settings
```
PUT /api/settings
```
Updates application settings. Requires admin privileges.

Request body:
```json
{
  "siteName": "VOC2GO Updated",
  "siteDescription": "New description"
}
```

Response:
```json
{
  "message": "Settings updated successfully"
}
```

### Media Endpoints

#### Get All Media
```
GET /api/media
```
Retrieves all media items.

Response:
```json
[
  {
    "id": 1,
    "name": "hero-image.jpg",
    "path": "/uploads/hero-image.jpg",
    "type": "image/jpeg",
    "createdAt": "2025-05-20T12:00:00Z",
    "updatedAt": "2025-05-20T12:00:00Z"
  }
]
```

#### Upload Media
```
POST /api/media
```
Uploads a new media file. Requires admin privileges.

Request body:
- Multipart form data with a file field named `file`

Response:
```json
{
  "id": 2,
  "name": "new-image.png",
  "path": "/uploads/new-image.png",
  "type": "image/png",
  "createdAt": "2025-05-22T12:00:00Z",
  "updatedAt": "2025-05-22T12:00:00Z"
}
```

#### Delete Media
```
DELETE /api/media/:id
```
Deletes a media item. Requires admin privileges.

Response:
```json
{
  "message": "Media deleted successfully"
}
```

### Campaign Endpoints

#### Get All Campaigns
```
GET /api/campaigns
```
Retrieves all campaigns. Requires authentication.

Response:
```json
[
  {
    "id": 1,
    "name": "Indiegogo Launch",
    "description": "Our first crowdfunding campaign",
    "platform": "indiegogo",
    "status": "active",
    "startDate": "2025-06-01T00:00:00Z",
    "endDate": "2025-07-01T00:00:00Z",
    "goal": 10000,
    "createdAt": "2025-05-20T12:00:00Z",
    "updatedAt": "2025-05-20T12:00:00Z"
  }
]
```

#### Get Campaign Details
```
GET /api/campaigns/:id
```
Retrieves details for a specific campaign, including associated contacts. Requires authentication.

Response:
```json
{
  "id": 1,
  "name": "Indiegogo Launch",
  "description": "Our first crowdfunding campaign",
  "platform": "indiegogo",
  "status": "active",
  "startDate": "2025-06-01T00:00:00Z",
  "endDate": "2025-07-01T00:00:00Z",
  "goal": 10000,
  "createdAt": "2025-05-20T12:00:00Z",
  "updatedAt": "2025-05-20T12:00:00Z",
  "contacts": [
    {
      "id": 1,
      "email": "supporter@example.com",
      "name": "John Supporter",
      "status": "subscribed"
    }
  ]
}
```

#### Create Campaign
```
POST /api/campaigns
```
Creates a new campaign. Requires admin privileges.

Request body:
```json
{
  "name": "Facebook Campaign",
  "description": "Our social media campaign",
  "platform": "facebook",
  "status": "draft",
  "startDate": "2025-08-01T00:00:00Z",
  "endDate": "2025-09-01T00:00:00Z",
  "goal": 5000
}
```

Response:
```json
{
  "id": 2,
  "name": "Facebook Campaign",
  "description": "Our social media campaign",
  "platform": "facebook",
  "status": "draft",
  "startDate": "2025-08-01T00:00:00Z",
  "endDate": "2025-09-01T00:00:00Z",
  "goal": 5000,
  "createdAt": "2025-05-22T12:00:00Z",
  "updatedAt": "2025-05-22T12:00:00Z"
}
```

#### Update Campaign
```
PUT /api/campaigns/:id
```
Updates an existing campaign. Requires admin privileges.

Request body:
```json
{
  "status": "active",
  "goal": 6000
}
```

Response:
```json
{
  "id": 2,
  "name": "Facebook Campaign",
  "description": "Our social media campaign",
  "platform": "facebook",
  "status": "active",
  "startDate": "2025-08-01T00:00:00Z",
  "endDate": "2025-09-01T00:00:00Z",
  "goal": 6000,
  "createdAt": "2025-05-22T12:00:00Z",
  "updatedAt": "2025-05-22T12:30:00Z"
}
```

#### Delete Campaign
```
DELETE /api/campaigns/:id
```
Deletes a campaign. Requires admin privileges.

Response:
```json
{
  "message": "Campaign deleted successfully"
}
```

#### Add Contacts to Campaign
```
POST /api/campaigns/:campaignId/contacts
```
Adds contacts to a campaign. Requires admin privileges.

Request body:
```json
{
  "contactIds": [1, 2, 3]
}
```

Response:
```json
{
  "message": "Contacts added to campaign successfully"
}
```

#### Remove Contact from Campaign
```
DELETE /api/campaigns/:campaignId/contacts/:contactId
```
Removes a contact from a campaign. Requires admin privileges.

Response:
```json
{
  "message": "Contact removed from campaign successfully"
}
```

### Contact Endpoints

#### Get All Contacts
```
GET /api/contacts
```
Retrieves all contacts. Requires authentication.

Response:
```json
[
  {
    "id": 1,
    "email": "contact@example.com",
    "name": "John Contact",
    "source": "website",
    "createdAt": "2025-05-20T12:00:00Z",
    "updatedAt": "2025-05-20T12:00:00Z"
  }
]
```

#### Create Contact
```
POST /api/contacts
```
Creates a new contact. This is a public endpoint with rate limiting.

Request body:
```json
{
  "email": "new@example.com",
  "name": "New Contact",
  "source": "landing-page"
}
```

Response:
```json
{
  "id": 2,
  "email": "new@example.com",
  "name": "New Contact",
  "source": "landing-page",
  "createdAt": "2025-05-22T12:00:00Z",
  "updatedAt": "2025-05-22T12:00:00Z"
}
```

#### Update Contact
```
PUT /api/contacts/:id
```
Updates an existing contact. Requires admin privileges.

Request body:
```json
{
  "name": "Updated Name"
}
```

Response:
```json
{
  "id": 2,
  "email": "new@example.com",
  "name": "Updated Name",
  "source": "landing-page",
  "createdAt": "2025-05-22T12:00:00Z",
  "updatedAt": "2025-05-22T12:30:00Z"
}
```

#### Delete Contact
```
DELETE /api/contacts/:id
```
Deletes a contact. Requires admin privileges.

Response:
```json
{
  "message": "Contact deleted successfully"
}
```

### Newsletter Subscription Endpoint

#### Subscribe to Newsletter
```
POST /api/subscribe
```
Subscribes an email to the newsletter. Public endpoint.

Request body:
```json
{
  "email": "subscriber@example.com",
  "name": "John Subscriber",
  "language": "en"
}
```

Response:
```json
{
  "message": "Subscribed successfully",
  "subscriber": {
    "id": 1,
    "email": "subscriber@example.com",
    "name": "John Subscriber",
    "language": "en",
    "isActive": true,
    "createdAt": "2025-05-22T12:00:00Z",
    "updatedAt": "2025-05-22T12:00:00Z"
  }
}
```

### Feedback Endpoint

#### Submit Feedback
```
POST /api/feedback
```
Submits user feedback. Public endpoint.

Request body:
```json
{
  "name": "John Feedback",
  "email": "feedback@example.com",
  "message": "I love the concept of your app!",
  "rating": 5
}
```

Response:
```json
{
  "message": "Feedback submitted successfully",
  "feedback": {
    "id": 1,
    "name": "John Feedback",
    "email": "feedback@example.com",
    "message": "I love the concept of your app!",
    "rating": 5,
    "createdAt": "2025-05-22T12:00:00Z"
  }
}
```

## Error Handling

All API endpoints return appropriate HTTP status codes and error messages when errors occur:

### Common Error Responses

#### Authentication Error
```json
{
  "message": "Not authenticated"
}
```
Status Code: 401

#### Authorization Error
```json
{
  "message": "Not authorized"
}
```
Status Code: 403

#### Not Found Error
```json
{
  "message": "Resource not found"
}
```
Status Code: 404

#### Validation Error
```json
{
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "error": "Invalid email format"
    }
  ]
}
```
Status Code: 400

#### Server Error
```json
{
  "message": "Internal server error"
}
```
Status Code: 500

## Rate Limiting

Public endpoints such as `/api/contacts`, `/api/subscribe`, and `/api/feedback` implement rate limiting to prevent abuse. The current limits are:

- 10 requests per minute per IP address
- 100 requests per day per IP address

When rate limits are exceeded, the API returns:

```json
{
  "message": "Too many requests, please try again later"
}
```
Status Code: 429

## API Versioning

The current API version is v1 (implicit in the URL structure). Future API versions will use explicit versioning in the URL (e.g., `/api/v2/...`).

## CORS Configuration

The API supports Cross-Origin Resource Sharing (CORS) with the following configuration:

- Allowed origins: The frontend domain
- Allowed methods: GET, POST, PUT, DELETE
- Allowed headers: Content-Type, Authorization
- Credentials: Allowed (for cookie-based authentication)

## API Testing

You can test the API using tools like Postman or curl. Sample curl commands:

### Login
```bash
curl -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"********"}' \
  -c cookies.txt
```

### Get Settings
```bash
curl -X GET http://localhost:5000/api/settings \
  -b cookies.txt
```

### Subscribe to Newsletter
```bash
curl -X POST http://localhost:5000/api/subscribe \
  -H "Content-Type: application/json" \
  -d '{"email":"new@example.com","name":"New Subscriber","language":"en"}'
```