# Voc2Go Technical Documentation

This document provides detailed technical information about the Voc2Go landing page implementation, intended for developers working on the project.

## Project Structure

```
├── client/                  # Frontend code
│   ├── src/                 # Source files
│   │   ├── assets/          # Images and media files
│   │   ├── components/      # React components
│   │   ├── context/         # React context providers
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions
│   │   ├── styles/          # CSS files
│   │   ├── App.tsx          # Main application component
│   │   ├── BasicApp.tsx     # Basic version of the app
│   │   ├── index.tsx        # Entry point
│   │   └── main.tsx         # Vite entry point
│
├── server/                  # Backend code
│   ├── middleware/          # Express middleware
│   ├── routes/              # API route definitions
│   ├── db.ts                # Database connection setup
│   ├── index.ts             # Server entry point
│   ├── routes.ts            # Route registration
│   ├── setup.js             # Initial setup script
│   ├── storage.ts           # Data storage interface
│   └── vite.ts              # Vite configuration for server
│
├── shared/                  # Code shared between frontend and backend
│   └── schema.ts            # Database schema and type definitions
│
├── docs/                    # Documentation
│   ├── README.md            # General documentation
│   └── TECHNICAL.md         # Technical documentation
│
├── package.json             # Project dependencies and scripts
├── tailwind.config.ts       # Tailwind CSS configuration
├── tsconfig.json            # TypeScript configuration
└── vite.config.ts           # Vite bundler configuration
```

## Frontend Architecture

### Component Hierarchy

The frontend is structured around React components organized in a logical hierarchy:

```
App (App.tsx)
├── LanguageProvider (context/LanguageContext.tsx)
├── Header (components/Header.tsx)
├── Main Content
│   ├── HeroSection (components/HeroSection.tsx)
│   ├── FeaturesSection (components/FeaturesSection.tsx)
│   ├── AppScreenshotsSection (components/AppScreenshotsSection.tsx)
│   ├── PlanComparisonSection (components/PlanComparisonSection.tsx)
│   ├── CampaignSection (components/CampaignSection.tsx)
│   ├── RoadmapSection (components/RoadmapSection.tsx)
│   ├── FeedbackSection (components/FeedbackSection.tsx)
│   └── LearnersSection (components/LearnersSection.tsx)
├── Footer (components/Footer.tsx)
└── AdminOverlay (components/AdminOverlay.tsx)
    ├── AdminLogin (components/AdminLogin.tsx)
    └── AdminDashboard (components/AdminDashboard.tsx)
```

### State Management

The application uses a combination of React's Context API and local component state:

1. **LanguageContext**: Manages the current language and provides translation functions
2. **Component State**: Individual components manage their own UI state
3. **Query State**: API data is managed using TanStack Query

### Responsive Design Implementation

The application implements responsive design through:

1. **Tailwind CSS**: Using responsive utilities like `sm:`, `md:`, `lg:`, and `xl:` prefixes
2. **CSS Custom Properties**: Variables for consistent spacing and sizing
3. **Mobile-first approach**: Default styles for mobile with media queries for larger screens
4. **Custom hook**: The `useIsMobile()` hook detects mobile viewports

```typescript
// Example from hooks/use-mobile.tsx
export function useIsMobile() {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  return isMobile;
}
```

### Language System Implementation

The language system uses React's Context API for global state management:

```typescript
// Key components from context/LanguageContext.tsx

// Type definition
type Language = 'en' | 'hu';

// Context definition
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

// Provider implementation
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  // Translation function
  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Usage hook
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
```

## Backend Architecture

### Express Server Setup

The backend uses Express.js with TypeScript for API routes and server-side logic:

```typescript
// Key parts from server/index.ts
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Middleware for logging API requests
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  // Capture and log response data
  // ...
});

// Register API routes
const server = await registerRoutes(app);

// Error handling middleware
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ message });
  throw err;
});

// Serve static files in production
if (app.get("env") === "development") {
  await setupVite(app, server);
} else {
  serveStatic(app);
}
```

### Database Integration

The application uses Drizzle ORM with PostgreSQL:

```typescript
// From server/db.ts
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });
```

### Storage Interface

The backend implements a storage interface that abstracts database operations:

```typescript
// From server/storage.ts
export interface IStorage {
  // Subscriber methods
  getSubscriber(id: number): Promise<Subscriber | undefined>;
  getSubscriberByEmail(email: string): Promise<Subscriber | undefined>;
  createSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
  
  // Feedback methods
  getFeedback(id: number): Promise<Feedback | undefined>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUserPassword(email: string, password: string): Promise<User | undefined>;

  // Additional methods for settings, media, campaigns, contacts, etc.
  // ...
}

export class DatabaseStorage implements IStorage {
  // Implementation of the storage interface using Drizzle ORM
  // ...
}
```

### Authentication Implementation

Authentication is handled using JWT tokens:

```javascript
// From server/routes/auth.js
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await prisma.user.findUnique({
      where: { email }
    });
    
    if (!user) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    
    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    
    // Create token
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET || 'your_jwt_secret',
      { expiresIn: '24h' }
    );
    
    // Set cookie and send response
    res.cookie('token', token, { httpOnly: true });
    res.status(200).json({
      message: 'Logged in successfully',
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

## Database Schema Implementation

The database schema is defined using Drizzle ORM and TypeScript:

```typescript
// From shared/schema.ts
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: text("name"),
  password: text("password").notNull(),
  role: text("role", { enum: ["USER", "ADMIN"] }).default("USER").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Additional tables for settings, media, campaigns, etc.
// ...

// Define relations
export const campaignsRelations = relations(campaigns, ({ many }) => ({
  campaignContacts: many(campaignContacts)
}));

export const contactsRelations = relations(contacts, ({ many }) => ({
  campaignContacts: many(campaignContacts)
}));

// Define insert schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true, 
  createdAt: true, 
  updatedAt: true
});

// Define types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
```

## API Endpoints Implementation

API endpoints are organized by resource type:

### Authentication Routes

```javascript
// From server/routes/auth.js
router.post('/login', async (req, res) => {/* ... */});
router.post('/logout', (req, res) => {/* ... */});
```

### Settings Routes

```javascript
// From server/routes/settings.js
router.get('/', async (req, res) => {/* ... */});
router.put('/', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
```

### Media Routes

```javascript
// From server/routes/media.js
router.post('/', authMiddleware, adminMiddleware, upload.single('file'), async (req, res) => {/* ... */});
router.get('/', async (req, res) => {/* ... */});
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
```

### Campaigns Routes

```javascript
// From server/routes/campaigns.js
router.get('/', authMiddleware, async (req, res) => {/* ... */});
router.get('/:id', authMiddleware, async (req, res) => {/* ... */});
router.post('/', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
```

### Contacts Routes

```javascript
// From server/routes/contacts.js
router.get('/', authMiddleware, async (req, res) => {/* ... */});
router.post('/', rateLimit, async (req, res) => {/* ... */});
router.put('/:id', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
router.delete('/:id', authMiddleware, adminMiddleware, async (req, res) => {/* ... */});
```

## Build and Deployment

### Development Environment

The development environment uses Vite for hot module replacement and fast development:

```typescript
// From server/vite.ts
export async function setupVite(app: Express, server: Server) {
  // Create Vite server in middleware mode
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'custom'
  });

  // Use vite's connect instance as middleware
  app.use(vite.middlewares);
  
  // Setup WebSocket for HMR
  // ...
}
```

### Production Build

The production build process is defined in package.json:

```json
"scripts": {
  "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
  "start": "NODE_ENV=production node dist/index.js"
}
```

This process:
1. Builds the frontend using Vite
2. Bundles the server-side code using ESBuild
3. Combines them for deployment

### Deployment Configuration

The application is configured for deployment on Replit:

```
[deployment]
deploymentTarget = "autoscale"
build = ["npm", "run", "build"]
run = ["npm", "run", "start"]

[[ports]]
localPort = 5000
externalPort = 80
```

## Performance Considerations

### Frontend Optimizations

1. **Code Splitting**: Lazy-loading components when not immediately needed
2. **Asset Optimization**: Proper sizing and compression of images
3. **Minimal Re-renders**: Careful use of React's memoization capabilities

### Backend Optimizations

1. **Database Indexing**: Important fields have been indexed for faster queries
2. **Query Optimization**: Using select to retrieve only needed fields
3. **Connection Pooling**: PostgreSQL connection pooling for improved performance

## Security Considerations

1. **Authentication**: JWT tokens with proper expiration and httpOnly cookies
2. **Authorization**: Role-based access control for admin operations
3. **Input Validation**: Zod schema validation for all inputs
4. **SQL Injection Protection**: Parameterized queries with Drizzle ORM
5. **XSS Protection**: React's built-in HTML escaping

## Testing Strategy

1. **Component Testing**: Individual React components can be tested with Jest and React Testing Library
2. **API Testing**: Endpoints can be tested with Supertest
3. **Integration Testing**: End-to-end flows can be tested with Cypress

## Future Improvements

1. **Server-side Rendering**: Adding SSR for improved SEO
2. **Progressive Web App**: Implementing service workers for offline capability
3. **Internationalization Expansion**: Adding more languages beyond English and Hungarian
4. **Analytics Integration**: Tracking user interaction and campaign performance
5. **A/B Testing Framework**: Testing different layouts and messaging for conversion optimization