# VOC2GO Installation Guide

This document provides step-by-step instructions for setting up the VOC2GO landing page application in development and production environments.

## Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (version 20.x or later)
- **PostgreSQL** (version 16.x or later)
- **Git** (for cloning the repository)

## Local Development Setup

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/voc2go-landing.git
cd voc2go-landing
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Environment Variables

Create a `.env` file in the root directory with the following variables:

```
# Database configuration
DATABASE_URL=postgresql://username:password@localhost:5432/voc2go

# JWT secret for authentication
JWT_SECRET=your_jwt_secret_key

# Server port
PORT=5000

# Node environment
NODE_ENV=development
```

Replace `username`, `password`, and other placeholder values with your actual configuration.

### 4. Create the Database

Create a PostgreSQL database named `voc2go`:

```bash
psql -U postgres -c "CREATE DATABASE voc2go;"
```

### 5. Run Database Migrations

Push the database schema to your database:

```bash
npm run db:push
```

### 6. Initialize Admin User and Default Settings

Run the setup script to create an admin user and default settings:

```bash
node server/setup.js
```

Follow the prompts to create your admin account.

### 7. Start the Development Server

```bash
npm run dev
```

This will start the development server on port 5000 (or the port specified in your `.env` file). The application will be accessible at `http://localhost:5000`.

## Production Deployment

### Option 1: Deploying on Replit

1. Create a new Repl on Replit.com
2. Import the repository
3. Set up the following environment variables in the Replit secrets panel:
   - `DATABASE_URL`: Your PostgreSQL connection string
   - `JWT_SECRET`: A secure random string for JWT token signing
   - `NODE_ENV`: Set to `production`
4. Click "Run" to deploy the application

### Option 2: Deploying on a Traditional Server

#### 1. Server Requirements

- Node.js 20.x or later
- PostgreSQL 16.x or later
- Nginx (recommended for reverse proxy)
- PM2 (for process management)

#### 2. Install Dependencies

```bash
npm install
npm install pm2 -g
```

#### 3. Build the Application

```bash
npm run build
```

This creates optimized production build in the `dist` directory.

#### 4. Set Up Environment Variables

Create a `.env` file with production settings:

```
DATABASE_URL=postgresql://username:password@localhost:5432/voc2go
JWT_SECRET=your_production_jwt_secret
NODE_ENV=production
PORT=5000
```

#### 5. Set Up Database

Create and migrate the database:

```bash
psql -U postgres -c "CREATE DATABASE voc2go;"
npm run db:push
```

#### 6. Configure Nginx

Create an Nginx configuration file:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### 7. Start the Application with PM2

```bash
pm2 start npm --name "voc2go" -- start
pm2 save
pm2 startup
```

#### 8. Set Up SSL with Let's Encrypt

```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Option 3: Deploying with Docker

#### 1. Create a Dockerfile

Create a `Dockerfile` in the root directory:

```Dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

ENV NODE_ENV=production

EXPOSE 5000

CMD ["npm", "start"]
```

#### 2. Create a Docker Compose file

Create a `docker-compose.yml` file:

```yaml
version: '3'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://postgres:password@db:5432/voc2go
      - JWT_SECRET=your_jwt_secret
    depends_on:
      - db
    restart: always

  db:
    image: postgres:16-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=voc2go
    restart: always

volumes:
  postgres_data:
```

#### 3. Build and Run with Docker Compose

```bash
docker-compose up -d
```

#### 4. Initialize the Database

```bash
docker-compose exec app node server/setup.js
```

## Environment Variables Reference

| Variable      | Description                        | Default Value         | Required |
|---------------|------------------------------------|----------------------|----------|
| DATABASE_URL  | PostgreSQL connection string       | -                    | Yes      |
| JWT_SECRET    | Secret for JWT token signing       | -                    | Yes      |
| PORT          | Port for the server to listen on   | 5000                 | No       |
| NODE_ENV      | Environment (development/production)| development         | No       |
| COOKIE_SECRET | Secret for cookie signing          | -                    | No       |
| UPLOAD_DIR    | Directory for media uploads        | ./uploads            | No       |

## Troubleshooting

### Database Connection Issues

If you encounter database connection issues:

1. Verify that PostgreSQL is running:
   ```bash
   sudo systemctl status postgresql
   ```

2. Check that your DATABASE_URL is correct and that the user has proper permissions:
   ```bash
   psql -U username -d voc2go
   ```

3. Ensure that PostgreSQL is configured to accept connections from your application:
   - Check `pg_hba.conf` for proper access configuration
   - Verify that PostgreSQL is listening on the expected port

### Build Errors

If you encounter build errors:

1. Clear node modules and reinstall:
   ```bash
   rm -rf node_modules
   npm install
   ```

2. Check for compatibility issues in package versions:
   ```bash
   npm ls
   ```

### Server Won't Start

If the server won't start:

1. Check if the port is already in use:
   ```bash
   lsof -i :5000
   ```

2. Verify environment variables are set correctly:
   ```bash
   printenv | grep DATABASE
   ```

3. Check the logs for specific errors:
   ```bash
   npm run dev
   ```

## Updating the Application

To update the application to a newer version:

1. Pull the latest changes:
   ```bash
   git pull origin main
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run database migrations:
   ```bash
   npm run db:push
   ```

4. Rebuild and restart the application:
   ```bash
   npm run build
   pm2 restart voc2go
   ```