# Voc2Go Database Documentation

This document provides detailed information about the Voc2Go application's database structure, relationships between tables, data models, and migration process.

## Database Overview

The Voc2Go landing page uses a PostgreSQL database to store user data, content, campaign information, and user interactions. The database is structured to support the bilingual nature of the application and the campaign management needs.

## Entity Relationship Diagram

Below is a simplified diagram of the main database entities and their relationships:

```
Users 1───┐
          │
          ▼
Campaigns ┬───┐     ┌────► Contacts
          │   │     │
          │   └────►┘
          │
          │
          ▼
Media Items

Subscribers

Feedbacks

Settings
```

## Table Definitions

### Users Table

Stores administrator and regular user accounts.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| email      | varchar   | NOT NULL, UNIQUE     | User email address               |
| name       | text      |                      | User's full name                 |
| password   | text      | NOT NULL             | Hashed password                  |
| role       | text      | NOT NULL, DEFAULT    | User role (USER or ADMIN)        |
| createdAt  | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt  | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Settings Table

Stores application configuration and customization settings.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| key        | varchar   | NOT NULL, UNIQUE     | Setting key identifier           |
| value      | text      | NOT NULL             | Setting value                    |
| type       | varchar   | NOT NULL, DEFAULT    | Data type (string, number, etc.) |

### Media Items Table

Stores uploaded images and other media files.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| name       | varchar   | NOT NULL             | File name                        |
| path       | text      | NOT NULL             | File storage path                |
| type       | varchar   | NOT NULL             | Media type                       |
| createdAt  | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt  | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Campaigns Table

Stores information about marketing campaigns.

| Column      | Type      | Constraints          | Description                      |
|-------------|-----------|----------------------|----------------------------------|
| id          | serial    | PRIMARY KEY          | Unique identifier                |
| name        | varchar   | NOT NULL             | Campaign name                    |
| description | text      |                      | Campaign description             |
| platform    | varchar   | NOT NULL             | Platform (indiegogo, etc.)       |
| status      | varchar   | NOT NULL             | Status (draft, active, etc.)     |
| startDate   | timestamp |                      | Campaign start date              |
| endDate     | timestamp |                      | Campaign end date                |
| goal        | real      |                      | Funding goal amount              |
| createdAt   | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt   | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Contacts Table

Stores information about people who have interacted with campaigns.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| email      | varchar   | NOT NULL, UNIQUE     | Contact email address            |
| name       | text      |                      | Contact name                     |
| source     | varchar   |                      | Where contact came from          |
| createdAt  | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt  | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Campaign Contacts Table

Junction table for the many-to-many relationship between campaigns and contacts.

| Column      | Type      | Constraints          | Description                      |
|-------------|-----------|----------------------|----------------------------------|
| id          | serial    | PRIMARY KEY          | Unique identifier                |
| campaignId  | serial    | NOT NULL, FOREIGN KEY| Reference to campaigns table     |
| contactId   | serial    | NOT NULL, FOREIGN KEY| Reference to contacts table      |
| status      | varchar   | NOT NULL             | Subscription status              |
| createdAt   | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt   | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Subscribers Table

Stores newsletter subscribers.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| email      | varchar   | NOT NULL, UNIQUE     | Subscriber email address         |
| name       | text      |                      | Subscriber name                  |
| language   | varchar   | NOT NULL, DEFAULT    | Preferred language (en/hu)       |
| isActive   | boolean   | NOT NULL, DEFAULT    | Subscription status              |
| createdAt  | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |
| updatedAt  | timestamp | NOT NULL, DEFAULT    | Record update timestamp          |

### Feedbacks Table

Stores user feedback submissions.

| Column     | Type      | Constraints          | Description                      |
|------------|-----------|----------------------|----------------------------------|
| id         | serial    | PRIMARY KEY          | Unique identifier                |
| name       | text      |                      | User name                        |
| email      | varchar   | NOT NULL             | User email                       |
| message    | text      | NOT NULL             | Feedback message                 |
| rating     | real      |                      | Optional numerical rating        |
| createdAt  | timestamp | NOT NULL, DEFAULT    | Record creation timestamp        |

## Table Relationships

### One-to-Many Relationships

- A **Campaign** can have many **Campaign Contacts**
- A **Contact** can have many **Campaign Contacts**

### Many-to-Many Relationships

- **Campaigns** and **Contacts** have a many-to-many relationship through the **Campaign Contacts** junction table

## Indexes and Performance Considerations

The following indexes are automatically created:

- Primary key indexes on all `id` columns
- Unique indexes on:
  - `users.email`
  - `settings.key`
  - `contacts.email`
  - `subscribers.email`
  - Compound unique index on `campaignId` and `contactId` in the `campaign_contacts` table

Additional indexes that could be added for improved performance:

- Index on `media_items.type` if filtering by media type is common
- Index on `campaigns.status` if filtering by status is frequent
- Index on `subscribers.language` if filtering by language preference is common

## Data Validation

The application uses Zod schemas derived from the Drizzle ORM table definitions to validate data before insertion:

```typescript
// Example for users
export const insertUserSchema = createInsertSchema(users).omit({
  id: true, 
  createdAt: true, 
  updatedAt: true
});
```

These schemas are used to:
1. Validate API request bodies
2. Provide TypeScript type safety
3. Transform data when needed

## Migrations

Database migrations are handled using Drizzle Kit. The schema is defined in `shared/schema.ts` and the migration process uses the `db:push` command:

```
npm run db:push
```

This command will:
1. Compare the current schema with the database
2. Generate SQL statements for any changes
3. Apply those changes to the database

### Migration Best Practices

1. **Always back up the database** before running migrations in production
2. Review the generated SQL before applying migrations
3. Test migrations in a development environment first
4. If a migration would cause data loss, manually handle the migration by:
   - Creating temporary tables
   - Copying data
   - Altering the schema
   - Restoring the data

## Initial Setup

The initial database setup is handled by the `server/setup.js` script, which:

1. Creates default settings
2. Sets up the first admin user account
3. Configures basic site content

## Backup and Recovery

It's recommended to:

1. Set up regular database backups
2. Test the restore process periodically
3. Keep backup files in a secure, offsite location

## Performance Monitoring

To monitor database performance:

1. Watch for slow queries in the PostgreSQL logs
2. Use the `EXPLAIN ANALYZE` command to understand query execution plans
3. Consider adding indexes for frequently used queries
4. Monitor connection pool usage