const express = require('express');
const path = require('path');
const { PrismaClient } = require('@prisma/client');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3000;

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

app.use(express.json());
app.use(cookieParser());
app.use(cors());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'client/build')));

// Create uploads directory if it doesn't exist
const fs = require('fs');
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token || req.headers['x-access-token'];
  
  if (!token) return res.status(401).json({ error: 'Access denied' });
  
  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret');
    req.user = verified;
    next();
  } catch (error) {
    res.status(400).json({ error: 'Invalid token' });
  }
};

// Admin middleware
const isAdmin = async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id }
    });
    
    if (user && user.role === 'ADMIN') {
      next();
    } else {
      res.status(403).json({ error: 'Access denied: Admin privileges required' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Auth routes
app.post('/api/register', async (req, res) => {
  try {
    const { email, name, password } = req.body;
    
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });
    
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create new user
    const user = await prisma.user.create({
      data: {
        email,
        name,
        password: hashedPassword,
        // First user is automatically an admin
        role: (await prisma.user.count() === 0) ? 'ADMIN' : 'USER'
      }
    });
    
    // Create token
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET || 'your_jwt_secret',
      { expiresIn: '24h' }
    );
    
    // Set cookie and send response
    res.cookie('token', token, { httpOnly: true });
    res.status(201).json({
      message: 'User created successfully',
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await prisma.user.findUnique({
      where: { email }
    });
    
    if (!user) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    
    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }
    
    // Create token
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET || 'your_jwt_secret',
      { expiresIn: '24h' }
    );
    
    // Set cookie and send response
    res.cookie('token', token, { httpOnly: true });
    res.status(200).json({
      message: 'Logged in successfully',
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('token');
  res.status(200).json({ message: 'Logged out successfully' });
});

// Settings routes
app.get('/api/settings', async (req, res) => {
  try {
    const settings = await prisma.settings.findMany();
    const settingsObject = settings.reduce((acc, setting) => {
      acc[setting.key] = setting.value;
      return acc;
    }, {});
    
    res.json(settingsObject);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/settings', authenticateToken, isAdmin, async (req, res) => {
  try {
    const settings = req.body;
    
    for (const [key, value] of Object.entries(settings)) {
      await prisma.settings.upsert({
        where: { key },
        update: { value: String(value) },
        create: { key, value: String(value) }
      });
    }
    
    res.json({ message: 'Settings updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Media routes
app.post('/api/media', authenticateToken, isAdmin, upload.single('file'), async (req, res) => {
  try {
    const { file } = req;
    
    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const mediaItem = await prisma.mediaItem.create({
      data: {
        name: file.originalname,
        path: file.path,
        type: file.mimetype
      }
    });
    
    res.status(201).json(mediaItem);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/media', async (req, res) => {
  try {
    const mediaItems = await prisma.mediaItem.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(mediaItems);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/media/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    const mediaItem = await prisma.mediaItem.findUnique({
      where: { id: parseInt(id) }
    });
    
    if (!mediaItem) {
      return res.status(404).json({ error: 'Media item not found' });
    }
    
    // Delete file from filesystem
    fs.unlinkSync(mediaItem.path);
    
    // Delete from database
    await prisma.mediaItem.delete({
      where: { id: parseInt(id) }
    });
    
    res.json({ message: 'Media item deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Campaign routes
app.post('/api/campaigns', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { name, description, platform, status, startDate, endDate, goal } = req.body;
    
    const campaign = await prisma.campaign.create({
      data: {
        name,
        description,
        platform,
        status,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        goal: goal ? parseFloat(goal) : null
      }
    });
    
    res.status(201).json(campaign);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/campaigns', authenticateToken, async (req, res) => {
  try {
    const campaigns = await prisma.campaign.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(campaigns);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/campaigns/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    const campaign = await prisma.campaign.findUnique({
      where: { id: parseInt(id) },
      include: {
        contacts: {
          include: {
            contact: true
          }
        }
      }
    });
    
    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    res.json(campaign);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/campaigns/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, platform, status, startDate, endDate, goal } = req.body;
    
    const campaign = await prisma.campaign.update({
      where: { id: parseInt(id) },
      data: {
        name,
        description,
        platform,
        status,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        goal: goal ? parseFloat(goal) : null
      }
    });
    
    res.json(campaign);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/campaigns/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Delete campaign contacts first
    await prisma.campaignContact.deleteMany({
      where: { campaignId: parseInt(id) }
    });
    
    // Delete campaign
    await prisma.campaign.delete({
      where: { id: parseInt(id) }
    });
    
    res.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Contact routes
app.post('/api/contacts', async (req, res) => {
  try {
    const { email, name, source } = req.body;
    
    // Check if contact already exists
    const existingContact = await prisma.contact.findUnique({
      where: { email }
    });
    
    if (existingContact) {
      return res.status(200).json(existingContact);
    }
    
    const contact = await prisma.contact.create({
      data: {
        email,
        name,
        source
      }
    });
    
    res.status(201).json(contact);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/contacts', authenticateToken, async (req, res) => {
  try {
    const contacts = await prisma.contact.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(contacts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/campaigns/:campaignId/contacts', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { campaignId } = req.params;
    const { contactIds } = req.body;
    
    const results = [];
    
    for (const contactId of contactIds) {
      // Check if relation already exists
      const existing = await prisma.campaignContact.findFirst({
        where: {
          campaignId: parseInt(campaignId),
          contactId: parseInt(contactId)
        }
      });
      
      if (!existing) {
        const campaignContact = await prisma.campaignContact.create({
          data: {
            campaignId: parseInt(campaignId),
            contactId: parseInt(contactId),
            status: 'subscribed'
          }
        });
        results.push(campaignContact);
      }
    }
    
    res.status(201).json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Public newsletter signup
app.post('/api/subscribe', async (req, res) => {
  try {
    const { email, name } = req.body;
    
    // Check if contact already exists
    let contact = await prisma.contact.findUnique({
      where: { email }
    });
    
    if (!contact) {
      contact = await prisma.contact.create({
        data: {
          email,
          name,
          source: 'website'
        }
      });
    }
    
    res.status(200).json({
      message: 'Subscribed successfully',
      contact
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Serve React app for any other route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});