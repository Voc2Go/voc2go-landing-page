import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { prisma } from '../db.js';
import { authenticateToken, isAdmin } from '../middleware/auth.js';

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../../uploads');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Create unique filename with original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

// File filter to accept only images
const fileFilter = (req, file, cb) => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, GIF and WebP images are allowed.'), false);
  }
};

const upload = multer({ 
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB size limit
  }
});

/**
 * Upload a new media file
 * POST /api/media
 * Requires admin privileges
 */
router.post('/', authenticateToken, isAdmin, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Create record in database
    const mediaItem = await prisma.mediaItem.create({
      data: {
        name: req.file.originalname,
        path: `/uploads/${req.file.filename}`, // Store as relative URL
        type: req.file.mimetype
      }
    });
    
    // Return media item with absolute URL
    const host = req.get('host');
    const protocol = req.protocol;
    
    res.status(201).json({
      ...mediaItem,
      url: `${protocol}://${host}${mediaItem.path}`
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    
    // Clean up uploaded file if database operation fails
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    
    if (error.message.includes('Invalid file type')) {
      return res.status(400).json({ error: error.message });
    }
    
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

/**
 * Get all media items
 * GET /api/media
 */
router.get('/', async (req, res) => {
  try {
    const mediaItems = await prisma.mediaItem.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    // Add absolute URLs
    const host = req.get('host');
    const protocol = req.protocol;
    
    const mediaWithUrls = mediaItems.map(item => ({
      ...item,
      url: `${protocol}://${host}${item.path}`
    }));
    
    res.json(mediaWithUrls);
  } catch (error) {
    console.error('Error fetching media items:', error);
    res.status(500).json({ error: 'Failed to fetch media items' });
  }
});

/**
 * Delete a media item
 * DELETE /api/media/:id
 * Requires admin privileges
 */
router.delete('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    // Find media item
    const mediaItem = await prisma.mediaItem.findUnique({
      where: { id }
    });
    
    if (!mediaItem) {
      return res.status(404).json({ error: 'Media item not found' });
    }
    
    // Delete file from filesystem
    const filePath = path.join(__dirname, '../..', mediaItem.path);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Delete from database
    await prisma.mediaItem.delete({
      where: { id }
    });
    
    res.json({ message: 'Media item deleted successfully' });
  } catch (error) {
    console.error('Error deleting media item:', error);
    res.status(500).json({ error: 'Failed to delete media item' });
  }
});

export default router;