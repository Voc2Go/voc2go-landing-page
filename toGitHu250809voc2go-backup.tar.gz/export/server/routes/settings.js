const express = require('express');
const { prisma } = require('../db');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

/**
 * Get all settings
 * GET /api/settings
 */
router.get('/', async (req, res) => {
  try {
    const settings = await prisma.settings.findMany();
    
    // Convert to key-value object
    const settingsObject = settings.reduce((acc, setting) => {
      acc[setting.key] = setting.value;
      return acc;
    }, {});
    
    res.json(settingsObject);
  } catch (error) {
    console.error('Error fetching settings:', error);
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

/**
 * Update settings
 * PUT /api/settings
 * Requires admin privileges
 */
router.put('/', authenticateToken, isAdmin, async (req, res) => {
  try {
    const settingsData = req.body;
    
    // Process each setting
    const updatePromises = Object.entries(settingsData).map(([key, value]) => {
      return prisma.settings.upsert({
        where: { key },
        update: { value: String(value) },
        create: { key, value: String(value) }
      });
    });
    
    await Promise.all(updatePromises);
    
    res.json({ message: 'Settings updated successfully' });
  } catch (error) {
    console.error('Error updating settings:', error);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

module.exports = router;