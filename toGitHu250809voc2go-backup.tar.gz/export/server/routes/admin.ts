import express from 'express';
import { storage } from '../storage';
import bcrypt from 'bcrypt';

const router = express.Router();

// Admin login
router.post('/login', async (req, res) => {
  try {
    const { loginName, password } = req.body;
    
    // Enhanced input validation
    if (!loginName || !password) {
      return res.status(400).json({ error: 'Login name and password are required' });
    }
    
    if (typeof loginName !== 'string' || typeof password !== 'string') {
      return res.status(400).json({ error: 'Invalid input types' });
    }
    
    if (loginName.length > 255 || password.length > 255) {
      return res.status(400).json({ error: 'Input too long' });
    }

    const admin = await storage.validateAdminLogin(loginName, password);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = await storage.createSessionToken(admin.id);
    
    // Set session cookie with enhanced security
    res.cookie('adminToken', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
      path: '/api/admin'
    });

    res.json({ 
      success: true, 
      admin: { 
        id: admin.id, 
        loginName: admin.loginName,
        lastLogin: admin.lastLogin 
      }
    });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get current admin info
router.get('/me', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    res.json({ 
      admin: { 
        id: admin.id, 
        loginName: admin.loginName,
        lastLogin: admin.lastLogin 
      }
    });
  } catch (error) {
    console.error('Admin auth error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all subscribers for admin dashboard
router.get('/subscribers', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const subscribers = await storage.getAllSubscribers();
    res.json({ subscribers });
  } catch (error) {
    console.error('Admin get subscribers error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all feedback for admin dashboard
router.get('/feedbacks', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const feedbacks = await storage.getAllFeedbacks();
    res.json({ feedbacks });
  } catch (error) {
    console.error('Admin get feedbacks error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update admin credentials
router.post('/update-credentials', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const { newLoginName, newPassword, currentPassword } = req.body;
    
    // Input validation for credential updates
    if (!currentPassword || typeof currentPassword !== 'string') {
      return res.status(400).json({ error: 'Current password is required' });
    }
    
    if (newLoginName && (typeof newLoginName !== 'string' || newLoginName.length > 255)) {
      return res.status(400).json({ error: 'Invalid login name' });
    }
    
    if (newPassword && (typeof newPassword !== 'string' || newPassword.length < 6 || newPassword.length > 255)) {
      return res.status(400).json({ error: 'Password must be between 6-255 characters' });
    }
    
    // Verify current password
    const isCurrentValid = await bcrypt.compare(currentPassword, admin.passwordHash);
    if (!isCurrentValid) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    const updates: any = {};
    
    if (newLoginName && newLoginName !== admin.loginName) {
      updates.loginName = newLoginName;
    }
    
    if (newPassword) {
      updates.passwordHash = await bcrypt.hash(newPassword, 10);
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: 'No changes provided' });
    }

    const updatedAdmin = await storage.updateAdminSettings(updates);
    
    res.json({ 
      success: true,
      admin: { 
        id: updatedAdmin.id, 
        loginName: updatedAdmin.loginName 
      }
    });
  } catch (error) {
    console.error('Admin update error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Admin logout
router.post('/logout', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (token) {
      // Clear session token from database
      const admin = await storage.validateSessionToken(token);
      if (admin) {
        await storage.updateAdminSettings({ sessionToken: null });
      }
    }

    res.clearCookie('adminToken', {
      path: '/api/admin',
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    });
    res.json({ success: true });
  } catch (error) {
    console.error('Admin logout error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all content sections
router.get('/content', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const { language } = req.query;
    const sections = await storage.getAllContentSections(language as string);
    
    res.json({ sections });
  } catch (error) {
    console.error('Get content error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update content section
router.put('/content/:sectionId', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const { sectionId } = req.params;
    const { title, content, language } = req.body;
    
    // Input validation for content updates
    if (!sectionId || typeof sectionId !== 'string') {
      return res.status(400).json({ error: 'Valid section ID is required' });
    }
    
    if (!title || typeof title !== 'string' || title.length > 500) {
      return res.status(400).json({ error: 'Valid title is required (max 500 chars)' });
    }
    
    if (!content || typeof content !== 'string' || content.length > 50000) {
      return res.status(400).json({ error: 'Valid content is required (max 50000 chars)' });
    }
    
    if (language && (typeof language !== 'string' || !['en', 'hu'].includes(language))) {
      return res.status(400).json({ error: 'Language must be "en" or "hu"' });
    }
    
    const existing = await storage.getContentSection(sectionId, language);
    
    if (existing) {
      const updated = await storage.updateContentSection(sectionId, { 
        title, 
        content, 
        language: language || 'en',
        modifiedBy: admin.loginName 
      });
      res.json({ section: updated });
    } else {
      const created = await storage.createContentSection({
        sectionId,
        title,
        content,
        language: language || 'en',
        modifiedBy: admin.loginName
      });
      res.json({ section: created });
    }
  } catch (error) {
    console.error('Update content error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update content section (alternative route for frontend compatibility)
router.put('/content', async (req, res) => {
  try {
    const token = req.cookies.adminToken;
    
    if (!token) {
      return res.status(401).json({ error: 'No session token' });
    }

    const admin = await storage.validateSessionToken(token);
    
    if (!admin) {
      return res.status(401).json({ error: 'Invalid session' });
    }

    const { sectionId, title, content, language } = req.body;
    
    if (!sectionId) {
      return res.status(400).json({ error: 'Section ID is required' });
    }
    
    const existing = await storage.getContentSection(sectionId, language || 'en');
    
    if (existing) {
      const updated = await storage.updateContentSection(sectionId, { 
        title, 
        content, 
        language: language || 'en',
        modifiedBy: admin.loginName 
      });
      res.json({ section: updated });
    } else {
      const created = await storage.createContentSection({
        sectionId,
        title,
        content,
        language: language || 'en',
        modifiedBy: admin.loginName
      });
      res.json({ section: created });
    }
  } catch (error) {
    console.error('Update content error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;