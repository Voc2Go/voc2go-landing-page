import { Router } from 'express';
import { storage } from '../storage';
import { insertTeamMemberSocialsSchema } from '@shared/schema';

const router = Router();

// Get social media links for a specific team member
router.get('/team-socials/:memberId', async (req, res) => {
  try {
    const { memberId } = req.params;
    
    if (!memberId) {
      return res.status(400).json({ error: 'Member ID is required' });
    }
    
    const socials = await storage.getTeamMemberSocials(memberId);
    res.json({ socials: socials || null });
  } catch (error) {
    console.error('Error fetching team member socials:', error);
    res.status(500).json({ error: 'Failed to fetch social media links' });
  }
});

// Update social media links for a team member
router.put('/team-socials/:memberId', async (req, res) => {
  try {
    const { memberId } = req.params;
    const socialsData = req.body;
    
    if (!memberId) {
      return res.status(400).json({ error: 'Member ID is required' });
    }
    
    // Validate the input - only include valid fields
    const { instagram, facebook, linkedin, behance, kofi, pinterest, twitter, website } = socialsData;
    const validatedData = insertTeamMemberSocialsSchema.parse({
      memberId,
      instagram,
      facebook,
      linkedin,
      behance,
      kofi,
      pinterest,
      twitter,
      website
    });
    
    const updatedSocials = await storage.updateTeamMemberSocials(memberId, validatedData);
    res.json({ socials: updatedSocials });
  } catch (error: any) {
    console.error('Error updating team member socials:', error);
    if (error.name === 'ZodError') {
      return res.status(400).json({ error: 'Invalid social media data', details: error.errors });
    }
    res.status(500).json({ error: 'Failed to update social media links' });
  }
});

// Get all team members' social media links
router.get('/team-socials', async (req, res) => {
  try {
    const allSocials = await storage.getAllTeamMemberSocials();
    res.json({ socials: allSocials });
  } catch (error) {
    console.error('Error fetching all team member socials:', error);
    res.status(500).json({ error: 'Failed to fetch team social media links' });
  }
});

export { router as teamSocialsRoutes };