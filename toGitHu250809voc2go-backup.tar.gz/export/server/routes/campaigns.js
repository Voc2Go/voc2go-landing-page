const express = require('express');
const { prisma } = require('../db');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

/**
 * Get all campaigns
 * GET /api/campaigns
 * Requires authentication
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const campaigns = await prisma.campaign.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(campaigns);
  } catch (error) {
    console.error('Error fetching campaigns:', error);
    res.status(500).json({ error: 'Failed to fetch campaigns' });
  }
});

/**
 * Get single campaign with contacts
 * GET /api/campaigns/:id
 * Requires authentication
 */
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    const campaign = await prisma.campaign.findUnique({
      where: { id },
      include: {
        contacts: {
          include: {
            contact: true
          }
        }
      }
    });
    
    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    // Format contacts for frontend
    const formattedCampaign = {
      ...campaign,
      contacts: campaign.contacts.map(cc => ({
        id: cc.contact.id,
        email: cc.contact.email,
        name: cc.contact.name,
        status: cc.status
      }))
    };
    
    res.json(formattedCampaign);
  } catch (error) {
    console.error('Error fetching campaign:', error);
    res.status(500).json({ error: 'Failed to fetch campaign' });
  }
});

/**
 * Create new campaign
 * POST /api/campaigns
 * Requires admin privileges
 */
router.post('/', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { name, description, platform, status, startDate, endDate, goal } = req.body;
    
    const campaign = await prisma.campaign.create({
      data: {
        name,
        description,
        platform,
        status,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        goal: goal ? parseFloat(goal) : null
      }
    });
    
    res.status(201).json(campaign);
  } catch (error) {
    console.error('Error creating campaign:', error);
    res.status(500).json({ error: 'Failed to create campaign' });
  }
});

/**
 * Update campaign
 * PUT /api/campaigns/:id
 * Requires admin privileges
 */
router.put('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { name, description, platform, status, startDate, endDate, goal } = req.body;
    
    const campaign = await prisma.campaign.update({
      where: { id },
      data: {
        name,
        description,
        platform,
        status,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        goal: goal ? parseFloat(goal) : null
      }
    });
    
    res.json(campaign);
  } catch (error) {
    console.error('Error updating campaign:', error);
    
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    res.status(500).json({ error: 'Failed to update campaign' });
  }
});

/**
 * Delete campaign
 * DELETE /api/campaigns/:id
 * Requires admin privileges
 */
router.delete('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    // Delete campaign contacts first (to avoid foreign key constraints)
    await prisma.campaignContact.deleteMany({
      where: { campaignId: id }
    });
    
    // Delete campaign
    await prisma.campaign.delete({
      where: { id }
    });
    
    res.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    console.error('Error deleting campaign:', error);
    
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    res.status(500).json({ error: 'Failed to delete campaign' });
  }
});

/**
 * Add contacts to campaign
 * POST /api/campaigns/:campaignId/contacts
 * Requires admin privileges
 */
router.post('/:campaignId/contacts', authenticateToken, isAdmin, async (req, res) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    const { contactIds } = req.body;
    
    if (!contactIds || !Array.isArray(contactIds) || contactIds.length === 0) {
      return res.status(400).json({ error: 'Contact IDs are required' });
    }
    
    // Check if campaign exists
    const campaign = await prisma.campaign.findUnique({
      where: { id: campaignId }
    });
    
    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }
    
    // Add contacts to campaign
    const results = [];
    
    for (const contactId of contactIds) {
      // Check if contact exists
      const contact = await prisma.contact.findUnique({
        where: { id: parseInt(contactId) }
      });
      
      if (!contact) {
        continue; // Skip if contact doesn't exist
      }
      
      // Check if relation already exists
      const existing = await prisma.campaignContact.findFirst({
        where: {
          campaignId,
          contactId: parseInt(contactId)
        }
      });
      
      if (!existing) {
        const campaignContact = await prisma.campaignContact.create({
          data: {
            campaignId,
            contactId: parseInt(contactId),
            status: 'subscribed'
          },
          include: {
            contact: true
          }
        });
        
        results.push({
          id: campaignContact.contact.id,
          email: campaignContact.contact.email,
          name: campaignContact.contact.name,
          status: campaignContact.status
        });
      }
    }
    
    res.status(201).json(results);
  } catch (error) {
    console.error('Error adding contacts to campaign:', error);
    res.status(500).json({ error: 'Failed to add contacts to campaign' });
  }
});

/**
 * Remove contact from campaign
 * DELETE /api/campaigns/:campaignId/contacts/:contactId
 * Requires admin privileges
 */
router.delete('/:campaignId/contacts/:contactId', authenticateToken, isAdmin, async (req, res) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    const contactId = parseInt(req.params.contactId);
    
    await prisma.campaignContact.deleteMany({
      where: {
        campaignId,
        contactId
      }
    });
    
    res.json({ message: 'Contact removed from campaign successfully' });
  } catch (error) {
    console.error('Error removing contact from campaign:', error);
    res.status(500).json({ error: 'Failed to remove contact from campaign' });
  }
});

module.exports = router;