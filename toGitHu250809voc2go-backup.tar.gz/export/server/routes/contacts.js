const express = require('express');
const { prisma } = require('../db');
const { authenticateToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

/**
 * Get all contacts
 * GET /api/contacts
 * Requires authentication
 */
router.get('/', authenticateToken, async (req, res) => {
  try {
    const contacts = await prisma.contact.findMany({
      orderBy: { createdAt: 'desc' }
    });
    
    res.json(contacts);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ error: 'Failed to fetch contacts' });
  }
});

/**
 * Create new contact
 * POST /api/contacts
 * Public endpoint with rate limiting
 */
router.post('/', async (req, res) => {
  try {
    const { email, name, source } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    
    // Check if contact already exists
    const existingContact = await prisma.contact.findUnique({
      where: { email }
    });
    
    if (existingContact) {
      return res.status(200).json(existingContact);
    }
    
    // Create new contact
    const contact = await prisma.contact.create({
      data: {
        email,
        name: name || null,
        source: source || 'website'
      }
    });
    
    res.status(201).json(contact);
  } catch (error) {
    console.error('Error creating contact:', error);
    res.status(500).json({ error: 'Failed to create contact' });
  }
});

/**
 * Update contact
 * PUT /api/contacts/:id
 * Requires admin privileges
 */
router.put('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { email, name, source } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    
    // Check if email is already taken by another contact
    const existingContact = await prisma.contact.findFirst({
      where: {
        email,
        id: { not: id }
      }
    });
    
    if (existingContact) {
      return res.status(400).json({ error: 'Email is already taken by another contact' });
    }
    
    const contact = await prisma.contact.update({
      where: { id },
      data: {
        email,
        name,
        source
      }
    });
    
    res.json(contact);
  } catch (error) {
    console.error('Error updating contact:', error);
    
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Contact not found' });
    }
    
    res.status(500).json({ error: 'Failed to update contact' });
  }
});

/**
 * Delete contact
 * DELETE /api/contacts/:id
 * Requires admin privileges
 */
router.delete('/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    // Delete campaign contacts first (to avoid foreign key constraints)
    await prisma.campaignContact.deleteMany({
      where: { contactId: id }
    });
    
    // Delete contact
    await prisma.contact.delete({
      where: { id }
    });
    
    res.json({ message: 'Contact deleted successfully' });
  } catch (error) {
    console.error('Error deleting contact:', error);
    
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Contact not found' });
    }
    
    res.status(500).json({ error: 'Failed to delete contact' });
  }
});

/**
 * Public newsletter subscription endpoint
 * POST /api/subscribe
 */
router.post('/subscribe', async (req, res) => {
  try {
    const { email, name } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    
    // Check if contact already exists
    let contact = await prisma.contact.findUnique({
      where: { email }
    });
    
    if (contact) {
      return res.status(200).json({
        message: 'You are already subscribed to our newsletter',
        contact
      });
    }
    
    // Create new contact
    contact = await prisma.contact.create({
      data: {
        email,
        name: name || null,
        source: 'newsletter'
      }
    });
    
    res.status(201).json({
      message: 'Subscribed successfully',
      contact
    });
  } catch (error) {
    console.error('Error subscribing:', error);
    res.status(500).json({ error: 'Failed to process subscription' });
  }
});

module.exports = router;