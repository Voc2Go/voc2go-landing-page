import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from 'url';
import { db } from "../db";
import { mediaItems } from "@shared/schema";
import { eq } from "drizzle-orm";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../../uploads');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    // Create unique filename with original extension
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    // Ensure fieldname is valid and not empty (security best practice)
    const safeFieldname = file.fieldname && file.fieldname.trim() ? file.fieldname : 'upload';
    cb(null, safeFieldname + '-' + uniqueSuffix + ext);
  }
});

// File filter to accept only images
const fileFilter = (req: any, file: any, cb: any) => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, GIF and WebP images are allowed.'), false);
  }
};

const upload = multer({ 
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB size limit
  }
});

/**
 * Upload a new media file
 * POST /api/media
 * Note: Simplified without authentication for now
 */
router.post('/', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Create record in database using Drizzle
    const newMediaItem = await db.insert(mediaItems).values({
      name: req.file.originalname,
      path: `/uploads/${req.file.filename}`, // Store as relative URL
      type: req.file.mimetype
    }).returning();
    
    // Return media item with absolute URL
    const host = req.get('host');
    const protocol = req.protocol;
    
    res.status(201).json({
      ...newMediaItem[0],
      url: `${protocol}://${host}${newMediaItem[0].path}`
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    
    // Clean up uploaded file if database operation fails
    if (req.file) {
      try {
        fs.unlinkSync(req.file.path);
      } catch (unlinkError) {
        console.error('Error cleaning up file:', unlinkError);
      }
    }
    
    if (error instanceof Error && error.message.includes('Invalid file type')) {
      return res.status(400).json({ error: error.message });
    }
    
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

/**
 * Get all media items
 * GET /api/media
 */
router.get('/', async (req, res) => {
  try {
    const mediaItemsList = await db.select().from(mediaItems).orderBy(mediaItems.createdAt);
    
    // Add absolute URLs
    const host = req.get('host');
    const protocol = req.protocol;
    
    const mediaWithUrls = mediaItemsList.map(item => ({
      ...item,
      url: `${protocol}://${host}${item.path}`
    }));
    
    res.json(mediaWithUrls);
  } catch (error) {
    console.error('Error fetching media items:', error);
    res.status(500).json({ error: 'Failed to fetch media items' });
  }
});

/**
 * Delete a media item
 * DELETE /api/media/:id
 * Note: Simplified without authentication for now
 */
router.delete('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid media item ID' });
    }
    
    // Find media item
    const mediaItem = await db.select().from(mediaItems).where(eq(mediaItems.id, id)).limit(1);
    
    if (mediaItem.length === 0) {
      return res.status(404).json({ error: 'Media item not found' });
    }
    
    // Delete file from filesystem
    const filePath = path.join(__dirname, '../..', mediaItem[0].path);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Delete from database
    await db.delete(mediaItems).where(eq(mediaItems.id, id));
    
    res.json({ message: 'Media item deleted successfully' });
  } catch (error) {
    console.error('Error deleting media item:', error);
    res.status(500).json({ error: 'Failed to delete media item' });
  }
});

// Serve uploaded files statically
router.use('/uploads', express.static(path.join(__dirname, '../../uploads')));

export default router;