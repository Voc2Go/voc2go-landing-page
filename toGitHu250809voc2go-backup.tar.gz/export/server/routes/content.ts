import { Router } from 'express';
import { storage } from '../storage';
import { createRateLimit } from '../middleware/rateLimiter';

const router = Router();

// Rate limiter for content endpoint - allow 100 requests per minute for development
const contentRateLimit = createRateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // Increased limit for development environment
  message: 'Too many requests. Please try again later.'
});

// Public endpoint to get content sections
router.get('/content', contentRateLimit, async (req, res) => {
  try {
    const language = req.query.language as string || 'en';
    
    // Input validation
    if (typeof language !== 'string' || !['en', 'hu'].includes(language)) {
      return res.status(400).json({ error: 'Invalid language parameter' });
    }
    
    const sections = await storage.getAllContentSections(language);
    
    // Ensure sections is always an array
    const safeSections = Array.isArray(sections) ? sections : [];
    
    res.json({ sections: safeSections });
  } catch (error) {
    console.error('Error fetching content:', error);
    res.status(500).json({ error: 'Failed to fetch content' });
  }
});

// Admin endpoint to create content sections
router.post('/content', async (req, res) => {
  try {
    const { sectionId, title, content, language = 'en' } = req.body;
    
    // Enhanced input validation
    if (!sectionId || typeof sectionId !== 'string' || sectionId.length > 255) {
      return res.status(400).json({ error: 'Valid section ID is required' });
    }
    
    if (!title || typeof title !== 'string' || title.length > 500) {
      return res.status(400).json({ error: 'Valid title is required (max 500 chars)' });
    }
    
    if (!content || typeof content !== 'string' || content.length > 50000) {
      return res.status(400).json({ error: 'Valid content is required (max 50000 chars)' });
    }
    
    if (!['en', 'hu'].includes(language)) {
      return res.status(400).json({ error: 'Language must be "en" or "hu"' });
    }
    
    const newSection = await storage.createContentSection({
      sectionId: sectionId.trim(),
      title: title.trim(),
      content: content.trim(),
      language,
      modifiedBy: 'admin'
    });
    
    res.json({ section: newSection });
  } catch (error) {
    console.error('Error creating content:', error);
    res.status(500).json({ error: 'Failed to create content' });
  }
});

export { router as contentRoutes };