const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const readline = require('readline');

const prisma = new PrismaClient();

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function main() {
  console.log('=== VOC2GO Website Setup ===');
  console.log('This script will initialize the database and create an admin user.\n');

  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    console.log('✅ Database connection successful');

    // Initialize settings
    const settingsCount = await prisma.settings.count();
    if (settingsCount === 0) {
      await prisma.settings.createMany({
        data: [
          { key: 'siteName', value: 'VOC2GO', type: 'string' },
          { key: 'siteDescription', value: 'Learn languages word by word, story by story', type: 'string' },
          { key: 'primaryColor', value: '#5C37C7', type: 'string' },
          { key: 'primaryDarkColor', value: '#2D0051', type: 'string' },
          { key: 'accentColor', value: '#44d1c6', type: 'string' },
          { key: 'ctaColor', value: '#FF7518', type: 'string' },
          { key: 'contactEmail', value: 'hello@voc2go.com', type: 'string' }
        ]
      });
      console.log('✅ Default settings created');
    } else {
      console.log('ℹ️ Settings already exist, skipping');
    }

    // Check if admin user exists
    const userCount = await prisma.user.count();
    
    if (userCount === 0) {
      // Get admin user details
      const email = await prompt('Enter admin email: ');
      const name = await prompt('Enter admin name: ');
      const password = await prompt('Enter admin password (min 6 characters): ');
      
      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters long');
      }
      
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      
      // Create admin user
      await prisma.user.create({
        data: {
          email,
          name,
          password: hashedPassword,
          role: 'ADMIN'
        }
      });
      
      console.log('✅ Admin user created successfully');
    } else {
      console.log('ℹ️ Users already exist, skipping admin creation');
    }
    
    console.log('\n✨ Setup completed successfully! You can now start the server.');
    console.log('- Run the application with: npm run dev');
    console.log('- Access the admin panel at: http://localhost:5000/login');
  } catch (error) {
    console.error('❌ Setup failed:', error);
  } finally {
    await prisma.$disconnect();
    rl.close();
  }
}

// Helper function to prompt for user input
function prompt(question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

main();