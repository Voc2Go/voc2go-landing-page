import { 
  type Subscriber, type InsertSubscriber, 
  type Feedback, type InsertFeedback,
  type User, type InsertUser,
  type Setting, type InsertSetting,
  type MediaItem, type InsertMediaItem,
  type Campaign, type InsertCampaign,
  type Contact, type InsertContact,
  type CampaignContact, type InsertCampaignContact,
  type AdminSettings, type InsertAdminSettings,
  type ContentSection, type InsertContentSection,
  type SelectTeamMemberSocials, type InsertTeamMemberSocials
} from "@shared/schema";

import { db } from './db';
import { 
  subscribers, feedbacks, users, settings, 
  mediaItems, campaigns, contacts, campaignContacts,
  adminSettings, contentSections, teamMemberSocials
} from '@shared/schema';
import { eq, and, desc, asc } from 'drizzle-orm';
import { hash, compare } from 'bcrypt';

export interface IStorage {
  // Subscriber methods
  getSubscriber(id: number): Promise<Subscriber | undefined>;
  getSubscriberByEmail(email: string): Promise<Subscriber | undefined>;
  createSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
  getAllSubscribers(): Promise<Subscriber[]>;
  
  // Feedback methods
  getFeedback(id: number): Promise<Feedback | undefined>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getAllFeedbacks(): Promise<Feedback[]>;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  validateUserPassword(email: string, password: string): Promise<User | undefined>;

  // Settings methods
  getAllSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<Setting | undefined>;
  updateSetting(key: string, value: string): Promise<Setting>;

  // Media methods
  getAllMedia(): Promise<MediaItem[]>;
  getMedia(id: number): Promise<MediaItem | undefined>;
  createMedia(media: InsertMediaItem): Promise<MediaItem>;
  deleteMedia(id: number): Promise<boolean>;

  // Campaign methods
  getAllCampaigns(): Promise<Campaign[]>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: number): Promise<boolean>;

  // Contact methods
  getAllContacts(): Promise<Contact[]>;
  getContact(id: number): Promise<Contact | undefined>;
  getContactByEmail(email: string): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact | undefined>;
  deleteContact(id: number): Promise<boolean>;

  // Campaign Contact methods
  getCampaignContacts(campaignId: number): Promise<CampaignContact[]>;
  addContactToCampaign(campaignContact: InsertCampaignContact): Promise<CampaignContact>;
  updateCampaignContactStatus(campaignId: number, contactId: number, status: string): Promise<CampaignContact | undefined>;
  removeContactFromCampaign(campaignId: number, contactId: number): Promise<boolean>;

  // Admin Settings methods
  getAdminSettings(): Promise<AdminSettings | undefined>;
  updateAdminSettings(settings: Partial<InsertAdminSettings>): Promise<AdminSettings>;
  validateAdminLogin(loginName: string, password: string): Promise<AdminSettings | undefined>;
  createSessionToken(adminId: number): Promise<string>;
  validateSessionToken(token: string): Promise<AdminSettings | undefined>;

  // Content Section methods
  getAllContentSections(language?: string): Promise<ContentSection[]>;
  getContentSection(sectionId: string, language?: string): Promise<ContentSection | undefined>;
  createContentSection(section: InsertContentSection): Promise<ContentSection>;
  updateContentSection(sectionId: string, content: Partial<InsertContentSection>): Promise<ContentSection | undefined>;
  deleteContentSection(sectionId: string, language?: string): Promise<boolean>;

  // Team Member Social Media methods
  getTeamMemberSocials(memberId: string): Promise<SelectTeamMemberSocials | undefined>;
  updateTeamMemberSocials(memberId: string, socials: Partial<InsertTeamMemberSocials>): Promise<SelectTeamMemberSocials>;
  getAllTeamMemberSocials(): Promise<SelectTeamMemberSocials[]>;
}

export class DatabaseStorage implements IStorage {
  // Subscriber methods
  async getSubscriber(id: number): Promise<Subscriber | undefined> {
    const [subscriber] = await db.select().from(subscribers).where(eq(subscribers.id, id));
    return subscriber || undefined;
  }

  async getSubscriberByEmail(email: string): Promise<Subscriber | undefined> {
    const [subscriber] = await db.select().from(subscribers).where(eq(subscribers.email, email));
    return subscriber || undefined;
  }

  async createSubscriber(insertSubscriber: InsertSubscriber): Promise<Subscriber> {
    try {
      const [subscriber] = await db.insert(subscribers).values(insertSubscriber).returning();
      return subscriber;
    } catch (error: any) {
      // Handle unique violation - email already exists
      if (error.code === '23505') {
        const duplicateError = new Error("Email already subscribed");
        (duplicateError as any).code = '23505';
        throw duplicateError;
      }
      throw error;
    }
  }

  async getAllSubscribers(): Promise<Subscriber[]> {
    return await db.select().from(subscribers).orderBy(desc(subscribers.createdAt));
  }
  
  // Feedback methods
  async getFeedback(id: number): Promise<Feedback | undefined> {
    const [feedback] = await db.select().from(feedbacks).where(eq(feedbacks.id, id));
    return feedback || undefined;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    try {
      const [feedback] = await db.insert(feedbacks).values({
        ...insertFeedback,
        name: insertFeedback.name || "",
        source: insertFeedback.source || "feedback_form",
        language: insertFeedback.language || "en"
      }).returning();
      return feedback;
    } catch (error) {
      console.error("Database error creating feedback:", error);
      throw error;
    }
  }

  async getAllFeedbacks(): Promise<Feedback[]> {
    return await db.select().from(feedbacks).orderBy(desc(feedbacks.createdAt));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Hash the password
    const saltRounds = 10;
    const hashedPassword = await hash(user.password, saltRounds);

    try {
      const [newUser] = await db.insert(users).values({
        ...user,
        password: hashedPassword
      }).returning();
      return newUser;
    } catch (error: any) {
      // Handle unique violation - email already exists
      if (error.code === '23505') {
        throw new Error("Email already in use");
      }
      throw error;
    }
  }

  async validateUserPassword(email: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByEmail(email);
    if (!user) {
      return undefined;
    }

    const isValid = await compare(password, user.password);
    return isValid ? user : undefined;
  }

  // Settings methods
  async getAllSettings(): Promise<Setting[]> {
    return await db.select().from(settings);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting || undefined;
  }

  async updateSetting(key: string, value: string): Promise<Setting> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    
    if (setting) {
      // Update existing setting
      const [updated] = await db.update(settings)
        .set({ value })
        .where(eq(settings.key, key))
        .returning();
      return updated;
    } else {
      // Create new setting
      const [newSetting] = await db.insert(settings)
        .values({ key, value, type: 'string' })
        .returning();
      return newSetting;
    }
  }

  // Media methods
  async getAllMedia(): Promise<MediaItem[]> {
    return await db.select().from(mediaItems).orderBy(desc(mediaItems.createdAt));
  }

  async getMedia(id: number): Promise<MediaItem | undefined> {
    const [media] = await db.select().from(mediaItems).where(eq(mediaItems.id, id));
    return media || undefined;
  }

  async createMedia(media: InsertMediaItem): Promise<MediaItem> {
    const [newMedia] = await db.insert(mediaItems).values(media).returning();
    return newMedia;
  }

  async deleteMedia(id: number): Promise<boolean> {
    const result = await db.delete(mediaItems).where(eq(mediaItems.id, id)).returning();
    return result.length > 0;
  }

  // Campaign methods
  async getAllCampaigns(): Promise<Campaign[]> {
    return await db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }

  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }

  async updateCampaign(id: number, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const [updated] = await db.update(campaigns)
      .set({ ...campaign, updatedAt: new Date() })
      .where(eq(campaigns.id, id))
      .returning();
    return updated;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    // First delete all campaign contacts
    await db.delete(campaignContacts).where(eq(campaignContacts.campaignId, id));
    
    // Then delete the campaign
    const result = await db.delete(campaigns).where(eq(campaigns.id, id)).returning();
    return result.length > 0;
  }

  // Contact methods
  async getAllContacts(): Promise<Contact[]> {
    return await db.select().from(contacts).orderBy(desc(contacts.createdAt));
  }

  async getContact(id: number): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts).where(eq(contacts.id, id));
    return contact || undefined;
  }

  async getContactByEmail(email: string): Promise<Contact | undefined> {
    const [contact] = await db.select().from(contacts).where(eq(contacts.email, email));
    return contact || undefined;
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    try {
      const [newContact] = await db.insert(contacts).values(contact).returning();
      return newContact;
    } catch (error: any) {
      // Handle unique violation - email already exists
      if (error.code === '23505') {
        throw new Error("Contact with this email already exists");
      }
      throw error;
    }
  }

  async updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact | undefined> {
    try {
      const [updated] = await db.update(contacts)
        .set({ ...contact, updatedAt: new Date() })
        .where(eq(contacts.id, id))
        .returning();
      return updated;
    } catch (error: any) {
      // Handle unique violation - email already exists
      if (error.code === '23505') {
        throw new Error("Contact with this email already exists");
      }
      throw error;
    }
  }

  async deleteContact(id: number): Promise<boolean> {
    // First delete all campaign contacts
    await db.delete(campaignContacts).where(eq(campaignContacts.contactId, id));
    
    // Then delete the contact
    const result = await db.delete(contacts).where(eq(contacts.id, id)).returning();
    return result.length > 0;
  }

  // Campaign Contact methods
  async getCampaignContacts(campaignId: number): Promise<CampaignContact[]> {
    return await db.select()
      .from(campaignContacts)
      .where(eq(campaignContacts.campaignId, campaignId));
  }

  async addContactToCampaign(campaignContact: InsertCampaignContact): Promise<CampaignContact> {
    try {
      const [newConnection] = await db.insert(campaignContacts)
        .values(campaignContact)
        .returning();
      return newConnection;
    } catch (error: any) {
      // Handle unique violation - relationship already exists
      if (error.code === '23505') {
        throw new Error("Contact is already in this campaign");
      }
      throw error;
    }
  }

  async updateCampaignContactStatus(campaignId: number, contactId: number, status: string): Promise<CampaignContact | undefined> {
    const [updated] = await db.update(campaignContacts)
      .set({ status, updatedAt: new Date() })
      .where(
        and(
          eq(campaignContacts.campaignId, campaignId),
          eq(campaignContacts.contactId, contactId)
        )
      )
      .returning();
    return updated;
  }

  async removeContactFromCampaign(campaignId: number, contactId: number): Promise<boolean> {
    const result = await db.delete(campaignContacts)
      .where(
        and(
          eq(campaignContacts.campaignId, campaignId),
          eq(campaignContacts.contactId, contactId)
        )
      )
      .returning();
    return result.length > 0;
  }

  // Admin Settings methods
  async getAdminSettings(): Promise<AdminSettings | undefined> {
    const [adminSetting] = await db.select().from(adminSettings).limit(1);
    return adminSetting || undefined;
  }

  async updateAdminSettings(settings: Partial<InsertAdminSettings>): Promise<AdminSettings> {
    const existing = await this.getAdminSettings();
    
    if (existing) {
      const [updated] = await db
        .update(adminSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(adminSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      // Create default admin settings if none exist
      const [created] = await db
        .insert(adminSettings)
        .values({
          loginName: settings.loginName || "admin",
          passwordHash: settings.passwordHash || await hash("admin123", 10),
          ...settings
        })
        .returning();
      return created;
    }
  }

  async validateAdminLogin(loginName: string, password: string): Promise<AdminSettings | undefined> {
    const [admin] = await db
      .select()
      .from(adminSettings)
      .where(eq(adminSettings.loginName, loginName));
    
    if (!admin) return undefined;
    
    const isValid = await compare(password, admin.passwordHash);
    if (!isValid) return undefined;
    
    // Update last login
    await db
      .update(adminSettings)
      .set({ lastLogin: new Date() })
      .where(eq(adminSettings.id, admin.id));
    
    return admin;
  }

  async createSessionToken(adminId: number): Promise<string> {
    const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    
    await db
      .update(adminSettings)
      .set({ sessionToken: token })
      .where(eq(adminSettings.id, adminId));
    
    return token;
  }

  async validateSessionToken(token: string): Promise<AdminSettings | undefined> {
    const [admin] = await db
      .select()
      .from(adminSettings)
      .where(eq(adminSettings.sessionToken, token));
    
    return admin || undefined;
  }

  // Content Section methods
  async getAllContentSections(language?: string): Promise<ContentSection[]> {
    if (language) {
      return await db
        .select()
        .from(contentSections)
        .where(eq(contentSections.language, language))
        .orderBy(asc(contentSections.sectionId));
    }
    return await db
      .select()
      .from(contentSections)
      .orderBy(asc(contentSections.sectionId));
  }

  async getContentSection(sectionId: string, language: string = "en"): Promise<ContentSection | undefined> {
    const [section] = await db
      .select()
      .from(contentSections)
      .where(and(
        eq(contentSections.sectionId, sectionId),
        eq(contentSections.language, language)
      ));
    
    return section || undefined;
  }

  async createContentSection(section: InsertContentSection): Promise<ContentSection> {
    const [created] = await db
      .insert(contentSections)
      .values(section)
      .returning();
    return created;
  }

  async updateContentSection(sectionId: string, content: Partial<InsertContentSection>): Promise<ContentSection | undefined> {
    const language = content.language || 'en';
    const [updated] = await db
      .update(contentSections)
      .set({ ...content, lastModified: new Date() })
      .where(and(
        eq(contentSections.sectionId, sectionId),
        eq(contentSections.language, language)
      ))
      .returning();
    
    return updated || undefined;
  }

  async deleteContentSection(sectionId: string, language?: string): Promise<boolean> {
    const whereCondition = language 
      ? and(eq(contentSections.sectionId, sectionId), eq(contentSections.language, language))
      : eq(contentSections.sectionId, sectionId);
    
    const result = await db
      .delete(contentSections)
      .where(whereCondition);
    
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Team Member Social Media methods
  async getTeamMemberSocials(memberId: string): Promise<SelectTeamMemberSocials | undefined> {
    try {
      const [socials] = await db.select().from(teamMemberSocials).where(eq(teamMemberSocials.memberId, memberId));
      return socials || undefined;
    } catch (error) {
      console.error('Error fetching team member socials:', error);
      return undefined;
    }
  }

  async updateTeamMemberSocials(memberId: string, socials: Partial<InsertTeamMemberSocials>): Promise<SelectTeamMemberSocials> {
    try {
      // First try to update existing record
      const [updated] = await db.update(teamMemberSocials)
        .set({ ...socials, updatedAt: new Date() })
        .where(eq(teamMemberSocials.memberId, memberId))
        .returning();

      if (updated) {
        return updated;
      }

      // If no existing record, create new one
      const [created] = await db.insert(teamMemberSocials)
        .values({ memberId, ...socials })
        .returning();
        
      return created;
    } catch (error) {
      console.error('Error updating team member socials:', error);
      throw error;
    }
  }

  async getAllTeamMemberSocials(): Promise<SelectTeamMemberSocials[]> {
    try {
      const allSocials = await db.select().from(teamMemberSocials);
      return allSocials;
    } catch (error) {
      console.error('Error fetching all team member socials:', error);
      return [];
    }
  }
}

export const storage = new DatabaseStorage();
