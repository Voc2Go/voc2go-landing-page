const jwt = require('jsonwebtoken');

/**
 * Get JWT secret with proper validation
 * @returns {string} JWT secret
 * @throws {Error} If JWT_SECRET is not set in production
 */
function getJWTSecret() {
  const jwtSecret = process.env.JWT_SECRET;
  
  if (!jwtSecret && process.env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET must be set in production environment for security');
  }
  
  // Use development fallback only in non-production
  return jwtSecret || 'dev_jwt_secret_change_in_production';
}

/**
 * Create a JWT token with proper secret validation
 * @param {Object} payload - Token payload
 * @param {Object} options - JWT options
 * @returns {string} JWT token
 */
function createToken(payload, options = { expiresIn: '24h' }) {
  return jwt.sign(payload, getJWTSecret(), options);
}

/**
 * Verify a JWT token with proper secret validation
 * @param {string} token - JWT token to verify
 * @returns {Object} Decoded token payload
 */
function verifyToken(token) {
  return jwt.verify(token, getJWTSecret());
}

module.exports = {
  getJWTSecret,
  createToken,
  verifyToken
};