import jwt from 'jsonwebtoken';
import { prisma } from '../db.js';
import { getJWTSecret } from '../utils/jwt.js';

/**
 * Authentication middleware
 * Verifies the JWT token in the cookie or Authorization header
 */
const authenticateToken = (req, res, next) => {
  // Get token from cookie or Authorization header
  const token = req.cookies.token || req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }
  
  try {
    // Verify token with secure secret
    const decoded = jwt.verify(token, getJWTSecret());
    req.user = decoded;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    res.status(401).json({ error: 'Invalid token.' });
  }
};

/**
 * Admin middleware
 * Checks if the authenticated user has admin privileges
 */
const isAdmin = async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id }
    });
    
    if (!user || user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Access denied. Admin privileges required.' });
    }
    
    next();
  } catch (error) {
    console.error('Admin verification error:', error);
    res.status(500).json({ error: 'Server error during admin verification.' });
  }
};

export { authenticateToken, isAdmin };