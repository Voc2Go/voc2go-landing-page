import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSubscriberSchema, insertFeedbackSchema } from "@shared/schema";
import adminRoutes from "./routes/admin";
import { contentRoutes } from "./routes/content";
import { sanitizeInput, rateLimit } from "./middleware/security";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import path from "path";
import fs from "fs";
import { ObjectStorageService } from "./objectStorage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Import media routes (TypeScript module)
  const { default: mediaRoutes } = await import("./routes/media");
  // Legal document routes
  const legalDocuments = [
    { path: '/terms-en.html', file: 'terms-en.html' },
    { path: '/terms-hu.html', file: 'terms-hu.html' },
    { path: '/privacy-en.html', file: 'privacy-en.html' },
    { path: '/privacy-hu.html', file: 'privacy-hu.html' },
    { path: '/cookie-en.html', file: 'cookie-en.html' },
    { path: '/cookie-hu.html', file: 'cookie-hu.html' }
  ];

  legalDocuments.forEach(doc => {
    app.get(doc.path, (req, res) => {
      const filePath = path.resolve(process.cwd(), 'client', 'public', doc.file);
      
      if (fs.existsSync(filePath)) {
        res.setHeader('Content-Type', 'text/html');
        res.sendFile(filePath);
      } else {
        res.status(404).send('Document not found');
      }
    });
  });

  // Apply security middleware to all API routes
  app.use("/api", sanitizeInput);
  app.use("/api", rateLimit(1000, 15 * 60 * 1000)); // 1000 requests per 15 minutes

  // Admin routes
  app.use("/api/admin", adminRoutes);
  
  // Media routes
  app.use("/api/media", mediaRoutes);
  
  // Public content routes
  app.use("/api", contentRoutes);
  
  // Team socials routes
  const { teamSocialsRoutes } = await import("./routes/team-socials");
  app.use("/api", teamSocialsRoutes);

  // Object storage public file serving
  app.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error searching for public object:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  // Subscribe to campaign updates
  app.post("/api/subscribe", async (req, res) => {
    try {
      // Additional input validation before Zod parsing
      const { email, source, language } = req.body;
      
      if (!email || typeof email !== 'string') {
        return res.status(400).json({ message: "Valid email is required" });
      }
      
      if (email.length > 255) {
        return res.status(400).json({ message: "Email too long" });
      }
      
      if (source && typeof source !== 'string') {
        return res.status(400).json({ message: "Invalid source" });
      }
      
      if (language && !['en', 'hu'].includes(language)) {
        return res.status(400).json({ message: "Language must be 'en' or 'hu'" });
      }
      
      const data = insertSubscriberSchema.parse(req.body);
      const subscriber = await storage.createSubscriber(data);
      res.status(201).json({ 
        message: "Successfully subscribed to campaign updates",
        subscriber 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else if (error instanceof Error && 'code' in error && error.code === '23505') { // PostgreSQL unique violation
        res.status(409).json({ message: "This email is already subscribed" });
      } else {
        console.error("Subscription error:", error);
        res.status(500).json({ message: "Failed to subscribe. Please try again later." });
      }
    }
  });

  // Submit feedback
  app.post("/api/feedback", async (req, res) => {
    try {
      // Additional input validation before Zod parsing
      const { email, message, name, rating, source, language } = req.body;
      
      if (!email || typeof email !== 'string' || email.length > 255) {
        return res.status(400).json({ message: "Valid email is required" });
      }
      
      if (!message || typeof message !== 'string' || message.length > 5000) {
        return res.status(400).json({ message: "Valid message is required (max 5000 chars)" });
      }
      
      if (name && (typeof name !== 'string' || name.length > 255)) {
        return res.status(400).json({ message: "Name too long" });
      }
      
      if (rating && (typeof rating !== 'number' || rating < 1 || rating > 5)) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }
      
      if (source && typeof source !== 'string') {
        return res.status(400).json({ message: "Invalid source" });
      }
      
      if (language && !['en', 'hu'].includes(language)) {
        return res.status(400).json({ message: "Language must be 'en' or 'hu'" });
      }
      
      const data = insertFeedbackSchema.parse(req.body);
      const feedback = await storage.createFeedback(data);
      res.status(201).json({ 
        message: "Thank you for your feedback!",
        feedback 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Feedback error:", error);
        res.status(500).json({ message: "Failed to submit feedback. Please try again later." });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
