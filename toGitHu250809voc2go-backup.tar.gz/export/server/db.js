import { PrismaClient } from '@prisma/client';

// Initialize Prisma client with logging in development mode
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

// Helper function to check DB connection
async function checkDatabaseConnection() {
  try {
    // Execute a simple query to check connection
    await prisma.$queryRaw`SELECT 1`;
    console.log('Database connection successful');
    return true;
  } catch (error) {
    console.error('Database connection failed:', error);
    return false;
  }
}

// Initialize database with default settings if needed
async function initializeDatabase() {
  try {
    // Check if we have a settings record
    const settingsCount = await prisma.settings.count();
    
    // If no settings exist, create default ones
    if (settingsCount === 0) {
      await prisma.settings.createMany({
        data: [
          { key: 'siteName', value: 'VOC2GO', type: 'string' },
          { key: 'siteDescription', value: 'Learn languages word by word, story by story', type: 'string' },
          { key: 'primaryColor', value: '#5C37C7', type: 'string' },
          { key: 'primaryDarkColor', value: '#2D0051', type: 'string' },
          { key: 'accentColor', value: '#44d1c6', type: 'string' },
          { key: 'ctaColor', value: '#FF7518', type: 'string' },
          { key: 'contactEmail', value: 'hello@voc2go.com', type: 'string' }
        ]
      });
      console.log('Created default settings');
    }
    
    // Check if we have any admin user
    const userCount = await prisma.user.count();
    
    // If no users exist, create a default admin (in a real app, this would be more secure)
    if (userCount === 0) {
      const bcrypt = await import('bcrypt');
      const salt = await bcrypt.default.genSalt(10);
      const hashedPassword = await bcrypt.default.hash('admin123', salt);
      
      await prisma.user.create({
        data: {
          email: 'admin@voc2go.com',
          name: 'Admin User',
          password: hashedPassword,
          role: 'ADMIN'
        }
      });
      console.log('Created default admin user (admin@voc2go.com / admin123)');
    }
    
    return true;
  } catch (error) {
    console.error('Database initialization failed:', error);
    return false;
  }
}

export { prisma, checkDatabaseConnection, initializeDatabase };