import { pgTable, serial, text, varchar, timestamp, real, unique, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: text("name"),
  password: text("password").notNull(),
  role: text("role", { enum: ["USER", "ADMIN"] }).default("USER").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Settings model
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  type: varchar("type", { length: 50 }).default("string").notNull()
});

// Admin Settings model for configurable login
export const adminSettings = pgTable("admin_settings", {
  id: serial("id").primaryKey(),
  loginName: varchar("login_name", { length: 255 }).notNull().default("admin"),
  passwordHash: text("password_hash").notNull(),
  sessionToken: text("session_token"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Content Sections for mirroring site content
export const contentSections = pgTable("content_sections", {
  id: serial("id").primaryKey(),
  sectionId: varchar("section_id", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  language: varchar("language", { length: 10 }).notNull().default("en"),
  lastModified: timestamp("last_modified").defaultNow().notNull(),
  modifiedBy: varchar("modified_by", { length: 255 }).notNull().default("admin"),
});

// Media model
export const mediaItems = pgTable("media_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  path: text("path").notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Campaign model
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  platform: varchar("platform", { length: 50 }).notNull(), // "indiegogo", "facebook", "instagram"
  status: varchar("status", { length: 50 }).notNull(), // "draft", "active", "completed"
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  goal: real("goal"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Contact model
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: text("name"),
  source: varchar("source", { length: 100 }), // Where they came from
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Campaign Contact model (junction table)
export const campaignContacts = pgTable("campaign_contacts", {
  id: serial("id").primaryKey(),
  campaignId: serial("campaign_id").references(() => campaigns.id).notNull(),
  contactId: serial("contact_id").references(() => contacts.id).notNull(),
  status: varchar("status", { length: 50 }).notNull(), // "subscribed", "unsubscribed", "bounced"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
}, (table) => {
  return {
    uniq: unique().on(table.campaignId, table.contactId)
  };
});

// Subscriber model for newsletter subscriptions
export const subscribers = pgTable("subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: text("name"),
  source: varchar("source", { length: 100 }).notNull().default("newsletter"), // "newsletter", "campaign", "mission_support", "hero_section", "why_choose"
  language: varchar("language", { length: 10 }).default("en").notNull(), // For bilingual content preference
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Feedback model for user feedback collection
export const feedbacks = pgTable("feedbacks", {
  id: serial("id").primaryKey(),
  name: text("name").default(""),
  email: varchar("email", { length: 255 }).notNull(),
  message: text("message").notNull(),
  rating: real("rating"),
  source: varchar("source", { length: 100 }).notNull().default("feedback_form"), // "feedback_form", "contact_form"
  language: varchar("language", { length: 10 }).default("en").notNull(),
  status: varchar("status", { length: 50 }).notNull().default("new"), // "new", "reviewed", "responded"
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Team members social media links
export const teamMemberSocials = pgTable("team_member_socials", {
  id: serial("id").primaryKey(),
  memberId: varchar("member_id", { length: 255 }).notNull(), // e.g., "member-1", "member-2"
  instagram: text("instagram"),
  facebook: text("facebook"),
  linkedin: text("linkedin"),
  behance: text("behance"),
  kofi: text("kofi"),
  pinterest: text("pinterest"),
  twitter: text("twitter"),
  website: text("website"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

// Zod schemas for validation
export const insertTeamMemberSocialsSchema = createInsertSchema(teamMemberSocials).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export type InsertTeamMemberSocials = z.infer<typeof insertTeamMemberSocialsSchema>;
export type SelectTeamMemberSocials = typeof teamMemberSocials.$inferSelect;

// Define relations
export const campaignsRelations = relations(campaigns, ({ many }) => ({
  campaignContacts: many(campaignContacts)
}));

export const contactsRelations = relations(contacts, ({ many }) => ({
  campaignContacts: many(campaignContacts)
}));

export const campaignContactsRelations = relations(campaignContacts, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [campaignContacts.campaignId],
    references: [campaigns.id]
  }),
  contact: one(contacts, {
    fields: [campaignContacts.contactId],
    references: [contacts.id]
  })
}));

// Define insert schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true, 
  createdAt: true, 
  updatedAt: true
});

export const insertSettingSchema = createInsertSchema(settings).omit({ 
  id: true 
});

export const insertMediaItemSchema = createInsertSchema(mediaItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertCampaignContactSchema = createInsertSchema(campaignContacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertSubscriberSchema = createInsertSchema(subscribers).pick({
  email: true,
  name: true,
  source: true,
  language: true
});

export const insertFeedbackSchema = createInsertSchema(feedbacks).pick({
  name: true,
  email: true,
  message: true,
  rating: true,
  source: true,
  language: true
});

export const insertAdminSettingsSchema = createInsertSchema(adminSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertContentSectionSchema = createInsertSchema(contentSections).omit({
  id: true,
  lastModified: true
});

// Define types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;

export type InsertMediaItem = z.infer<typeof insertMediaItemSchema>;
export type MediaItem = typeof mediaItems.$inferSelect;

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

export type InsertContact = z.infer<typeof insertContactSchema>;
export type Contact = typeof contacts.$inferSelect;

export type InsertCampaignContact = z.infer<typeof insertCampaignContactSchema>;
export type CampaignContact = typeof campaignContacts.$inferSelect;

export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;
export type Subscriber = typeof subscribers.$inferSelect;

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedbacks.$inferSelect;

export type InsertAdminSettings = z.infer<typeof insertAdminSettingsSchema>;
export type AdminSettings = typeof adminSettings.$inferSelect;

export type InsertContentSection = z.infer<typeof insertContentSectionSchema>;
export type ContentSection = typeof contentSections.$inferSelect;