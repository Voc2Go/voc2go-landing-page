# Security Documentation

## JWT Token Management

### Overview
The application uses JWT (JSON Web Tokens) for authentication and authorization. A secure JWT utility has been implemented to prevent security vulnerabilities.

### Security Features

#### 1. Secure JWT Secret Management
- **Location**: `server/utils/jwt.js`
- **Purpose**: Centralized JWT secret validation and token operations
- **Security**: Prevents hardcoded secrets, enforces environment variable usage in production

#### 2. Token Operations
```javascript
// Create token with secure secret validation
const token = createToken({ id: user.id, email: user.email });

// Verify token with secure secret validation
const decoded = verifyToken(token);
```

#### 3. Environment Variables
Required environment variables for secure operation:
```
JWT_SECRET=your_secure_jwt_secret_here
NODE_ENV=production
```

### Security Best Practices

1. **Production Requirements**:
   - JWT_SECRET must be set in production environment
   - Uses cryptographically strong secret (minimum 32 characters recommended)

2. **Development Fallback**:
   - Development environments use fallback secret with clear naming
   - Fallback: `dev_jwt_secret_change_in_production`

3. **Token Expiration**:
   - Default expiration: 24 hours
   - Configurable through token creation options

### Authentication Flow

1. **Registration/Login**: 
   - User provides credentials
   - Server validates and creates JWT token
   - Token stored in httpOnly cookie

2. **Protected Routes**:
   - Middleware extracts token from cookie or Authorization header
   - Token verified using secure JWT utility
   - User information attached to request object

3. **Admin Protection**:
   - Additional middleware checks user role
   - Database verification for admin privileges

### Security Vulnerabilities Addressed

- **Fixed**: Hardcoded JWT secrets in authentication routes
- **Fixed**: Inconsistent secret usage across middleware and routes
- **Added**: Production environment validation
- **Added**: Centralized token management

## Error Handling

### Memory Leak Prevention
- **Location**: `client/src/App.tsx`
- **Fix**: Proper cleanup of setTimeout in useEffect
- **Impact**: Prevents memory accumulation during component lifecycle

### Race Condition Prevention  
- **Location**: `client/src/components/PlanComparisonSection.tsx`
- **Fix**: Proper interval cleanup and null checks
- **Impact**: Prevents memory leaks and timing issues in animations

### API Error Handling
- **Location**: `client/src/components/AdminPanel.tsx`
- **Enhancement**: Comprehensive error handling for all API operations
- **Impact**: Better user experience and debugging capabilities

## Environment Setup

### Required Files
- `.env`: Contains actual secrets (not committed to repository)
- `.env.example`: Template for environment variables (committed to repository)

### Environment Variables
```
# Database
DATABASE_URL=your_database_connection_string

# JWT Authentication
JWT_SECRET=your_secure_jwt_secret_minimum_32_characters

# Node Environment
NODE_ENV=development|production

# Optional: API Keys for external services
OPENAI_API_KEY=your_openai_api_key_if_needed
```

## Development Guidelines

1. **Never commit actual secrets** - Use .env.example as template
2. **Test authentication flows** - Verify token creation and validation
3. **Monitor memory usage** - Check for proper cleanup in useEffect hooks
4. **Handle API errors** - Implement proper error boundaries and user feedback

## Security Checklist

- [ ] JWT_SECRET is set in production environment
- [ ] All authentication routes use secure JWT utility
- [ ] Middleware properly validates tokens
- [ ] Admin routes have proper authorization checks
- [ ] Memory leaks are prevented with proper cleanup
- [ ] Error handling provides appropriate user feedback
- [ ] Environment variables are properly configured