import React from 'react';
import { useLanguage } from '../context/LanguageContext';

interface NewsletterSectionProps {
  newsletterEmail: string;
  setNewsletterEmail: (email: string) => void;
  newsletterSubscribed: boolean;
  handleNewsletterSubscribe: (e: React.FormEvent) => void;
}

const NewsletterSection: React.FC<NewsletterSectionProps> = ({
  newsletterEmail,
  setNewsletterEmail,
  newsletterSubscribed,
  handleNewsletterSubscribe
}) => {
  const { language } = useLanguage();
  
  return (
    <div style={{ 
      background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
      padding: "40px 20px",
      minHeight: "300px",
      width: "100%"
    }}>
      <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ color: "white", textAlign: "center" }}>
          <h2>{language === 'en' ? 'Stay Updated' : 'Maradj naprakész'}</h2>
          <p>{language === 'en' ? 'Subscribe to our newsletter for campaign updates' : 'Iratkozz fel hírlevelünkre a kampány frissítéseiért'}</p>
          <form onSubmit={handleNewsletterSubscribe} style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
            <input 
              type="email" 
              placeholder={language === 'en' ? 'Enter your email' : 'Add meg az email címed'} 
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              required
              style={{
                padding: "12px",
                borderRadius: "8px",
                border: "1px solid rgba(255,255,255,0.3)",
                background: "rgba(255,255,255,0.1)",
                color: "white",
                width: "300px"
              }}
            />
            <button 
              type="submit"
              style={{
                padding: "12px 24px",
                background: "#F7941D",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer"
              }}
            >
              {newsletterSubscribed ? 
                (language === 'en' ? 'Subscribed!' : 'Feliratkozva!') : 
                (language === 'en' ? 'Subscribe' : 'Feliratkozás')
              }
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default NewsletterSection;