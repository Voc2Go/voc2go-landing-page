import React, { useState, useEffect, useRef } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { LanguageProvider, useLanguage } from "./context/LanguageContext";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import FeaturesSection from "./components/FeaturesSection";

import PlanComparisonSection from "./components/PlanComparisonSection";
import VocFutureSection from "./components/VocFutureSection";
import LearnersSection from "./components/LearnersSection";
import PayAsYouGoSection from "./components/PayAsYouGoSection";
import PersonasSection from "./components/PersonasSection";

import ProjectTeamSection from "./components/ProjectTeamSection";

import CampaignSection from "./components/CampaignSection";
import RoadmapSection from "./components/RoadmapSection";
import FeedbackSection from "./components/FeedbackSection";
import WhyChooseSection from "./components/WhyChooseSection";
import TeamSection from "./components/TeamSection";
import TestimonialsSection from "./components/TestimonialsSection";
import CountdownTimer from "./components/CountdownTimer";
import ComparisonTableSection from "./components/ComparisonTableSection";
import FAQSection from "./components/FAQSection";
import SupportSection from "./components/SupportSection";
import CampaignButtonSection from "./components/CampaignButtonSection";
import MobileTestPage from "./components/MobileTestPage";
import AdminTestPanel from "./components/AdminTestPanel";
import TestSummary from "./components/TestSummary";
import VisionSection from "./components/VisionSection";
import Footer from "./components/Footer";
import AdminOverlay from "./components/AdminOverlay";
import AdminLogin from "./components/AdminLogin";
import AdminPanel from "./components/AdminPanel";
import NewsletterSection from "./components/NewsletterSection";
import ErrorBoundary from "./components/ErrorBoundary";

// Import styles
import "./styles/main.css";
import "./styles/admin-overlay.css";

function AppContent() {
  const { language } = useLanguage();
  const [showAdmin, setShowAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminLoginLoading, setAdminLoginLoading] = useState(false);
  const [adminLoginError, setAdminLoginError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState("home");
  const [showMobileTest, setShowMobileTest] = useState(false);
  const [showAdminTest, setShowAdminTest] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  
  // Utility function to ensure scroll-to-top works on all devices
  const scrollToTop = () => {
    // Multiple methods to ensure compatibility across all browsers and devices
    if (window.scrollTo) {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    
    // Fallback for older browsers
    if (document.documentElement) {
      document.documentElement.scrollTop = 0;
    }
    
    // Additional fallback for mobile devices
    if (document.body) {
      document.body.scrollTop = 0;
    }
  };
  
  const handleOpenAdmin = () => {
    setShowAdminLogin(true);
  };

  const handleCloseAdminLogin = () => {
    setShowAdminLogin(false);
    setAdminLoginError(null);
  };

  const handleAdminLogin = async (credentials: { loginName: string; password: string }) => {
    setAdminLoginLoading(true);
    setAdminLoginError(null);
    
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });
      
      if (response.ok) {
        setShowAdminLogin(false);
        setShowAdminPanel(true);
        setAdminLoginError(null);
      } else {
        const errorData = await response.json();
        setAdminLoginError(errorData.error || 'Login failed');
      }
    } catch (error) {
      setAdminLoginError('Network error. Please try again.');
    } finally {
      setAdminLoginLoading(false);
    }
  };

  const handleAdminLoginSuccess = () => {
    setShowAdminLogin(false);
    setShowAdminPanel(true);
    setAdminLoginError(null);
  };

  const handleCloseAdminPanel = () => {
    setShowAdminPanel(false);
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.location.hash = page;
    
    // Clear any existing timeout before setting new one
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    // Scroll to top when navigating programmatically
    timeoutRef.current = setTimeout(() => {
      scrollToTop();
      timeoutRef.current = null;
    }, 50);
  };



  useEffect(() => {
    
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1) || "home";
      setCurrentPage(hash);
      
      // Clear any existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      // Scroll to top when page changes - immediate scroll for better UX
      // Use setTimeout to ensure page content has rendered
      timeoutRef.current = setTimeout(() => {
        scrollToTop();
        timeoutRef.current = null;
      }, 50);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'm') {
        e.preventDefault();
        setShowMobileTest(true);
      }
      if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        setShowAdminLogin(true);
      }
    };
    
    // Set initial page based on hash
    handleHashChange();
    
    // Listen for hash changes and custom navigation events
    const handleNavigate = (e: CustomEvent) => {
      const section = e.detail.section || e.detail;
      setCurrentPage(section);
      window.location.hash = section;
      
      // Clear any existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      // Scroll to top when navigating via custom events
      timeoutRef.current = setTimeout(() => {
        scrollToTop();
        timeoutRef.current = null;
      }, 50);
    };
    
    window.addEventListener("hashchange", handleHashChange);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("navigate", handleNavigate as EventListener);
    
    return () => {
      // Clear timeout on cleanup
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      window.removeEventListener("hashchange", handleHashChange);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("navigate", handleNavigate as EventListener);
    };
  }, []);
  
  return (
    <ErrorBoundary>
      <div className="voc2go-app" lang={language}>
        <Header />
        <main>
        {/* HOME menu content */}
        {(currentPage === "home") && (
              <>
                <HeroSection />
                <WhyChooseSection />
                <TeamSection />
                <TestimonialsSection />
                <ComparisonTableSection />
                <FAQSection />
                <PlanComparisonSection />
                <VocFutureSection />
                <CampaignButtonSection />
                
                {/* Newsletter section at bottom of home page */}
                <div style={{ 
                  background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
                  padding: "40px 20px",
                  minHeight: "300px",
                  width: "100%"
                }}>
                  <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
                    <NewsletterSection />
                  </div>
                </div>
              </>
            )}
            
            {/* LEARNERS menu content */}
            {(currentPage === "learners") && (
              <>
                <LearnersSection />
                
                {/* Newsletter section at bottom of learners page */}
                <div style={{ 
                  background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
                  padding: "40px 20px",
                  minHeight: "300px",
                  width: "100%"
                }}>
                  <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
                    <NewsletterSection />
                  </div>
                </div>
              </>
            )}
            
            {/* SUPPORTERS menu content */}
            {(currentPage === "supporters") && (
              <>
                <VisionSection />

                <CampaignSection />
                <SupportSection />
                
                {/* Newsletter section at bottom of supporters page */}
                <div style={{ 
                  background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
                  padding: "40px 20px",
                  minHeight: "300px",
                  width: "100%"
                }}>
                  <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
                    <NewsletterSection />
                  </div>
                </div>
              </>
            )}
            
            {/* PROJECT menu content */}
            {(currentPage === "project") && (
              <>
                <ProjectTeamSection />
                
                {/* Newsletter section at bottom of project page */}
                <div style={{ 
                  background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
                  padding: "40px 20px",
                  minHeight: "300px",
                  width: "100%"
                }}>
                  <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
                    <NewsletterSection />
                  </div>
                </div>
              </>
            )}
            
            {/* CONTACT menu content */}
            {(currentPage === "contact") && (
              <>
                <FeedbackSection />
                
                {/* Newsletter section at bottom of contact page */}
                <div style={{ 
                  background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
                  padding: "40px 20px",
                  minHeight: "300px",
                  width: "100%"
                }}>
                  <div className="container" style={{ maxWidth: "1200px", margin: "0 auto" }}>
                    <NewsletterSection />
                  </div>
                </div>
              </>
            )}
      </main>
      <Footer onAdminClick={handleOpenAdmin} />
      
      {/* Admin overlay appears when showAdmin is true */}
      {showAdmin && <AdminOverlay onClose={() => setShowAdmin(false)} />}
      
      {/* Mobile Test Page */}
      {showMobileTest && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'white',
          zIndex: 10000,
          overflow: 'auto'
        }}>
          <div style={{
            position: 'sticky',
            top: 0,
            background: 'white',
            padding: '10px 20px',
            borderBottom: '1px solid #ddd',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <h3>Mobile Responsivity Test</h3>
            <button 
              onClick={() => setShowMobileTest(false)}
              style={{
                background: '#f44336',
                color: 'white',
                border: 'none',
                padding: '8px 16px',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Close
            </button>
          </div>
          <MobileTestPage />
        </div>
      )}

      {/* Admin Test Panel */}
      {showAdminTest && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          background: 'white',
          zIndex: 10000,
          overflow: 'auto'
        }}>
          <div style={{
            position: 'sticky',
            top: 0,
            background: 'white',
            padding: '10px 20px',
            borderBottom: '1px solid #ddd',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <h3>Admin System Test</h3>
            <button 
              onClick={() => setShowAdminTest(false)}
              style={{
                background: '#f44336',
                color: 'white',
                border: 'none',
                padding: '8px 16px',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Close
            </button>
          </div>
          <AdminTestPanel />
        </div>
      )}

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <AdminLogin 
          onClose={handleCloseAdminLogin}
          onLogin={handleAdminLogin}
          isLoading={adminLoginLoading}
          error={adminLoginError || undefined}
        />
      )}

      {/* Admin Panel */}
      {showAdminPanel && (
        <AdminPanel onClose={handleCloseAdminPanel} />
      )}

      {/* Development Testing Tools */}
      {process.env.NODE_ENV === 'development' && <TestSummary />}
      </div>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;