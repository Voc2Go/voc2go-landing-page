import { useState, useEffect } from 'react';

interface AdaptiveCardConfig {
  padding: number;
  fontSize: {
    title: string;
    body: string;
    small: string;
  };
  iconSize: number;
  spacing: number;
  minHeight: number;
  contentDensity: 'compact' | 'normal' | 'spacious';
  itemsPerRow: number;
  borderRadius: number;
}

interface ScreenMetrics {
  width: number;
  height: number;
  aspectRatio: number;
  pixelDensity: number;
  availableSpace: number;
}

export const useAdaptiveCardSize = () => {
  const [screenMetrics, setScreenMetrics] = useState<ScreenMetrics>({
    width: window.innerWidth,
    height: window.innerHeight,
    aspectRatio: window.innerWidth / window.innerHeight,
    pixelDensity: window.devicePixelRatio || 1,
    availableSpace: window.innerWidth * window.innerHeight
  });

  const [cardConfig, setCardConfig] = useState<AdaptiveCardConfig>({
    padding: 20,
    fontSize: { title: '1.2rem', body: '1rem', small: '0.9rem' },
    iconSize: 24,
    spacing: 16,
    minHeight: 200,
    contentDensity: 'normal',
    itemsPerRow: 3,
    borderRadius: 12
  });

  useEffect(() => {
    const updateScreenMetrics = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const aspectRatio = width / height;
      const pixelDensity = window.devicePixelRatio || 1;
      const availableSpace = width * height;

      setScreenMetrics({
        width,
        height,
        aspectRatio,
        pixelDensity,
        availableSpace
      });

      // Calculate adaptive card configuration based on screen metrics
      const newConfig = calculateAdaptiveConfig({
        width,
        height,
        aspectRatio,
        pixelDensity,
        availableSpace
      });

      setCardConfig(newConfig);
    };

    updateScreenMetrics();
    window.addEventListener('resize', updateScreenMetrics);
    window.addEventListener('orientationchange', updateScreenMetrics);

    return () => {
      window.removeEventListener('resize', updateScreenMetrics);
      window.removeEventListener('orientationchange', updateScreenMetrics);
    };
  }, []);

  const calculateAdaptiveConfig = (metrics: ScreenMetrics): AdaptiveCardConfig => {
    const { width, height, aspectRatio, pixelDensity, availableSpace } = metrics;

    // Base configuration for different screen categories
    let config: AdaptiveCardConfig;

    if (width >= 1920 && availableSpace >= 2073600) {
      // Ultra-wide and large displays (4K, ultrawide monitors)
      config = {
        padding: 40,
        fontSize: { title: '1.8rem', body: '1.2rem', small: '1rem' },
        iconSize: 36,
        spacing: 32,
        minHeight: 320,
        contentDensity: 'spacious',
        itemsPerRow: 4,
        borderRadius: 20
      };
    } else if (width >= 1440 && availableSpace >= 1440000) {
      // Large desktop displays
      config = {
        padding: 35,
        fontSize: { title: '1.6rem', body: '1.15rem', small: '0.95rem' },
        iconSize: 32,
        spacing: 28,
        minHeight: 280,
        contentDensity: 'spacious',
        itemsPerRow: 3,
        borderRadius: 18
      };
    } else if (width >= 1200 && availableSpace >= 1000000) {
      // Standard desktop
      config = {
        padding: 30,
        fontSize: { title: '1.4rem', body: '1.1rem', small: '0.9rem' },
        iconSize: 28,
        spacing: 24,
        minHeight: 250,
        contentDensity: 'normal',
        itemsPerRow: 3,
        borderRadius: 16
      };
    } else if (width >= 768 && availableSpace >= 500000) {
      // Tablet landscape/small desktop
      config = {
        padding: 24,
        fontSize: { title: '1.3rem', body: '1rem', small: '0.85rem' },
        iconSize: 24,
        spacing: 20,
        minHeight: 220,
        contentDensity: 'normal',
        itemsPerRow: 2,
        borderRadius: 14
      };
    } else if (width >= 480 && availableSpace >= 200000) {
      // Mobile landscape/tablet portrait
      config = {
        padding: 20,
        fontSize: { title: '1.2rem', body: '0.95rem', small: '0.8rem' },
        iconSize: 22,
        spacing: 16,
        minHeight: 200,
        contentDensity: 'compact',
        itemsPerRow: 2,
        borderRadius: 12
      };
    } else {
      // Small mobile devices
      config = {
        padding: 16,
        fontSize: { title: '1.1rem', body: '0.9rem', small: '0.75rem' },
        iconSize: 20,
        spacing: 12,
        minHeight: 180,
        contentDensity: 'compact',
        itemsPerRow: 1,
        borderRadius: 10
      };
    }

    // Adjust for pixel density
    if (pixelDensity >= 2) {
      config.fontSize = {
        title: `calc(${config.fontSize.title} * 0.9)`,
        body: `calc(${config.fontSize.body} * 0.9)`,
        small: `calc(${config.fontSize.small} * 0.9)`
      };
    }

    // Adjust for extreme aspect ratios
    if (aspectRatio > 2.5) {
      // Very wide screens - increase items per row
      config.itemsPerRow = Math.min(config.itemsPerRow + 1, 5);
      config.contentDensity = 'compact';
    } else if (aspectRatio < 0.7) {
      // Very tall screens - reduce items per row
      config.itemsPerRow = Math.max(config.itemsPerRow - 1, 1);
      config.contentDensity = 'spacious';
    }

    return config;
  };

  const getCardStyle = (cardType: 'vision' | 'persona' | 'reward' | 'generic' = 'generic') => {
    const baseStyle = {
      padding: `${cardConfig.padding}px`,
      borderRadius: `${cardConfig.borderRadius}px`,
      minHeight: `${cardConfig.minHeight}px`,
      fontSize: cardConfig.fontSize.body,
      gap: `${cardConfig.spacing}px`
    };

    // Card type specific adjustments
    switch (cardType) {
      case 'vision':
        return {
          ...baseStyle,
          minHeight: `${cardConfig.minHeight + 50}px`,
          padding: `${cardConfig.padding + 5}px`
        };
      case 'persona':
        return {
          ...baseStyle,
          minHeight: screenMetrics.width < 768 ? '300px' : `${cardConfig.minHeight + 100}px`,
          aspectRatio: cardConfig.contentDensity === 'compact' ? '1.2' : '1'
        };
      case 'reward':
        return {
          ...baseStyle,
          minHeight: `${cardConfig.minHeight + 80}px`,
          maxWidth: screenMetrics.width < 768 ? '100%' : '400px'
        };
      default:
        return baseStyle;
    }
  };

  const getTitleStyle = () => ({
    fontSize: cardConfig.fontSize.title,
    marginBottom: `${cardConfig.spacing}px`
  });

  const getIconStyle = () => ({
    width: `${cardConfig.iconSize}px`,
    height: `${cardConfig.iconSize}px`
  });

  const getGridStyle = () => ({
    gridTemplateColumns: `repeat(auto-fit, minmax(${
      screenMetrics.width < 768 ? '280px' : '320px'
    }, 1fr))`,
    gap: `${cardConfig.spacing * 1.5}px`,
    maxWidth: '100%'
  });

  const getContentDensityClass = () => `content-density-${cardConfig.contentDensity}`;

  return {
    screenMetrics,
    cardConfig,
    getCardStyle,
    getTitleStyle,
    getIconStyle,
    getGridStyle,
    getContentDensityClass
  };
};