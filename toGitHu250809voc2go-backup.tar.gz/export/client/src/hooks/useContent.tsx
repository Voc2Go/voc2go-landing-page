import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useLanguage } from "../context/LanguageContext";
import { useEffect } from "react";

export interface ContentSection {
  id: number;
  sectionId: string;
  title: string;
  content: string;
  language: string;
  lastModified: string;
  modifiedBy: string;
}

export function useContent(sectionId?: string) {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  
  // Listen for content update events from admin panel
  useEffect(() => {
    const handleContentUpdate = (event: CustomEvent) => {
      console.log('Content update event received:', event.detail);
      // Only invalidate cache, let React Query handle refetch naturally
      const eventLanguage = event.detail?.language;
      if (eventLanguage === 'all') {
        // Invalidate all content queries - no forced refetch to prevent rate limiting
        queryClient.invalidateQueries({ queryKey: ['/api/content'] });
        console.log('Invalidated all content queries');
      } else if (eventLanguage) {
        queryClient.invalidateQueries({ queryKey: ['/api/content', eventLanguage] });
        console.log(`Invalidated content queries for language: ${eventLanguage}`);
        // Also invalidate current language if different
        if (eventLanguage !== language) {
          queryClient.invalidateQueries({ queryKey: ['/api/content', language] });
          console.log(`Also invalidated current language: ${language}`);
        }
      } else {
        // Invalidate all content queries as fallback
        queryClient.invalidateQueries({ queryKey: ['/api/content'] });
        console.log('Invalidated all content queries (fallback)');
      }
    };
    
    window.addEventListener('contentUpdated', handleContentUpdate as EventListener);
    return () => window.removeEventListener('contentUpdated', handleContentUpdate as EventListener);
  }, [queryClient, language]);
  
  const { data: sections, isLoading, error } = useQuery<ContentSection[]>({
    queryKey: ['/api/content', language],
    queryFn: async () => {
      const response = await fetch(`/api/content?language=${language}`);
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error('Too many requests. Please try again in a moment.');
        }
        throw new Error('Failed to fetch content');
      }
      const data = await response.json();
      console.log(`Content fetched for ${language}:`, data.sections?.length, 'sections');
      return data.sections || [];
    },
    staleTime: 30000, // Cache for 30 seconds to reduce API calls
    gcTime: 300000, // Keep in cache for 5 minutes
  });

  const getContent = (id: string): ContentSection | undefined => {
    return sections?.find((section: ContentSection) => section.sectionId === id);
  };

  const getContentText = (id: string, fallback: string = ''): string => {
    const section = getContent(id);
    // If content exists and is not empty, return it
    if (section?.content && section.content.trim().length > 0) {
      return section.content;
    }
    // If content is empty/null, return fallback
    return fallback;
  };

  const getContentTitle = (id: string, fallback: string = ''): string => {
    const section = getContent(id);
    return section?.title || fallback;
  };

  if (sectionId) {
    const section = getContent(sectionId);
    return {
      section,
      isLoading,
      error,
      getContent,
      getContentText,
      getContentTitle
    };
  }

  return {
    sections,
    isLoading,
    error,
    getContent,
    getContentText,
    getContentTitle
  };
}