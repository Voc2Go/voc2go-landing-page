import React, { useState, useEffect } from 'react';
import { Instagram, Facebook, Linkedin, Globe, Heart } from 'lucide-react';

interface SocialLinks {
  instagram?: string;
  facebook?: string;
  linkedin?: string;
  behance?: string;
  kofi?: string;
}

interface TeamMemberSocialsProps {
  memberId: string;
  className?: string;
}

const socialPlatforms = [
  { key: 'instagram', icon: Instagram, color: '#E4405F' },
  { key: 'facebook', icon: Facebook, color: '#1877F2' },
  { key: 'linkedin', icon: Linkedin, color: '#0A66C2' },
  { key: 'behance', icon: Globe, color: '#1769FF' },
  { key: 'kofi', icon: Heart, color: '#FF5E5B' }
];

export default function TeamMemberSocials({ memberId, className = '' }: TeamMemberSocialsProps) {
  const [socialLinks, setSocialLinks] = useState<SocialLinks>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSocialLinks();
  }, [memberId]);

  const loadSocialLinks = async () => {
    try {
      const response = await fetch(`/api/team-socials/${memberId}`);
      const data = await response.json();
      
      if (response.ok && data.socials) {
        setSocialLinks(data.socials);
      }
    } catch (err) {
      console.error('Error loading social links:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSocialClick = (url: string) => {
    // Ensure URL has proper protocol
    let finalUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      finalUrl = 'https://' + url;
    }
    window.open(finalUrl, '_blank', 'noopener,noreferrer');
  };

  if (loading) {
    return null; // Don't show anything while loading
  }

  // Filter out platforms that don't have links
  const activePlatforms = socialPlatforms.filter(platform => {
    const link = socialLinks[platform.key as keyof SocialLinks];
    return link && link.trim().length > 0;
  });

  // Don't render if no social links are available
  if (activePlatforms.length === 0) {
    return null;
  }

  return (
    <div className="flex justify-center items-center mt-6 w-full">
      <div className="flex gap-6">
        {activePlatforms.map(({ key, icon: Icon, color }) => {
          const link = socialLinks[key as keyof SocialLinks];
          return (
            <button
              key={key}
              onClick={() => handleSocialClick(link!)}
              className="w-12 h-12 rounded-full flex items-center justify-center transition-transform duration-200 hover:scale-110"
              style={{ 
                backgroundColor: color,
                color: 'white',
                border: 'none',
                boxShadow: 'none',
                outline: 'none'
              }}
              title={`Visit ${key} profile`}
              aria-label={`Visit ${key} profile`}
            >
              <Icon size={20} />
            </button>
          );
        })}
      </div>
    </div>
  );
}