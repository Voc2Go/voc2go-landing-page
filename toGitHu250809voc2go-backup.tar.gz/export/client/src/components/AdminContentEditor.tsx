import React, { useState, useEffect } from 'react';
import { useLanguage } from "../context/LanguageContext";

interface ContentSection {
  id: string;
  title: string;
  description?: string;
  menuCategory: string;
  editableItems?: { [key: string]: string };
}

interface AdminContentEditorProps {
  onSave: (data: any) => void;
  onCancel: () => void;
}

const AdminContentEditor: React.FC<AdminContentEditorProps> = ({ onSave, onCancel }) => {
  const { t, language } = useLanguage();
  const [activeLanguage, setActiveLanguage] = useState<'en' | 'hu'>(language as 'en' | 'hu');
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [activeMenu, setActiveMenu] = useState<string>("HOME");
  const [menuExpanded, setMenuExpanded] = useState<{[key: string]: boolean}>({
    HOME: true,
    LEARNERS: false,
    SUPPORTERS: false,
    PROJECT: false,
    CONTACT: false
  });
  
  // Sync with global language setting
  useEffect(() => {
    setActiveLanguage(language as 'en' | 'hu');
  }, [language]);
  
  // This would be loaded from API in a real implementation
  const [contentSections, setContentSections] = useState<{[key: string]: ContentSection[]}>({
    en: [
      // Home Menu
      {
        id: 'hero',
        title: 'Hero Section',
        menuCategory: 'HOME',
        editableItems: {
          heading: 'Learn Languages on the Go',
          subheading: 'VOC2GO makes vocabulary acquisition fun, easy, and effective with AI-powered learning techniques.',
          buttonText1: 'Join Our Campaign',
          buttonText2: 'Learn More'
        }
      },
      {
        id: 'features',
        title: 'Features Section',
        editableItems: {
          heading: 'Why Choose VOC2GO?',
          subheading: 'Discover how our app makes language learning effective and enjoyable',
          feature1Title: 'AI-Powered Learning',
          feature1Text: 'Our AI adapts to your learning style and creates personalized study plans',
          feature2Title: 'Real-Life Contexts',
          feature2Text: 'Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios',
          feature3Title: 'Spaced Repetition',
          feature3Text: 'Our scientifically-proven system ensures you remember words for the long term',
          feature4Title: 'Progress Tracking',
          feature4Text: 'Track your learning journey with detailed statistics and achievements'
        }
      },
      {
        id: 'screenshots',
        title: 'Screenshots Section',
        editableItems: {
          heading: 'App Screenshots',
          subheading: 'Take a sneak peek at VOC2GO\'s intuitive interface',
          screenshot1Title: 'Café Scene',
          screenshot1Text: 'Learn vocabulary in a virtual café environment',
          screenshot2Title: 'Library Mode',
          screenshot2Text: 'Browse through categories and learn at your own pace',
          screenshot3Title: 'Cooking Context',
          screenshot3Text: 'Master kitchen-related terms through interactive lessons'
        }
      },
      {
        id: 'whyChoose',
        title: 'Why Choose VOC2GO Section',
        editableItems: {
          heading: 'Why Choose VOC2GO?',
          subheading: 'We\'ve reimagined language learning from the ground up',
          point1Title: 'Personal Vocabulary Building',
          point1Text: 'Words YOU want to learn, not what an app decides',
          point2Title: 'Engaging Story-Based Learning',
          point2Text: 'Remember words through context, not flash cards',
          point3Title: 'Real Conversations Practice',
          point3Text: 'Realistic dialogues that prepare you for actual use',
          point4Title: 'Adaptive Learning System',
          point4Text: 'Our AI adjusts to your learning style and pace',
          targetAudienceTitle: 'Who is VOC2GO for?',
          audienceText: 'VOC2GO is perfect for busy professionals, students, travelers, and anyone who wants to learn a new language efficiently.'
        }
      },
      
      // Learners Menu
      {
        id: 'learners',
        title: 'Learners Section',
        editableItems: {
          heading: 'For Language Learners',
          subheading: 'VOC2GO is designed with your learning needs in mind',
          benefitsTitle: 'Benefits for Learners',
          benefit1: 'Personalized vocabulary lists based on your interests',
          benefit2: 'Engaging story-based approach that makes learning memorable',
          benefit3: 'Adaptive difficulty that grows with your skills',
          benefit4: 'Track your progress with detailed analytics',
          testimonialTitle: 'What Our Users Say',
          testimonial1Name: 'Sarah M.',
          testimonial1Text: 'VOC2GO has revolutionized how I learn new words. The contextual learning is brilliant!',
          testimonial2Name: 'David K.',
          testimonial2Text: 'The app\'s adaptive system feels like having a personal language tutor in my pocket.'
        }
      },
      
      // Supporters Menu
      {
        id: 'vision',
        title: 'Vision Section',
        editableItems: {
          heading: 'Reinventing English Learning with AI + User Vocabulary',
          subtitle: '',
          problem1: 'Existing apps teach words YOU DON\'T NEED',
          problem2: 'Flash cards are BORING and ineffective',
          problem3: 'Learning feels like a CHORE not a joy',
          solution1: 'VOC2GO teaches YOUR words, YOUR way',
          solution2: 'Stories make words STICK in your memory',
          solution3: 'Learning becomes FUN and ENGAGING',
          marketStats: 'Global language learning market: $17.7 billion by 2027'
        }
      },
      {
        id: 'campaign',
        title: 'Campaign Section',
        editableItems: {
          heading: 'Join Our Indiegogo Campaign',
          subheading: 'Help us bring VOC2GO to life and get exclusive rewards',
          tier1Title: 'Early Bird Access',
          tier1Price: '$15',
          tier1Description: 'Get the app before everyone else',
          tier1Limit: 'Limited to first 100 backers',
          tier2Title: 'Premium Supporter',
          tier2Price: '$30',
          tier2Description: 'Lifetime access to premium features',
          tier2Limit: 'Only 50 spots available',
          tier3Title: 'Language Bundle',
          tier3Price: '$50',
          tier3Description: 'Access to all language packs',
          tier3Limit: 'Unlimited availability'
        }
      },
      {
        id: 'support',
        title: 'Support Section',
        editableItems: {
          heading: 'Support Our Mission',
          subheading: 'Choose the plan that works for you',
          plan1Title: 'Free Plan',
          plan1Features: 'Basic features, Limited vocabulary sets, Standard learning tools',
          plan2Title: 'Premium Plan',
          plan2Price: '$5.99/month',
          plan2Features: 'Unlimited vocabulary creation, AI-powered story generation, Advanced progress tracking',
          plan3Title: 'Lifetime Access',
          plan3Price: '$99.99',
          plan3Features: 'One-time payment, All premium features forever, Priority support'
        }
      },
      
      // Project Menu
      {
        id: 'project',
        title: 'Project Team Section',
        editableItems: {
          heading: 'Meet Our Team',
          subheading: 'The passionate people behind VOC2GO',
          member1Name: 'Natasha Rogers',
          member1Role: 'Founder & CEO',
          member1Bio: 'Language learning enthusiast with 15 years of teaching experience',
          member2Name: 'David Chen',
          member2Role: 'Lead Developer',
          member2Bio: 'Full-stack developer specializing in AI and mobile applications',
          member3Name: 'Elisabeth König',
          member3Role: 'Language Expert',
          member3Bio: 'Polyglot with expertise in linguistics and language acquisition'
        }
      },
      {
        id: 'roadmap',
        title: 'Roadmap Section',
        editableItems: {
          heading: 'Development Roadmap',
          subheading: 'Our journey to create the ultimate language learning app',
          phase1Title: 'Research Phase',
          phase1Description: 'Researching effective learning methods and user needs',
          phase1Status: 'Completed',
          phase2Title: 'Development Phase',
          phase2Description: 'Building the core features and user interface',
          phase2Status: 'In Progress',
          phase3Title: 'Testing Phase',
          phase3Description: 'Beta testing with real users to improve the experience',
          phase3Status: 'Planned',
          phase4Title: 'Launch Phase',
          phase4Description: 'Official release and marketing campaign',
          phase4Status: 'Planned'
        }
      },
      
      // Contact Menu
      {
        id: 'feedback',
        title: 'Feedback Section',
        editableItems: {
          heading: 'Send Us Your Thoughts',
          subheading: 'We value your feedback to improve our app',
          namePlaceholder: 'Enter your name',
          emailPlaceholder: 'Enter your email',
          messagePlaceholder: 'Enter your message or suggestion',
          excitementQuestion: 'How excited are you about VOC2GO?',
          excitementOption1: 'Very Excited',
          excitementOption2: 'Excited',
          excitementOption3: 'Somewhat Excited',
          excitementOption4: 'Slightly Excited',
          excitementOption5: 'Not Excited',
          submitButton: 'Submit Feedback',
          thankYouMessage: 'Thank you for your feedback!'
        }
      },
      {
        id: 'footer',
        title: 'Footer Section',
        editableItems: {
          contactTitle: 'Contact',
          contactEmail: 'Email: voc2go@gmail.com',
          socialTitle: 'Follow Us',
          legalTitle: 'Legal',
          termsLink: 'Terms of Use',
          privacyLink: 'Privacy Policy',
          cookieLink: 'Cookie Policy',
          copyright: '© 2025 Voc2Go by Circular Innovation Hub. All rights reserved.'
        }
      }
    ],
    hu: [
      // Home Menu
      {
        id: 'hero',
        title: 'Kezdőlap Szekció',
        editableItems: {
          heading: 'Tanulj Nyelveket Útközben',
          subheading: 'Voc2Go szórakoztató, könnyű és hatákony szókincs tanuló társ, MI segítséggel.',
          buttonText1: 'Csatlakozz a Kampányhoz',
          buttonText2: 'Tudj Meg Többet'
        }
      },
      {
        id: 'features',
        title: 'Funkciók Szekció',
        editableItems: {
          heading: 'Miért Válaszd a VOC2GO-t?',
          subheading: 'Fedezd fel, hogyan teszi applikációnk hatékonnyá és élvezetessé a nyelvtanulást',
          feature1Title: 'AI-Alapú Tanulás',
          feature1Text: 'Az AI-nk alkalmazkodik a tanulási stílusodhoz és személyre szabott tanulási tervet készít',
          feature2Title: 'Valós Élethelyzetek',
          feature2Text: 'Tanulj szókincset értelmes környezetben, mint kávézók, könyvtárak és utazási helyzetek',
          feature3Title: 'Időzített Ismétlés',
          feature3Text: 'Tudományosan bizonyított rendszerünk biztosítja, hogy hosszú távon emlékezz a szavakra',
          feature4Title: 'Haladás Követése',
          feature4Text: 'Kövesd tanulási utadat részletes statisztikákkal és eredményekkel'
        }
      },
      {
        id: 'screenshots',
        title: 'Képernyőképek Szekció',
        editableItems: {
          heading: 'Alkalmazás Képernyőképek',
          subheading: 'Vess egy pillantást a VOC2GO intuitív felületére',
          screenshot1Title: 'Kávézó Jelenet',
          screenshot1Text: 'Tanulj szókincset egy virtuális kávézó környezetben',
          screenshot2Title: 'Könyvtár Mód',
          screenshot2Text: 'Böngéssz a kategóriák között és tanulj a saját tempódban',
          screenshot3Title: 'Főzési Környezet',
          screenshot3Text: 'Sajátítsd el a konyhával kapcsolatos kifejezéseket interaktív leckéken keresztül'
        }
      },
      {
        id: 'whyChoose',
        title: 'Miért Válaszd a VOC2GO-t Szekció',
        editableItems: {
          heading: 'Miért Válaszd a VOC2GO-t?',
          subheading: 'Újragondoltuk a nyelvtanulást az alapoktól',
          point1Title: 'Személyes Szókincsépítés',
          point1Text: 'Azokat a szavakat tanulod, amelyeket TE akarsz, nem amiket egy app eldönt',
          point2Title: 'Lebilincselő Történet-alapú Tanulás',
          point2Text: 'Jegyezd meg a szavakat kontextusban, ne kártyákkal',
          point3Title: 'Valódi Beszélgetési Gyakorlat',
          point3Text: 'Realisztikus párbeszédek, amelyek felkészítenek a tényleges használatra',
          point4Title: 'Adaptív Tanulási Rendszer',
          point4Text: 'Az MI-nk alkalmazkodik a tanulási stílusodhoz és tempódhoz',
          targetAudienceTitle: 'Kinek készült a VOC2GO?',
          audienceText: 'A VOC2GO tökéletes elfoglalt szakembereknek, diákoknak, utazóknak és bárkinek, aki hatékonyan szeretne új nyelvet tanulni.'
        }
      },
      
      // Learners Menu
      {
        id: 'learners',
        title: 'Tanulók Szekció',
        editableItems: {
          heading: 'Nyelvtanulóknak',
          subheading: 'A VOC2GO a tanulási igényeidet szem előtt tartva lett tervezve',
          benefitsTitle: 'Előnyök a Tanulóknak',
          benefit1: 'Személyre szabott szókincslisták az érdeklődési köröd alapján',
          benefit2: 'Lebilincselő történet-alapú megközelítés, amely emlékezetessé teszi a tanulást',
          benefit3: 'Adaptív nehézség, amely a képességeiddel együtt fejlődik',
          benefit4: 'Kövesd a fejlődésedet részletes elemzésekkel',
          testimonialTitle: 'Mit Mondanak a Felhasználóink',
          testimonial1Name: 'Molnár S.',
          testimonial1Text: 'A VOC2GO forradalmasította, ahogyan új szavakat tanulok. A kontextuális tanulás briliáns!',
          testimonial2Name: 'Kovács D.',
          testimonial2Text: 'Az alkalmazás adaptív rendszere olyan, mintha egy személyes nyelvtanár lenne a zsebemben.'
        }
      },
      
      // Supporters Menu
      {
        id: 'vision',
        title: 'Jövőkép Szekció',
        editableItems: {
          heading: 'Az új angoltanulás az MI segítségével a személyes szókincsépítés',
          subtitle: '',
          problem1: 'A meglévő appok olyan szavakat tanítanak, AMIKRE NINCS SZÜKSÉGED',
          problem2: 'A szókártyák UNALMASAK és hatástalanok',
          problem3: 'A tanulás TEHERNEK tűnik, nem örömnek',
          solution1: 'A VOC2GO a TE szavaidat tanítja, a TE módodon',
          solution2: 'A történetek SEGÍTENEK megjegyezni a szavakat',
          solution3: 'A tanulás SZÓRAKOZTATÓVÁ és LEBILINCSELŐVÉ válik',
          marketStats: 'Globális nyelvtanulási piac: 17.7 milliárd dollár 2027-re'
        }
      },
      {
        id: 'campaign',
        title: 'Kampány Szekció',
        editableItems: {
          heading: 'Csatlakozz az Indiegogo Kampányunkhoz',
          subheading: 'Segíts életre kelteni a VOC2GO-t és szerezz exkluzív jutalmakat',
          tier1Title: 'Korai Hozzáférés',
          tier1Price: '5000 Ft',
          tier1Description: 'Kapd meg az alkalmazást mindenki más előtt',
          tier1Limit: 'Az első 100 támogatóra korlátozva',
          tier2Title: 'Prémium Támogató',
          tier2Price: '10000 Ft',
          tier2Description: 'Élethosszig tartó hozzáférés a prémium funkciókhoz',
          tier2Limit: 'Csak 50 hely elérhető',
          tier3Title: 'Nyelvi Csomag',
          tier3Price: '17000 Ft',
          tier3Description: 'Hozzáférés minden nyelvi csomaghoz',
          tier3Limit: 'Korlátlan elérhetőség'
        }
      },
      {
        id: 'support',
        title: 'Támogatás Szekció',
        editableItems: {
          heading: 'Támogasd a Küldetésünket',
          subheading: 'Válaszd ki a számodra megfelelő csomagot',
          plan1Title: 'Ingyenes Csomag',
          plan1Features: 'Alapvető funkciók, Korlátozott szókészletek, Normál tanulási eszközök',
          plan2Title: 'Prémium Csomag',
          plan2Price: '1990 Ft/hó',
          plan2Features: 'Korlátlan szókincs létrehozás, MI-alapú történetgenerálás, Fejlett előrehaladás-követés',
          plan3Title: 'Élethosszig Tartó Hozzáférés',
          plan3Price: '34990 Ft',
          plan3Features: 'Egyszeri fizetés, Minden prémium funkció örökre, Elsőbbségi támogatás'
        }
      },
      
      // Project Menu
      {
        id: 'project',
        title: 'Projekt Csapat Szekció',
        editableItems: {
          heading: 'Ismerd Meg a Csapatunkat',
          subheading: 'A VOC2GO mögött álló lelkes emberek',
          member1Name: 'Natasha Rogers',
          member1Role: 'Alapító és Vezérigazgató',
          member1Bio: 'Nyelvtanulás rajongó 15 éves oktatási tapasztalattal',
          member2Name: 'David Chen',
          member2Role: 'Vezető Fejlesztő',
          member2Bio: 'Full-stack fejlesztő, MI és mobilalkalmazások szakértője',
          member3Name: 'Elisabeth König',
          member3Role: 'Nyelvi Szakértő',
          member3Bio: 'Többnyelvű szakember nyelvészeti és nyelvelsajátítási szaktudással'
        }
      },
      {
        id: 'roadmap',
        title: 'Ütemterv Szekció',
        editableItems: {
          heading: 'Fejlesztési Ütemterv',
          subheading: 'Utunk a tökéletes nyelvtanuló alkalmazás létrehozásához',
          phase1Title: 'Kutatási Szakasz',
          phase1Description: 'Hatékony tanulási módszerek és felhasználói igények kutatása',
          phase1Status: 'Befejezve',
          phase2Title: 'Fejlesztési Szakasz',
          phase2Description: 'Alapfunkciók és felhasználói felület kiépítése',
          phase2Status: 'Folyamatban',
          phase3Title: 'Tesztelési Szakasz',
          phase3Description: 'Béta tesztelés valódi felhasználókkal a tapasztalat javítására',
          phase3Status: 'Tervezett',
          phase4Title: 'Indítási Szakasz',
          phase4Description: 'Hivatalos kiadás és marketing kampány',
          phase4Status: 'Tervezett'
        }
      },
      
      // Contact Menu
      {
        id: 'feedback',
        title: 'Visszajelzés Szekció',
        editableItems: {
          heading: 'Küldd El Gondolataidat',
          subheading: 'Nagyra értékeljük a visszajelzéseidet',
          namePlaceholder: 'Add meg a neved',
          emailPlaceholder: 'Add meg az email címed',
          messagePlaceholder: 'Add meg üzeneted vagy javaslatod',
          excitementQuestion: 'Mennyire vagy lelkes?',
          excitementOption1: 'Nagyon',
          excitementOption2: 'Lelkes',
          excitementOption3: 'Valamennyire',
          excitementOption4: 'Kicsit',
          excitementOption5: 'Nem mozgat meg',
          submitButton: 'Visszajelzés Küldése',
          thankYouMessage: 'Köszönjük a visszajelzést!'
        }
      },
      {
        id: 'footer',
        title: 'Lábléc Szekció',
        editableItems: {
          contactTitle: 'Kapcsolat',
          contactEmail: 'Email: voc2go@gmail.com',
          socialTitle: 'Kövess Minket',
          legalTitle: 'Jogi információk',
          termsLink: 'Felhasználási Feltételek',
          privacyLink: 'Adatvédelmi Szabályzat',
          cookieLink: 'Süti Szabályzat',
          copyright: '© 2025 Voc2Go by Circular Innovation Hub. Minden jog fenntartva.'
        }
      }
    ]
  });

  const handleContentChange = (sectionId: string, itemKey: string, value: string) => {
    setContentSections(prev => {
      const newSections = {...prev};
      const sectionIndex = newSections[activeLanguage].findIndex(s => s.id === sectionId);
      
      if (sectionIndex !== -1 && newSections[activeLanguage][sectionIndex].editableItems) {
        newSections[activeLanguage][sectionIndex].editableItems![itemKey] = value;
      }
      
      return newSections;
    });
  };

  const handleSaveChanges = () => {
    // In a real implementation, this would send data to the backend
    console.log('Saving content changes:', contentSections);
    onSave(contentSections);
  };

  return (
    <div className="admin-content-editor">
      <div className="editor-header">
        <h3>{t("Content Management")}</h3>
        <div className="language-switcher">
          <button 
            className={`lang-btn ${activeLanguage === 'en' ? 'active' : ''}`}
            onClick={() => setActiveLanguage('en')}
          >
            {t("English")}
          </button>
          <button 
            className={`lang-btn ${activeLanguage === 'hu' ? 'active' : ''}`}
            onClick={() => setActiveLanguage('hu')}
          >
            {t("Hungarian")}
          </button>
        </div>
      </div>

      <div className="editor-content">
        <div className="sections-list">
          <h4>{activeLanguage === 'en' ? 'English Sections' : 'Magyar Szekciók'}</h4>
          <ul>
            {contentSections[activeLanguage].map(section => (
              <li 
                key={section.id}
                className={activeSection === section.id ? 'active' : ''}
                onClick={() => setActiveSection(section.id)}
              >
                {section.title}
              </li>
            ))}
          </ul>
        </div>

        <div className="section-editor">
          {activeSection && (
            <>
              <h4>
                {activeLanguage === 'en' 
                  ? 'Editing: ' + contentSections.en.find(s => s.id === activeSection)?.title
                  : 'Szerkesztés: ' + contentSections.hu.find(s => s.id === activeSection)?.title}
              </h4>
              
              <div className="editor-fields">
                {contentSections[activeLanguage]
                  .find(s => s.id === activeSection)
                  ?.editableItems && 
                  Object.entries(contentSections[activeLanguage]
                    .find(s => s.id === activeSection)!
                    .editableItems!).map(([key, value]) => (
                    <div className="editor-field" key={key}>
                      <label>{key.charAt(0).toUpperCase() + key.slice(1)}</label>
                      <textarea 
                        value={value}
                        onChange={(e) => handleContentChange(activeSection, key, e.target.value)}
                        rows={key === 'subtitle' || key === 'subheading' ? 3 : 1}
                      />
                    </div>
                  ))
                }
              </div>
            </>
          )}
          {!activeSection && (
            <div className="no-selection">
              <p>{activeLanguage === 'en' ? 'Select a section to edit' : 'Válassz egy szekciót a szerkesztéshez'}</p>
            </div>
          )}
        </div>
      </div>

      <div className="editor-actions">
        <button className="cancel-btn" onClick={onCancel}>
          {t("Cancel")}
        </button>
        <button className="save-btn" onClick={handleSaveChanges}>
          {t("Save Changes")}
        </button>
      </div>
    </div>
  );
};

export default AdminContentEditor;