import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { CheckCircle, Mail } from "lucide-react";

const NewsletterSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [alreadySubscribed, setAlreadySubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, language }),
      });
      
      if (response.ok) {
        setSubscribed(true);
        setEmail('');
      } else if (response.status === 409) {
        // Already subscribed case
        setAlreadySubscribed(true);
        timeoutRef.current = setTimeout(() => setAlreadySubscribed(false), 3000); // Reset after 3 seconds
      } else {
        const errorData = await response.json();
        console.error('Subscription failed:', errorData.message);
      }
    } catch (error) {
      console.error('Network error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Cleanup effect
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);
  
  return (
    <div style={{ color: "white", textAlign: "center" }}>
      <h2>
        {getContentText('newsletter-title', language === 'en' ? 'Stay Updated' : 'Maradj naprakész')}
      </h2>
      <p>
        {getContentText('newsletter-description', language === 'en' ? 'Subscribe to our newsletter for campaign updates' : 'Iratkozz fel hírlevelünkre a kampány frissítéseiért')}
      </p>
          
          {subscribed || alreadySubscribed ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '15px',
              padding: '20px',
              background: 'rgba(255, 255, 255, 0.05)',
              borderRadius: '12px'
            }}>
              <div style={{
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                background: subscribed ? '#44d1c6' : '#f59e0b',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
              }}>
                <CheckCircle size={30} />
              </div>
              <p style={{ 
                fontSize: '18px',
                fontWeight: '500',
                color: 'white'
              }}>
                {subscribed 
                  ? getContentText('newsletter-thanks', language === 'en' ? 'Thanks for subscribing!' : 'Köszönjük a feliratkozást!')
                  : (language === 'en' ? 'You are already subscribed!' : 'Már feliratkoztál!')
                }
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "10px", flexWrap: "wrap" }}>
              <input 
                type="email" 
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  // Reset custom validation on input change
                  e.target.setCustomValidity('');
                }}
                required
                placeholder={getContentText('newsletter-placeholder', language === 'en' ? 'Enter your email' : 'Add meg az email címed')}
                style={{
                  padding: "12px",
                  borderRadius: "8px",
                  border: "1px solid rgba(255,255,255,0.3)",
                  background: "rgba(255,255,255,0.1)",
                  color: "white",
                  width: "300px"
                }}
              />
              <button 
                type="submit"
                disabled={isLoading}
                style={{
                  padding: "12px 24px",
                  background: isLoading ? "#cccccc" : "#F7941D",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: isLoading ? "not-allowed" : "pointer",
                  opacity: isLoading ? 0.7 : 1
                }}
              >
                {isLoading 
                  ? (language === 'en' ? 'Subscribing...' : 'Feliratkozás...')
                  : getContentText('newsletter-button', language === 'en' ? 'Subscribe' : 'Feliratkozás')
                }
              </button>
            </form>
          )}
    </div>
  );
};

export default NewsletterSection;