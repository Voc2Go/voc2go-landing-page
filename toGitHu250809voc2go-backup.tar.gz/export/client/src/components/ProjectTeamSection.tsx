import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import SocialMediaIcons from "./SocialMediaIcons";
import kataPhoto from "@assets/Kata.jpeg";
import zsuzsaPhoto from "@assets/Zsuzsa.jpg";
import jenoPhoto from "@assets/Jeno.jpg";
import kyaraPhoto from "@assets/Kyara.jpg";
import somaPhoto from "@assets/Soma.jpg";
import fanniPhoto from "@assets/Fanni.jpg";
import kolosPhoto from "@assets/Kolos.jpg";
import vikiPhoto from "@assets/Viki.jpg";
import davidPhoto from "@assets/David.jpg";
import { motion } from "framer-motion";
import backgroundImage from "@assets/Background.png";
import { ArrowLeft } from "lucide-react";

const ProjectTeamSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();

  // Navigation handler for back to home
  const handleBackToHome = () => {
    const event = new CustomEvent('navigate', { detail: 'home' });
    window.dispatchEvent(event);
  };

  // Team members' data managed through admin system
  const teamMembers = [
    {
      name: getContentText('team-member-1-name', "MarjaiKata"),
      photo: kataPhoto,
      bio: {
        en: getContentText('team-member-1-bio-en', "I'm the brain behind Voc2Go, and my furry assistant Bodza says woof! We've packed all my teaching tricks and tech smarts into this super fun app! It's like having a pocket-sized English guru! Whether you're starting out or need a boost, we've got your back! Let's rock this together! #EasyEnglish #DogApproved"),
        hu: getContentText('team-member-1-bio-hu', "Én vagyok a Voc2Go motorja, bundás asszisztensem, Bodza, egyetértően vakkant! Az összes tanítási trükkömet és tech-varázslatomat belezsúfoltan ebbe a szuper hatékony és szórakoztató appba! Olyan, mintha lenne egy zsebméretű angoltanárod! Akár most kezded, akár csak egy kis löketre van szükséged, mi itt vagyunk neked! Nyomjuk együtt! #KönnyűAngol #KutyaÁltalJóváhagyva")
      }
    },
    {
      name: getContentText('team-member-2-name', language === "en" ? "ZsuzsiMagyar" : "MagyarZsuzsi"),
      photo: zsuzsaPhoto,
      bio: {
        en: getContentText('team-member-2-bio-en', "I'm living my best life as a freelance art director and teaching at Visart Art School Budapest! My bestie Kata and I are about to change the English learning game forever with Voc2Go. It's going to be epic! Let's collab and make some magic happen! Your words, your style, your English is Voc2Go. #ArtDirector #CreativeCollaboration"),
        hu: getContentText('team-member-2-bio-hu', "Élem az álommelómatt: szabadúszó art director vagyok, és a Visart Művészeti Akadémián is tanítok Budapesten! A legjobb barátnőmmel, Katával most teljesen megváltoztatjuk az angoltanulást a Voc2Go-val! Ez hatalmas lesz! Dolgozzunk össze, és alkossunk valami elképesztőt! A szavaid, a stílusod, az angolod a Voc2Go. #ArtDirector #KreatívEgyüttműködés")
      }
    },
    {
      name: getContentText('team-member-3-name', language === "en" ? "JenoHalasy" : "HalasyJenő"),
      photo: jenoPhoto,
      bio: {
        en: getContentText('team-member-3-bio-en', "I'm a visual storyteller and proud papa to two awesome little dudes! Been rocking the freelance world as a motion designer and 3D artist for 10 years! My teachers were total rockstars, especially Zsuzsi Magyar - we still team up all the time! Ready to bring your story to life! #AnimationRocks"),
        hu: getContentText('team-member-3-bio-hu', "Vizuális történetmesélő és két vagány kissrác büszke apukája! Már 10 éve pörgök a szabadúszó világban, mint motion designer és 3D artist! A tanáraim igazi legendák voltak – főleg Magyar Zsuzsi, akivel a mai napig együtt dolgozunk! Készen állok, hogy életre keltsem a történeted! #AnimációKirályság")
      }
    },
    {
      name: getContentText('team-member-4-name', language === "en" ? "KyaraRippel" : "RippelKyara"),
      photo: kyaraPhoto,
      bio: {
        en: getContentText('team-member-4-bio-en', "Graphic field specialist in the house! Voc2Go is helping me level up my English game! When I'm not on the grind, I'm crushing it with gaming and aerial silks - they're my secret weapons for getting those skills on point! Sometimes I grab my paintbrush to chill and express! #ArtisticVibes"),
        hu: getContentText('team-member-4-bio-hu', "Grafikai területi szakértő itt! A Voc2Go segít nekem fejleszteni az angol tudásomat! Amikor nem dolgozom, gaming-gel és légi selyemmel töltöm az időt - ezek a titkos fegyvereim a készségek csiszolásához! Néha előveszem az ecsetemet, hogy lazítsak és kifejezzem magam! #MűvésziHangulat")
      }
    },
    {
      name: getContentText('team-member-5-name', language === "en" ? "SomaLegler" : "LeglerSoma"),
      photo: somaPhoto,
      bio: {
        en: getContentText('team-member-5-bio-en', "Fresh designer ready to rock the Voc2Go world! When I'm not pushing pixels, you'll find me geeking out over typography or snapping photos! Weekends are for hiking trails and hunting inspiration! Always nose-deep in design books because trends never sleep! Let's create something awesome! #AlwaysLearning"),
        hu: getContentText('team-member-5-bio-hu', "Friss dizájner, aki készen áll, hogy meghódítsa a Voc2Go világát! Ha épp nem pixeleket tologatok, akkor a tipográfián pörgök vagy a kamerával vadászom az inspirációt! A hétvégék nálam a túrázásról és kreatív feltöltődésről szólnak! Folyamatosan design könyveket bújok, mert a trendek sosem alszanak! #FolyamatosTanulás")
      }
    },
    {
      name: getContentText('team-member-6-name', language === "en" ? "FanniKovács" : "KovácsFanni"),
      photo: fanniPhoto,
      bio: {
        en: getContentText('team-member-6-bio-en', "Fresh graphic design grad here! Total language nerd alert - nailed English, tackled French, now wrestling with Dutch! When I'm not designing for Voc2Go, I'm conquering virtual worlds or getting lost in books! Can't wait for you to feel the magic of what we're creating. #LanguageLearningRevolution"),
        hu: getContentText('team-member-6-bio-hu', "Frissen végzett grafikus designer itt! Totál nyelvimádó vagyok – az angolt kipipáltam, a franciát legyűrtem, most a hollanddal küzdök! Amikor nem a Voc2Go dizájnját csiszolom, akkor vagy virtuális világokat hódítok meg vagy könyvekben vesztem el! Alig várom, hogy te is átérezd, milyen izgalmas dolgot alkotunk! #NyelvtanulásiForradalom")
      }
    },
    {
      name: getContentText('team-member-7-name', language === "en" ? "KolosKevei" : "KeveiKolos"),
      photo: kolosPhoto,
      bio: {
        en: getContentText('team-member-7-bio-en', "Visual Storyteller with a sweet twist here! Been rocking the advertising world for 15 years and crafting luxury chocolates since 2012! When I'm not in my chocolate lab, catch me paragliding for fresh perspectives! From Unreal Engine 5 to cocoa beans, I'm all about that creative life! #ChocolateArtisan"),
        hu: getContentText('team-member-7-bio-hu', "Vizuális történetmesélő egy kis édes csavarral! 15 éve pörgök a reklámszakmában, és 2012 óta luxus csokoládékat készítek! Ha épp nem a csoki laboromban alkotok, akkor siklóernyőzök, hogy új perspektívákat találjak! Az Unreal Engine 5-től a kakaóbabig mindenben ott a kreativitás! #CsokoládéMűvészet")
      }
    },
    {
      name: getContentText('team-member-8-name', language === "en" ? "VikiMolnár" : "MolnárViki"),
      photo: vikiPhoto,
      bio: {
        en: getContentText('team-member-8-bio-en', "I'm the artistic whiz behind Vic, your new digital English teacher! When I'm not wielding my paintbrush at Visart School, I'm bringing Voc2Go to life! You'll catch me swinging a tennis racket or diving into my paints - no fear! Let's rock this English journey together! #ArtMeetsLanguage"),
        hu: getContentText('team-member-8-bio-hu', "Én vagyok a művész, aki megalkotta Vicet, az új digitális angoltanárod arcát! Ha épp nem a Visart Iskolában festek, akkor a Voc2Go-t keltem életre! Amikor nem az ecsettel varázsolok, akkor teniszütővel csapok le éppen! Tarts velem az angoltanulás kalandtúrán! #MűvészetTalálkozikANyelvvel")
      }
    },
    {
      name: getContentText('team-member-9-name', language === "en" ? "DávidKocsi" : "KocsiDávid"),
      photo: davidPhoto,
      bio: {
        en: getContentText('team-member-9-bio-en', "Full-stack developer passionate about creating innovative educational technology! When I'm not coding the future of language learning, I'm exploring new frameworks or contributing to open-source projects! Ready to build something that changes how the world learns English! #TechForEducation"),
        hu: getContentText('team-member-9-bio-hu', "Full-stack fejlesztő, aki szenvedélyesen dolgozik az innovatív oktatási technológián! Amikor nem a nyelvtanulás jövőjét kódolom, akkor új keretrendszereket fedezek fel vagy nyílt forráskódú projektekhez járulok hozzá! Készen állok arra, hogy olyan dolgot építsünk, ami megváltoztatja, hogyan tanul angolul a világ! #TechAzOktatásért")
      }
    }
  ];

  // Background gradient colors - darker and less pinky
  const gradientColors = [
    "linear-gradient(135deg, #ff9966, #ff5e62)",
    "linear-gradient(135deg, #7F7FD5, #86A8E7, #91EAE4)",
    "linear-gradient(135deg, #2D0051, #5C37C7)"
  ];

  return (
    <section
      id="voc2go-project"
      style={{
        padding: "120px 0 60px",
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        position: "relative"
      }}
    >
      {/* Dark overlay */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0,0,0,0.7)",
          zIndex: 1
        }}
      ></div>

      <div
        className="container"
        style={{
          position: "relative",
          zIndex: 2,
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "0 20px"
        }}
      >
        {/* Back to Home Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          style={{
            marginBottom: "30px",
            display: "flex",
            justifyContent: "flex-start"
          }}
        >
          <button
            onClick={handleBackToHome}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              padding: "12px 24px",
              background: "rgba(255, 255, 255, 0.1)",
              color: "white",
              border: "2px solid rgba(255, 255, 255, 0.3)",
              borderRadius: "8px",
              fontSize: "14px",
              fontWeight: "600",
              cursor: "pointer",
              transition: "all 0.3s ease",
              backdropFilter: "blur(10px)"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.2)";
              e.currentTarget.style.borderColor = "rgba(255, 255, 255, 0.5)";
              e.currentTarget.style.transform = "translateX(-3px)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.1)";
              e.currentTarget.style.borderColor = "rgba(255, 255, 255, 0.3)";
              e.currentTarget.style.transform = "translateX(0)";
            }}
          >
            <ArrowLeft size={16} />
            {language === "en" ? "Back to Home" : "Vissza a kezdőlapra"}
          </button>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="section-title"
          style={{
            color: "white",
            fontSize: "36px",
            textAlign: "center",
            marginBottom: "50px",
            fontWeight: "bold"
          }}
        >
          {language === "en" ? "Meet the Team" : "Ismerd meg a csapatot"}
        </motion.h2>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
            gap: "30px",
            width: "100%",
            maxWidth: "1200px",
            margin: "0 auto"
          }}
        >
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              style={{
                background: gradientColors[index % gradientColors.length],
                borderRadius: "12px",
                overflow: "hidden",
                boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
                height: "100%"
              }}
            >
              <div
                style={{
                  padding: "20px",
                  color: "white"
                }}
              >
                <div className="flex flex-col items-center mb-4">
                  {/* Photo container - centered on mobile */}
                  <div 
                    className="rounded-full overflow-hidden mb-4 flex-shrink-0 border-4 border-white shadow-lg mx-auto" 
                    style={{ 
                      width: "260px", 
                      height: "260px", 
                      maxWidth: "90%",
                      boxSizing: "border-box",
                      position: "relative"
                    }}
                  >
                    <img 
                      src={member.photo} 
                      alt={member.name} 
                      style={{ 
                        objectFit: "cover", 
                        objectPosition: "center",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%" 
                      }}
                    />
                  </div>
                  
                  {/* Text content - centered on mobile */}
                  <div className="text-center">
                    <h3
                      style={{
                        fontSize: "24px",
                        fontWeight: "bold",
                        marginBottom: "15px"
                      }}
                    >
                      {member.name}
                    </h3>
                    <p
                      style={{
                        fontSize: "16px",
                        lineHeight: "1.6",
                        marginBottom: "20px"
                      }}
                    >
                      {language === "en" ? member.bio.en : member.bio.hu}
                    </p>
                    
                    {/* Social media icons */}
                    <SocialMediaIcons memberId={`member-${index + 1}`} />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Indiegogo Campaign Button */}
        <div style={{ 
          textAlign: 'center', 
          marginTop: '60px',
          paddingBottom: '40px'
        }}>
          <a 
            href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: 'inline-block',
              backgroundColor: '#eb1478',
              color: 'white',
              padding: '18px 36px',
              borderRadius: '50px',
              textDecoration: 'none',
              fontWeight: 'bold',
              fontSize: '1.2rem',
              boxShadow: '0 8px 25px rgba(235, 20, 120, 0.4)',
              transition: 'all 0.3s ease',
              border: '2px solid rgba(255, 255, 255, 0.2)',
              textTransform: 'uppercase',
              letterSpacing: '1px'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-3px)';
              e.currentTarget.style.boxShadow = '0 12px 35px rgba(235, 20, 120, 0.6)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.boxShadow = '0 8px 25px rgba(235, 20, 120, 0.4)';
            }}
          >
            {getContentText('indiegogo-button', language === 'en' ? "Support on Indiegogo" : "Támogass az Indiegogo-n")}
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProjectTeamSection;