import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { motion } from "framer-motion";
import { useAdaptiveCardSize } from "../hooks/useAdaptiveCardSize";
import "../styles/adaptive-cards.css";

// Import persona images
import jenciImage from "@assets/1Jenci560_560.jpg";
import natashaImage from "@assets/2Natasha560_560.jpg";
import elisabethImage from "@assets/3Elisabeth560_560.jpg";
import leeImage from "@assets/4Lee_560_560.jpg";

interface PersonaCardProps {
  image: string;
  name: string;
  title: string;
  description: string;
  index: number;
}

const PersonaCard: React.FC<PersonaCardProps> = ({ image, name, title, description, index }) => {
  const { getCardStyle, getTitleStyle, getContentDensityClass } = useAdaptiveCardSize();
  const cardStyle = getCardStyle('persona');
  const titleStyle = getTitleStyle();
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className={`adaptive-card persona-card ${getContentDensityClass()}`}
      style={{
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
        cursor: "pointer",
        transition: "transform 0.3s ease, box-shadow 0.3s ease",
        aspectRatio: "4/5",
        ...cardStyle
      }}
      whileHover={{
        boxShadow: "0 12px 32px rgba(0, 0, 0, 0.15)",
        transform: "translateY(-5px)",
      }}
    >
      <img
        src={image}
        alt={name}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
        }}
      />
      <div 
        className="persona-content" 
        style={{ 
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: "24px",
          textAlign: "left",
          color: "white",
          background: "linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.8) 50%, rgba(0,0,0,0.3) 80%, rgba(0,0,0,0) 100%)",
          minHeight: "40%",
          maxHeight: "70%",
          overflow: "hidden",
          boxSizing: "border-box",
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-end"
        }}
      >
        <h3 style={{ 
          fontSize: "24px", 
          fontWeight: "700", 
          marginBottom: "6px",
          wordWrap: "break-word",
          overflowWrap: "break-word",
          margin: "0 0 6px 0",
          textShadow: "2px 2px 4px rgba(0,0,0,0.8)",
          lineHeight: "1.2"
        }}>{name}</h3>
        <h4 style={{ 
          fontSize: "17px", 
          fontWeight: "500", 
          opacity: 0.95, 
          marginBottom: "10px", 
          fontStyle: "italic",
          wordWrap: "break-word",
          overflowWrap: "break-word",
          margin: "0 0 10px 0",
          textShadow: "1px 1px 2px rgba(0,0,0,0.8)",
          lineHeight: "1.3"
        }}>
          {title}
        </h4>
        <p style={{ 
          fontSize: "16px", 
          opacity: 0.95, 
          lineHeight: 1.4,
          wordWrap: "break-word",
          overflowWrap: "break-word",
          hyphens: "auto",
          margin: 0,
          textShadow: "1px 1px 2px rgba(0,0,0,0.8)",
          display: "-webkit-box",
          WebkitLineClamp: 3,
          WebkitBoxOrient: "vertical",
          overflow: "hidden"
        }}>{description}</p>
      </div>
    </motion.div>
  );
};

const PersonasSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();

  const personas = [
    {
      image: jenciImage,
      name: "Jenci",
      title: getContentText('persona-jenci-title', language === "en" ? "3D programmer" : "3D programozó"),
      description: getContentText('persona-jenci-desc', 
        language === "en"
          ? "Wants to work internationally but needs stronger English skills"
          : "Külföldön szeretne dolgozni, de jobban kell tudnia angolul."
      ),
    },
    {
      image: natashaImage,
      name: "Natasha",
      title: getContentText('persona-natasha-title', language === "en" ? "Legal professional" : "Jogi szakember"),
      description: getContentText('persona-natasha-desc',
        language === "en"
          ? "Excels in legal writing but struggles with English speaking confidence in social settings"
          : "Jogi szövegeket remekül ír, de társaságban nem elég magabiztosan beszél angolul."
      ),
    },
    {
      image: elisabethImage,
      name: "Elisabeth",
      title: getContentText('persona-elisabeth-title', language === "en" ? "Creative designer" : "Kreatív tervező"),
      description: getContentText('persona-elisabeth-desc',
        language === "en"
          ? "Feels frustrated when she forgets English vocabulary mid-conversation"
          : "Bosszantja, hogy beszélgetés közben nem jutnak eszébe a pontos angol szavak."
      ),
    },
    {
      image: leeImage,
      name: "Lee",
      title: getContentText('persona-lee-title', language === "en" ? "Hospitality worker" : "Vendéglátásban dolgozik"),
      description: getContentText('persona-lee-desc',
        language === "en"
          ? "Has basic English but needs an advanced English level for university"
          : "Alapszinten beszél angolul, de az egyetemhez haladó szint kellene."
      ),
    },
  ];

  return (
    <section
      style={{
        background: "linear-gradient(135deg, #301A4B 0%, #0088cc 100%)",
        padding: "30px 0",
        position: "relative",
        overflow: "hidden",
        marginTop: "0",
        marginBottom: "0"
      }}
    >
      <div
        className="gradient-overlay"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          opacity: 0.2,
          background:
            "radial-gradient(circle at 20% 30%, rgba(130, 210, 250, 0.5) 0%, transparent 30%), " +
            "radial-gradient(circle at 80% 70%, rgba(79, 57, 147, 0.5) 0%, transparent 40%)",
          zIndex: 1,
        }}
      ></div>

      <div className="container" style={{ position: "relative", zIndex: 2 }}>
        <div className="section-header text-center mb-5">
          <h2
            style={{
              color: "white",
              fontSize: "32px",
              fontWeight: "bold",
              marginBottom: "15px",
            }}
          >
            {getContentText('who-is-voc2go-for-title', language === "en" ? "Who is Voc2Go for?" : "Kinek való a Voc2Go?")}
          </h2>
          <p
            style={{
              color: "rgba(255, 255, 255, 0.9)",
              fontSize: "18px",
              maxWidth: "800px",
              margin: "0 auto 25px auto",
              lineHeight: "1.6"
            }}
          >
            {getContentText('who-is-voc2go-for-description', 
              language === "en" 
                ? "Meet our learners - discover how Voc2Go helps people like you achieve their English learning goals."
                : "Ismerd meg tanulóinkat - fedezd fel, hogyan segít a Voc2Go az olyan embereknek, mint te, az angol tanulási céljaik elérésében."
            )}
          </p>
        </div>

        <div
          className="personas-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "30px",
            margin: "0 auto",
            maxWidth: "1400px",
            padding: "0 20px"
          }}
        >
          {personas.map((persona, index) => (
            <PersonaCard
              key={index}
              image={persona.image}
              name={persona.name}
              title={persona.title}
              description={persona.description}
              index={index}
            />
          ))}
        </div>
      </div>
      
      {/* Indiegogo Campaign Button */}
      <div style={{ 
        textAlign: 'center', 
        marginTop: '60px',
        paddingBottom: '40px'
      }}>
        <a 
          href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: 'inline-block',
            backgroundColor: '#eb1478',
            color: 'white',
            padding: '18px 36px',
            borderRadius: '50px',
            textDecoration: 'none',
            fontWeight: 'bold',
            fontSize: '1.2rem',
            boxShadow: '0 8px 25px rgba(235, 20, 120, 0.4)',
            transition: 'all 0.3s ease',
            border: '2px solid rgba(255, 255, 255, 0.2)',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-3px)';
            e.currentTarget.style.boxShadow = '0 12px 35px rgba(235, 20, 120, 0.6)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 8px 25px rgba(235, 20, 120, 0.4)';
          }}
        >
          {language === 'en' ? "Support on Indiegogo" : "Támogass az Indiegogo-n"}
        </a>
      </div>
    </section>
  );
};

export default PersonasSection;