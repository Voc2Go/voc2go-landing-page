import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { DollarSign, Clock, Calendar, BookOpen } from "lucide-react";

const PayAsYouGoSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();

  // Feature items with icons - now using admin-manageable content
  const features = [
    {
      icon: <DollarSign size={24} color="white" />,
      title: getContentText('pay-as-you-go-title', language === 'en' ? "Pay as you go" : "Csak annyit fizetsz, amennyit tanulsz"),
      subtitle: getContentText('pay-as-you-go-subtitle', language === 'en' ? "No subscription" : "nincs előfizetés!")
    },
    {
      icon: <Clock size={24} color="white" />,
      title: getContentText('pay-flexible-title', language === 'en' ? "FLEXIBLE" : "RUGALMAS"),
      description: getContentText('pay-flexible-desc', language === 'en' ? "No commitments. Just learn!" : "Nincs elköteleződés, nincs kötöttség. Akkor tanulsz, amikor neked megfelel!")
    },
    {
      icon: <Calendar size={24} color="white" />,
      title: getContentText('pay-schedule-title', language === 'en' ? "SUITS YOUR SCHEDULE" : "IGAZODIK AZ IDŐ BEOSZTÁSODHOZ"),
      description: getContentText('pay-schedule-desc', language === 'en' ? "Perfect for budget-conscious learners, Voc2Go adapts to your schedule and budget." : "A Voc2Go rugalmasan alkalmazkodik az életedhez és a költségvetésedhez.")
    },
    {
      icon: <BookOpen size={24} color="white" />,
      title: getContentText('pay-pace-title', language === 'en' ? "LEARN AT YOUR PACE" : "A SAJÁT TEMPÓDBAN TANULSZ"),
      description: getContentText('pay-pace-desc', language === 'en' ? "Learn at your own pace, pay as you go, and watch your English skills soar!" : "Haladj a saját ritmusodban, fizess csak az elvégzett leckékért, és élvezd, ahogy egyre magabiztosabban beszélsz angolul.")
    }
  ];

  return (
    <div style={{
      backgroundColor: "#2B1464", // Deep purple background
      padding: "25px 20px",
      color: "white",
      marginBottom: "0"
    }}>
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
        gap: "20px",
        maxWidth: "1200px",
        margin: "0 auto"
      }}>
        {features.map((feature, index) => (
          <div key={index} style={{
            display: "flex",
            alignItems: "flex-start",
            gap: "15px",
            opacity: 0,
            animationName: "fadeInUp",
            animationDuration: "0.5s",
            animationTimingFunction: "ease",
            animationFillMode: "forwards",
            animationDelay: `${0.1 * index}s`
          }}>
            <div style={{
              backgroundColor: "rgba(255, 255, 255, 0.1)",
              borderRadius: "50%",
              width: "48px",
              height: "48px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0
            }}>
              {feature.icon}
            </div>
            <div>
              <h3 style={{
                color: "#F7941D", // Orange color for titles
                fontSize: "18px",
                fontWeight: "bold",
                marginBottom: "6px",
                textTransform: "uppercase"
              }}>
                {feature.title}
              </h3>
              {feature.subtitle && (
                <p style={{
                  fontSize: "16px",
                  margin: "0 0 5px 0"
                }}>
                  {feature.subtitle}
                </p>
              )}
              {feature.description && (
                <p style={{
                  fontSize: "15px",
                  lineHeight: "1.5",
                  opacity: 0.9,
                  margin: 0
                }}>
                  {feature.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes fadeInUp {
            from {
              opacity: 0;
              transform: translateY(20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
        `
      }} />
    </div>
  );
};

export default PayAsYouGoSection;