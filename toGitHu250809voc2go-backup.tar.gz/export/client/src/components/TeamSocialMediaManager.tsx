import React, { useState, useEffect } from 'react';
import { Instagram, Facebook, Linkedin, Globe, Heart, ExternalLink } from 'lucide-react';
import { FaPinterest } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';
import { SiBehance } from 'react-icons/si';

interface SocialLinks {
  instagram?: string;
  facebook?: string;
  linkedin?: string;
  behance?: string;
  kofi?: string;
  pinterest?: string;
  twitter?: string;
  website?: string;
}

interface TeamSocialMediaManagerProps {
  memberId: string;
  memberName: string;
  onSave?: (links: SocialLinks) => void;
  language?: 'en' | 'hu';
}

const socialPlatforms = [
  { key: 'instagram', label: 'Instagram', icon: Instagram, placeholder: 'https://instagram.com/username' },
  { key: 'facebook', label: 'Facebook', icon: Facebook, placeholder: 'https://facebook.com/username' },
  { key: 'linkedin', label: 'LinkedIn', icon: Linkedin, placeholder: 'https://linkedin.com/in/username' },
  { key: 'behance', label: 'Behance', icon: SiBehance, placeholder: 'https://behance.net/username' },
  { key: 'kofi', label: 'Ko-fi', icon: Heart, placeholder: 'https://ko-fi.com/username' },
  { key: 'pinterest', label: 'Pinterest', icon: FaPinterest, placeholder: 'https://pinterest.com/username' },
  { key: 'twitter', label: 'X (Twitter)', icon: FaXTwitter, placeholder: 'https://x.com/username' },
  { key: 'website', label: 'Website', icon: ExternalLink, placeholder: 'https://yourwebsite.com' }
];

export default function TeamSocialMediaManager({ memberId, memberName, onSave, language = 'en' }: TeamSocialMediaManagerProps) {
  // Bilingual text content
  const text = {
    en: {
      title: 'Social Media Links',
      loading: 'Loading social media links...',
      failed: 'Failed to load social media links',
      error: 'Error loading social media links',
      saveError: 'Error saving social media links',
      failedSave: 'Failed to save social media links',
      reset: 'Reset',
      save: 'Save Links',
      saving: 'Saving...'
    },
    hu: {
      title: 'Közösségi Média Linkek',
      loading: 'Közösségi média linkek betöltése...',
      failed: 'Nem sikerült betölteni a közösségi média linkeket',
      error: 'Hiba a közösségi média linkek betöltésekor',
      saveError: 'Hiba a közösségi média linkek mentésekor',
      failedSave: 'Nem sikerült menteni a közösségi média linkeket',
      reset: 'Visszaállítás',
      save: 'Linkek Mentése',
      saving: 'Mentés...'
    }
  };
  const [socialLinks, setSocialLinks] = useState<SocialLinks>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load existing social links
  useEffect(() => {
    loadSocialLinks();
  }, [memberId]);

  const loadSocialLinks = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/team-socials/${memberId}`);
      const data = await response.json();
      
      if (response.ok) {
        setSocialLinks(data.socials || {});
      } else {
        setError(text[language].failed);
      }
    } catch (err) {
      setError(text[language].error);
      console.error('Error loading social links:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLinkChange = (platform: string, value: string) => {
    setSocialLinks(prev => ({
      ...prev,
      [platform]: value || undefined
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    
    try {
      const response = await fetch(`/api/team-socials/${memberId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(socialLinks),
      });

      const data = await response.json();
      
      if (response.ok) {
        setSocialLinks(data.socials);
        onSave?.(data.socials);
      } else {
        setError(data.error || text[language].failedSave);
      }
    } catch (err) {
      setError(text[language].saveError);
      console.error('Error saving social links:', err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div style={{
        padding: '20px',
        border: '1px solid #E5E7EB',
        borderRadius: '8px',
        backgroundColor: '#F9FAFB',
        textAlign: 'center'
      }}>
        <div>{text[language].loading}</div>
      </div>
    );
  }

  return (
    <div style={{
      padding: '20px',
      border: '1px solid #E5E7EB',
      borderRadius: '8px',
      backgroundColor: '#F9FAFB',
      marginTop: '16px'
    }}>
      <h4 style={{
        fontSize: '16px',
        fontWeight: '600',
        color: '#374151',
        marginBottom: '16px',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}>
        <Globe size={20} />
        {text[language].title} - {memberName}
      </h4>

      {error && (
        <div style={{
          padding: '12px',
          backgroundColor: '#FEF2F2',
          border: '1px solid #FCA5A5',
          borderRadius: '6px',
          color: '#B91C1C',
          fontSize: '14px',
          marginBottom: '16px'
        }}>
          {error}
        </div>
      )}

      <div style={{
        display: 'grid',
        gap: '16px'
      }}>
        {socialPlatforms.map(({ key, label, icon: Icon, placeholder }) => (
          <div key={key} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            <label style={{
              fontSize: '14px',
              fontWeight: '500',
              color: '#374151',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <Icon size={16} />
              {label}
            </label>
            <input
              type="url"
              value={socialLinks[key as keyof SocialLinks] || ''}
              onChange={(e) => handleLinkChange(key, e.target.value)}
              placeholder={placeholder}
              style={{
                padding: '8px 12px',
                border: '1px solid #D1D5DB',
                borderRadius: '6px',
                fontSize: '14px',
                backgroundColor: 'white',
                outline: 'none',
                transition: 'border-color 0.2s',
              }}
              onFocus={(e) => e.target.style.borderColor = '#3B82F6'}
              onBlur={(e) => e.target.style.borderColor = '#D1D5DB'}
            />
          </div>
        ))}
      </div>

      <div style={{
        marginTop: '20px',
        display: 'flex',
        justifyContent: 'flex-end',
        gap: '12px'
      }}>
        <button
          onClick={loadSocialLinks}
          disabled={loading || saving}
          style={{
            padding: '8px 16px',
            border: '1px solid #D1D5DB',
            borderRadius: '6px',
            backgroundColor: 'white',
            color: '#374151',
            fontSize: '14px',
            cursor: loading || saving ? 'not-allowed' : 'pointer',
            opacity: loading || saving ? 0.6 : 1
          }}
        >
          {text[language].reset}
        </button>
        <button
          onClick={handleSave}
          disabled={loading || saving}
          style={{
            padding: '8px 16px',
            border: 'none',
            borderRadius: '6px',
            backgroundColor: saving ? '#9CA3AF' : '#3B82F6',
            color: 'white',
            fontSize: '14px',
            cursor: loading || saving ? 'not-allowed' : 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '4px'
          }}
        >
          {saving ? text[language].saving : text[language].save}
        </button>
      </div>
    </div>
  );
}