import React from "react";
import { useLanguage } from "../context/LanguageContext";
import appleImage from "@assets/SiteFreemiumpic1.png";

const MemoryCard: React.FC = () => {
  const { language } = useLanguage();

  return (
    <div style={{
      position: 'relative',
      width: '100%',
      maxWidth: '300px',
      margin: '20px auto',
      padding: '15px',
      backgroundColor: 'white',
      borderRadius: '10px',
      boxShadow: '0 8px 20px rgba(0, 0, 0, 0.15)',
      transform: 'rotate(-2deg)',
      transition: 'transform 0.3s ease',
    }}>
      <div style={{
        width: '100%',
        height: '180px',
        backgroundColor: '#f0f0f0',
        borderRadius: '8px',
        marginBottom: '15px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
      }}>
        <img 
          src={appleImage} 
          alt="Apple" 
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            borderRadius: '8px',
          }}
        />
      </div>
      <div style={{
        padding: '5px 10px',
        backgroundColor: '#f5f5f5',
        borderRadius: '6px',
      }}>
        <h3 style={{
          color: '#301A4B',
          fontSize: '16px',
          fontWeight: 'bold',
          margin: '5px 0',
        }}>
          {language === 'en' ? 'Memory Card: "Apple"' : '"Alma"'}
        </h3>
        <p style={{
          fontSize: '14px',
          margin: '5px 0 10px',
          color: '#555',
        }}>
          {language === 'en' 
            ? '"I saw a red apple in the café yesterday."' 
            : '"Tegnap láttam egy piros almát a kávézóban."'}
        </p>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: '12px',
          color: '#888',
        }}>
          <span>Voc2Go</span>
          <span>#{Math.floor(Math.random() * 1000) + 1}</span>
        </div>
      </div>
      <div style={{
        position: 'absolute',
        right: '-10px',
        top: '-10px',
        backgroundColor: '#F7941D',
        color: 'white',
        borderRadius: '50%',
        width: '36px',
        height: '36px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '14px',
        fontWeight: 'bold',
        boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
      }}>
        NEW
      </div>
    </div>
  );
};

export default MemoryCard;