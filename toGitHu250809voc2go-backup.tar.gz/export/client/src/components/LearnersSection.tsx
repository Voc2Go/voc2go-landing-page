import React from "react";
import { useLanguage } from "../context/LanguageContext";
import PlanComparisonSection from "./PlanComparisonSection";
import VocFutureSection from "./VocFutureSection";
import PayAsYouGoSection from "./PayAsYouGoSection";
import PersonasSection from "./PersonasSection";


const LearnersSection: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <section id="learners" className="learners-section" style={{ paddingTop: "0" }}>
      {/* PersonasSection starts the page */}
      <PersonasSection />
      
      <div className="container">
        {/* Pay As You Go Section */}
        <div style={{ marginTop: '40px' }}>
          <PayAsYouGoSection />
        </div>
        
        {/* Plan Comparison Section */}
        <PlanComparisonSection className="standalone-plan-section" />
      </div>
      
      {/* Voc2Go Future Section - Last section */}
      <VocFutureSection />
    </section>
  );
};

export default LearnersSection;