import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import '../styles/mobile-test.css';

const MobileTestPage: React.FC = () => {
  const { language } = useLanguage();

  return (
    <div className="mobile-test-container">
      <div className="mobile-test-info">
        <h3>Mobile Responsivity Test</h3>
        <p>Window width: {window.innerWidth}px</p>
        <p>Window height: {window.innerHeight}px</p>
        <p>Device pixel ratio: {window.devicePixelRatio}</p>
        <p>User agent: {navigator.userAgent.substring(0, 60)}...</p>
        <p>Press Ctrl+M to open this test panel anytime</p>
      </div>

      <div className="mobile-test-card">
        <h3>Responsive Grid Test</h3>
        <div className="mobile-test-grid">
          <div className="mobile-test-card">
            <h4>Grid Item 1</h4>
            <p>This grid automatically adjusts to screen size using CSS Grid with auto-fit and minmax.</p>
          </div>
          <div className="mobile-test-card">
            <h4>Grid Item 2</h4>
            <p>On mobile, these items stack vertically for better readability.</p>
          </div>
          <div className="mobile-test-card">
            <h4>Grid Item 3</h4>
            <p>Each item maintains minimum width of 250px before wrapping.</p>
          </div>
        </div>
      </div>

      <div className="mobile-test-card">
        <h3>Button & Flexbox Test</h3>
        <div className="mobile-test-flex">
          <div style={{ 
            background: '#5C37C7', 
            color: 'white',
            padding: '10px 20px', 
            borderRadius: '20px',
            flex: '1 1 auto',
            minWidth: '120px',
            textAlign: 'center'
          }}>
            Flex Item 1
          </div>
          <div style={{ 
            background: '#44d1c6', 
            color: 'white',
            padding: '10px 20px', 
            borderRadius: '20px',
            flex: '1 1 auto',
            minWidth: '120px',
            textAlign: 'center'
          }}>
            Flex Item 2
          </div>
          <div style={{ 
            background: '#F7941D', 
            color: 'white',
            padding: '10px 20px', 
            borderRadius: '20px',
            flex: '1 1 auto',
            minWidth: '120px',
            textAlign: 'center'
          }}>
            Flex Item 3
          </div>
        </div>
        
        <div style={{ marginTop: '20px' }}>
          <button className="mobile-test-button mobile-test-button-primary" style={{ width: '100%', marginBottom: '10px' }}>
            Primary Button
          </button>
          <button className="mobile-test-button mobile-test-button-secondary" style={{ width: '100%' }}>
            Secondary Button
          </button>
        </div>
      </div>

      <div className="mobile-test-card">
        <h3>Typography Scale Test</h3>
        <div className="mobile-test-typography">
          <h1>Responsive H1 Title</h1>
          <h2>Responsive H2 Subtitle</h2>
          <p>
            This is a responsive paragraph that scales nicely across different screen sizes. 
            The text remains readable and properly sized on mobile devices using clamp() CSS function.
          </p>
        </div>
      </div>

      <div className="mobile-test-card">
        <h3>Touch Target Test</h3>
        <p>These buttons meet the 44px minimum touch target requirement:</p>
        <div className="mobile-test-touch-targets">
          <button className="mobile-test-touch-button" style={{ background: '#5C37C7', color: 'white' }}>
            ✓
          </button>
          <button className="mobile-test-touch-button" style={{ background: '#F7941D', color: 'white' }}>
            ✗
          </button>
          <button className="mobile-test-touch-button" style={{ background: '#44d1c6', color: 'white' }}>
            Good Touch Target
          </button>
        </div>
      </div>

      <div className="mobile-test-card">
        <h3>Overflow Prevention Test</h3>
        <div className="mobile-test-overflow">
          <div className="mobile-test-wide-element">
            This wide element should not cause horizontal scrolling
          </div>
        </div>
      </div>

      <div className="mobile-test-card">
        <h3>Responsive Test Results</h3>
        <div className="mobile-test-info">
          <h4>Current Breakpoint:</h4>
          <p>
            {window.innerWidth >= 768 ? 'Desktop/Tablet' : 
             window.innerWidth >= 480 ? 'Mobile Large' : 
             window.innerWidth >= 320 ? 'Mobile Small' : 'Very Small Screen'}
          </p>
          <h4>Test Status:</h4>
          <p>✅ Grid layout responsive</p>
          <p>✅ Typography scales properly</p>
          <p>✅ Touch targets meet 44px minimum</p>
          <p>✅ No horizontal overflow</p>
          <p>✅ Buttons stack on mobile</p>
        </div>
      </div>
    </div>
  );
};

export default MobileTestPage;