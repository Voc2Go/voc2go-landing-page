import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import logo from "@assets/JoV2VLogo240815.png";
import { Facebook, Instagram, Mail, Lock } from "lucide-react";

interface FooterProps {
  onAdminClick?: () => void;
}

const Footer: React.FC<FooterProps> = ({ onAdminClick }) => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-logo">
            <img src={logo} alt="VOC2GO" className="logo" />
          </div>
          
          <div className="footer-links">
            <div className="footer-section">
              <h3>{getContentText('footer-navigation', language === 'en' ? "Navigation" : "Navigáció")}</h3>
              <ul>
                <li><a href="#home" onClick={(e) => {
                  e.preventDefault();
                  window.dispatchEvent(new CustomEvent('navigate', { detail: 'home' }));
                }}>{t("Features")}</a></li>
                <li><a href="#learners" onClick={(e) => {
                  e.preventDefault();
                  window.dispatchEvent(new CustomEvent('navigate', { detail: 'learners' }));
                }}>{t("App Screenshots")}</a></li>
                <li><a href="#supporters" onClick={(e) => {
                  e.preventDefault();
                  window.dispatchEvent(new CustomEvent('navigate', { detail: 'supporters' }));
                }}>{t("Campaign")}</a></li>
                <li><a href="#supporters" onClick={(e) => {
                  e.preventDefault();
                  window.dispatchEvent(new CustomEvent('navigate', { detail: 'supporters' }));
                }}>{t("Roadmap")}</a></li>
                <li><a href="#contact" onClick={(e) => {
                  e.preventDefault();
                  window.dispatchEvent(new CustomEvent('navigate', { detail: 'contact' }));
                }}>{t("Feedback")}</a></li>
              </ul>
              
              <h3 className="mt-4">{getContentText('footer-legal', language === 'en' ? "Legal" : "Jogi")}</h3>
              <ul>
                <li><a href="#" onClick={(e) => {
                  e.preventDefault();
                  const termsUrl = language === 'hu' ? '/terms-hu.html' : '/terms-en.html';
                  window.open(termsUrl, '_blank');
                }}>{t("Terms of Use")}</a></li>
                <li><a href="#" onClick={(e) => {
                  e.preventDefault();
                  const privacyUrl = language === 'hu' ? '/privacy-hu.html' : '/privacy-en.html';
                  window.open(privacyUrl, '_blank');
                }}>{t("Privacy Policy")}</a></li>
                <li><a href="#" onClick={(e) => {
                  e.preventDefault();
                  const cookieUrl = language === 'hu' ? '/cookie-hu.html' : '/cookie-en.html';
                  window.open(cookieUrl, '_blank');
                }}>{t("Cookie Policy")}</a></li>
              </ul>
            </div>
            
            <div className="footer-section">
              <h3>{getContentText('footer-contact', language === 'en' ? "Contact" : "Kapcsolat")}</h3>
              <ul>
                <li><a href="mailto:voc2go@gmail.com"><Mail size={16} /> voc2go@gmail.com</a></li>
                <li>
                  <a 
                    href="#" 
                    className="admin-link" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (onAdminClick) onAdminClick();
                    }}
                  >
                    <Lock size={16} /> Admin Login
                  </a>
                </li>
              </ul>
              
              <h3 className="mt-4">{getContentText('footer-follow', language === 'en' ? "Follow Us" : "Kövess Minket")}</h3>
              <div className="social-icons">
                <a href="https://facebook.com/voc2go" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                  <Facebook size={20} />
                </a>

                <a href="https://instagram.com/voc2go" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                  <Instagram size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p className="copyright">{getContentText('footer-copyright', language === 'en' ? "© 2025 Voc2Go by Circular Innovation Hub. All rights reserved." : "© 2025 Voc2Go by Circular Innovation Hub. Minden jog fenntartva.")}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;