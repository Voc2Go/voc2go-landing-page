import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { CheckCircle, Circle, Clock, AlertCircle } from "lucide-react";

interface RoadmapPhaseProps {
  phase: string;
  description: string;
  status: string;
  statusColor: string;
  statusIcon: React.ReactNode;
  isActive: boolean;
  isRight: boolean;
  delay: number;
}

const RoadmapPhase: React.FC<RoadmapPhaseProps> = ({ 
  phase, 
  description, 
  status, 
  statusColor, 
  statusIcon, 
  isActive,
  isRight,
  delay
}) => {
  const { t } = useLanguage();
  
  return (
    <div 
      className={`roadmap-item ${isActive ? 'active' : ''} ${isRight ? 'right' : 'left'}`}
      style={{ 
        animationDelay: `${delay}s`,
        opacity: 0,
        animation: 'fadeInUp 0.5s ease forwards'
      }}
    >
      <div className="roadmap-content">
        <h3>{t(phase)}</h3>
        <p>{t(description)}</p>
        <div className="status-badge" style={{ backgroundColor: statusColor }}>
          {statusIcon}
          <span>{t(status)}</span>
        </div>
      </div>
      <div className="roadmap-dot"></div>
    </div>
  );
};

const RoadmapSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  
  const phases = [
    {
      phase: "Research Phase",
      description: "Researching effective learning methods and user needs",
      status: "Completed",
      statusColor: "#4CAF50",
      statusIcon: <CheckCircle size={16} />,
      isActive: true,
      isRight: false,
      delay: 0.1
    },
    {
      phase: "Development Phase",
      description: "Building the core features and user interface",
      status: "In Progress",
      statusColor: "#2196F3",
      statusIcon: <Clock size={16} />,
      isActive: true,
      isRight: true,
      delay: 0.3
    },
    {
      phase: "Testing Phase",
      description: "Beta testing with real users to improve the experience",
      status: "Planned",
      statusColor: "#FFC107",
      statusIcon: <Circle size={16} />,
      isActive: false,
      isRight: false,
      delay: 0.5
    },
    {
      phase: "Launch Phase",
      description: "Official release and marketing campaign",
      status: "Planned",
      statusColor: "#FFC107",
      statusIcon: <Circle size={16} />,
      isActive: false,
      isRight: true,
      delay: 0.7
    }
  ];

  return (
    <section id="roadmap" className="roadmap-section">
      <div className="container">
        <div className="section-header">
          <h2>{t("Development Roadmap")}</h2>
          <p>{t("Our journey to create the ultimate language learning app")}</p>
        </div>

        <div className="roadmap-timeline">
          <div className="roadmap-line"></div>
          
          {phases.map((phase, index) => (
            <RoadmapPhase 
              key={index}
              phase={phase.phase}
              description={phase.description}
              status={phase.status}
              statusColor={phase.statusColor}
              statusIcon={phase.statusIcon}
              isActive={phase.isActive}
              isRight={phase.isRight}
              delay={phase.delay}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default RoadmapSection;