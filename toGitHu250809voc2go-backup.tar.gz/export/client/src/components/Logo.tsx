import React from 'react';

// Creating an SVG version of the logo based on the provided PNG
const Logo: React.FC<{ className?: string }> = ({ className = "h-12" }) => {
  return (
    <svg 
      width="240" 
      height="240" 
      viewBox="0 0 240 240" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="voc2goGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2D0051" />
          <stop offset="50%" stopColor="#5C37C7" />
          <stop offset="100%" stopColor="#44d1c6" />
        </linearGradient>
      </defs>
      <rect 
        width="240" 
        height="240" 
        rx="40" 
        fill="url(#voc2goGradient)" 
      />
      <text 
        x="50%" 
        y="40%" 
        dominantBaseline="middle" 
        textAnchor="middle" 
        fill="white" 
        fontFamily="'Arial Black', sans-serif" 
        fontSize="60"
        fontWeight="bold"
      >
        VOC
      </text>
      <text 
        x="50%" 
        y="70%" 
        dominantBaseline="middle" 
        textAnchor="middle" 
        fill="white" 
        fontFamily="'Arial Black', sans-serif" 
        fontSize="65"
        fontWeight="bold"
      >
        2GO
      </text>
      <path 
        d="M 240,200 L 220,200 Q 200,240 170,240 L 40,240 Q 0,240 0,200 L 40,240 Z" 
        fill="url(#voc2goGradient)" 
      />
    </svg>
  );
};

export default Logo;
