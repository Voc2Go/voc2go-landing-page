import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Facebook, Instagram, Globe, Heart, Users, Star } from "lucide-react";

const SupportSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  
  // Support tier data - updated with correct pricing and descriptions
  const supportTiers = [
    {
      title: getContentText('support-tier-1-title', language === 'en' ? "Early Bird" : "Korai Madár"),
      description: getContentText('support-tier-1-desc', language === 'en' 
        ? "Get early access to Voc2Go when it launches + special supporter badge" 
        : "Korai hozzáférés a Voc2Go-hoz + különleges támogatói jelvény"),
      price: getContentText('support-tier-1-price', "$15"),
      limitText: getContentText('support-tier-1-limit', language === 'en' ? "Limited early access" : "Korlátozott korai hozzáférés"),
      icon: <Heart size={24} />,
      delay: 0.1
    },
    {
      title: getContentText('support-tier-2-title', language === 'en' ? "Vocabulary Explorer" : "Szókincs Felfedező"),
      description: getContentText('support-tier-2-desc', language === 'en' 
        ? "MVP access + 15 hours premium learning + community access" 
        : "MVP hozzáférés + 15 óra prémium tanulás + közösségi hozzáférés"),
      price: getContentText('support-tier-2-price', "$50"),
      limitText: getContentText('support-tier-2-limit', language === 'en' ? "Perfect for trying the full experience" : "Tökéletes a teljes élmény kipróbálásához"),
      icon: <Users size={24} />,
      delay: 0.2
    },
    {
      title: getContentText('support-tier-3-title', language === 'en' ? "Learning Champion" : "Tanulási Bajnok"),
      description: getContentText('support-tier-3-desc', language === 'en' 
        ? "MVP access + 50 hours premium + exclusive features + priority support" 
        : "MVP hozzáférés + 50 óra prémium + exkluzív funkciók + elsőbbségi támogatás"),
      price: getContentText('support-tier-3-price', "$150"),
      limitText: getContentText('support-tier-3-limit', language === 'en' ? "Most popular choice" : "Legnépszerűbb választás"),
      icon: <Star size={24} />,
      delay: 0.3,
      featured: true
    },
    {
      title: getContentText('support-tier-4-title', language === 'en' ? "Language Master" : "Nyelvi Mester"),
      description: getContentText('support-tier-4-desc', language === 'en' 
        ? "Everything above + 150 hours premium + beta access to new features + direct feedback channel" 
        : "Minden a fentiekből + 150 óra prémium + béta hozzáférés új funkciókhoz + közvetlen visszajelzési csatorna"),
      price: getContentText('support-tier-4-price', "$400"),
      limitText: getContentText('support-tier-4-limit', language === 'en' ? "For serious learners" : "Komoly tanulóknak"),
      icon: <Star size={24} />,
      delay: 0.4
    },
    {
      title: getContentText('support-tier-5-title', language === 'en' ? "Voc2Go Founder" : "Voc2Go Alapító"),
      description: getContentText('support-tier-5-desc', language === 'en' 
        ? "Lifetime premium access + influence on roadmap + special recognition + 10 gift licenses" 
        : "Élethosszig tartó prémium hozzáférés + befolyás a fejlesztési útvonalra + különleges elismerés + 10 ajándék licensz"),
      price: getContentText('support-tier-5-price', "$1,000"),
      limitText: getContentText('support-tier-5-limit', language === 'en' ? "Limited to 50 founders" : "Korlátozva 50 alapítóra"),
      icon: <Star size={24} />,
      delay: 0.5,
      featured: true
    }
  ];
  
  return (
    <section id="support" className="support-section px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20" style={{
      background: "linear-gradient(135deg, rgba(45, 0, 81, 0.97) 0%, rgba(92, 55, 199, 0.97) 100%)",
      color: "white",
      position: "relative",
      overflow: "hidden"
    }}>
      <div className="container max-w-7xl mx-auto">
        <div className="section-header text-center mb-12 sm:mb-16 lg:mb-20">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-4 sm:mb-6 font-bold" style={{color: "#FF7518"}}>
            {getContentText('support-heading', language === 'en' ? "Support Voc2Go's Development" : "Segíts, hogy elindulhassunk")}
          </h2>
          
          <div className="max-w-3xl mx-auto leading-relaxed text-base sm:text-lg lg:text-xl">
            <p>
              {getContentText('support-description', language === 'en' 
                ? "We've designed the full learning journey and built a talented creative + development team. We're ready to build the MVP — but need your help to bring it to life. Funding goal: $35,000"
                : "A rendszer kész, tehetséges kreatív és fejlesztői csapattal rendelkezünk. Készen állunk az MVP elkészítésére – de szükségünk van a segítségedre, hogy életre keltsük. Finanszírozási cél: 35 000 USD"
              )}
            </p>
          </div>
        </div>


        
        <div className="mb-12 sm:mb-16 lg:mb-20">
          <h3 className="text-xl sm:text-2xl lg:text-3xl mb-6 sm:mb-8 text-center" style={{color: "#44d1c6"}}>
            {getContentText('support-levels-title', language === 'en' ? "Support Levels" : "Támogatási szintek")}
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 max-w-7xl mx-auto">
            {supportTiers.map((tier, index) => (
              <div 
                key={index} 
                className={`
                  rounded-xl sm:rounded-2xl p-4 sm:p-6 lg:p-8 
                  backdrop-blur-md border
                  transition-all duration-300 hover:scale-105 hover:shadow-2xl
                  ${tier.featured 
                    ? 'bg-gradient-to-br from-orange-500/20 to-orange-600/10 border-orange-500/30 shadow-orange-500/20' 
                    : 'bg-white/10 border-white/20 shadow-black/20'
                  }
                  shadow-xl
                `}
                style={{
                  animation: `fadeInUp 0.6s ease forwards ${tier.delay}s`,
                  opacity: 0
                }}
              >
                {tier.featured && (
                  <div className="absolute top-3 right-3 bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-bold z-10">
                    {language === 'en' ? "BEST VALUE" : "LEGJOBB ÉRTÉK"}
                  </div>
                )}
                
                <div className="flex justify-center mb-4 sm:mb-6">
                  <div className={`
                    w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-white
                    ${tier.featured ? 'bg-orange-500' : 'bg-teal-400'}
                  `}>
                    {tier.icon}
                  </div>
                </div>
                
                <h4 className={`
                  text-lg sm:text-xl lg:text-2xl font-bold text-center mb-2
                  ${tier.featured ? 'text-orange-500' : 'text-white'}
                `}>
                  {tier.title}
                </h4>
                
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-center my-3 sm:my-4 text-white">
                  {tier.price}
                </div>
                
                <p className="text-center mb-2 sm:mb-4 leading-relaxed text-white/80 min-h-[60px] text-sm sm:text-base">
                  {tier.description}
                </p>
                
                {tier.limitText && (
                  <p className={`
                    text-center mb-4 sm:mb-6 text-sm font-semibold
                    ${tier.featured ? 'text-orange-500' : 'text-teal-400'}
                  `}>
                    {tier.limitText}
                  </p>
                )}
                
                <div className="text-center">
                  <a
                    href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`
                      inline-block px-4 py-2 sm:px-6 sm:py-3 rounded-lg text-white 
                      font-semibold transition-all duration-300 hover:scale-105 no-underline
                      text-sm sm:text-base
                      ${tier.featured 
                        ? 'bg-orange-500 hover:bg-orange-600' 
                        : 'bg-white/15 hover:bg-white/25 border border-white/30'
                      }
                    `}
                  >
                    {language === 'en' ? "Select" : "Választom"}
                  </a>
                </div>
              </div>
            ))}
          </div>
          
          <p className="text-center mt-6 sm:mt-8 lg:mt-12 max-w-3xl mx-auto text-white/80 text-sm sm:text-base">
            {language === 'en'
              ? "All tiers receive beta access for further developments, learning insights, and the opportunity to test features before launch."
              : "Minden támogatónk hozzáfér a kulisszák mögötti fejlesztésekhez, nyelvtanulási tippekhez és a teszteléshez."
            }
          </p>
        </div>
        

        <div className="text-center mt-8 sm:mt-12 lg:mt-16">
          <h4 className="text-lg sm:text-xl mb-4 sm:mb-6 text-white/90">
            {language === 'en' ? "Follow Us:" : "Kövess minket:"}
          </h4>
          
          <div className="flex justify-center gap-4 sm:gap-6 mb-4 sm:mb-6">
            <a
              href="https://www.facebook.com/profile.php?id=61565586517616"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 flex items-center justify-center text-white transition-all duration-300 hover:bg-white/20 hover:scale-110"
            >
              <Facebook size={18} />
            </a>
            
            <a
              href="https://www.instagram.com/voc2go24/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/10 flex items-center justify-center text-white transition-all duration-300 hover:bg-white/20 hover:scale-110"
            >
              <Instagram size={18} />
            </a>
          </div>
          
          <div className="text-white/80 text-sm sm:text-base">
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <Globe size={16} />
              <span>{language === 'en' ? "Visit us at:" : "Weboldal:"} </span>
              <a 
                href="http://www.voc2go.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-teal-400 no-underline hover:text-teal-300 transition-colors"
              >
                www.voc2go.com
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Background decorations */}
      <div style={{
        position: "absolute",
        width: "400px",
        height: "400px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(68, 209, 198, 0.2) 0%, rgba(68, 209, 198, 0) 70%)",
        top: "-150px",
        right: "-150px",
        zIndex: 1
      }}></div>
      
      <div style={{
        position: "absolute",
        width: "500px",
        height: "500px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(255, 117, 24, 0.1) 0%, rgba(255, 117, 24, 0) 70%)",
        bottom: "-200px",
        left: "-200px",
        zIndex: 1
      }}></div>
    </section>
  );
};

export default SupportSection;