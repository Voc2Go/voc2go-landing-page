import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Check, Star, Sparkles, Crown, Heart } from "lucide-react";
import MemoryCard from "./MemoryCard";
import vicImage from "@assets/Vic11.04_1752753806261.png";

interface PlanComparisonProps {
  className?: string;
}

const PlanComparisonSection: React.FC<PlanComparisonProps> = ({ className = "" }) => {
  const { language } = useLanguage();
  const { getContentText } = useContent();
  const [activeFeature, setActiveFeature] = useState<number | null>(null);
  const [isInView, setIsInView] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  
  // Check for mobile screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  // Hungarian translations for the comparison section
  const hungarianTranslations: Record<string, string> = {
    "FREEMIUM": "FREEMIUM",
    "Vic tracks your progress and brings up past words to practice": "Vic nyomon követi a fejlődésedet és gyakoroljátok a korábban tanult szavakat",
    "DISCOVER NEW WORDS": "FEDEZZ FEL ÚJ SZAVAKAT",
    "BUILD YOUR WORD BANK": "ÉPÍTSD A SZÓKINCSED",
    "GET PRACTICE SESSIONS": "GYAKORLÓ FELADATOKAT KAPSZ",
    "GET YOUR MEMORY CARD": "MEMÓRIAKÁRTYÁT KAPSZ",
    "GET YOUR MEMORY CAR AND A GENERATED PICTURE GOING WITH IT": "KAPD MEG A MEMÓRIA AUTÓDAT ÉS A HOZZÁ TARTOZÓ GENERÁLT KÉPET",
    
    "PREMIUM": "PREMIUM",
    "Every word you learn is connected to your life": "Minden szó, amit megtanulsz, kapcsolódik az életedhez",
    "NEW LESSON BUILDS ON WHAT YOU ALREADY LEARNED": "AZ ÚJ LECKE ARRA ÉPÍT, AMIT MÁR MEGTANULTÁL",
    "YOUR CONVERSATIONS GROW INTO RICHER STORIES": "BESZÉLGETÉSEID TÖRTÉNETEKKÉ FEJLŐDNEK",
    "**ÉLŐ NYELVTANULÁS**": "**ÉLŐ NYELVTANULÁS**",
    "MASTER TRICKY WORDS AND SYNONYMS": "SAJÁTÍTSD EL A NEHÉZ SZAVAKAT ÉS SZINONIMÁKAT",
    "CONVERSATION PRACTICE WITH VIC'S TIPS": "BESZÉLGETÉSI GYAKORLAT VIC TIPPJEIVEL",
    "AUDIO LESSONS FOR BUSY DAYS": "AUDIO LECKÉK ELFOGLALT NAPOKRA",
    "Choose Your Plan": "Válaszd Ki a Csomagod",
    "Compare our options and find the best fit for your learning journey": "",
    "RECOMMENDED": "AJÁNLOTT",
    "FREE": "INGYENES",
    "UPGRADE NOW": "FRISSÍTS MOST"
  };
  
  // Translate function for the comparison section
  const translate = (text: string): string => {
    return language === 'en' ? text : hungarianTranslations[text] || text;
  };
  
  const premiumFeatures = [
    getContentText('premium-feature-1', language === 'en' ? 'NEW LESSON BUILDS ON WHAT YOU ALREADY LEARNED' : 'AZ ÚJ LECKE ARRA ÉPÍT, AMIT MÁR MEGTANULTÁL'),
    getContentText('premium-feature-2', language === 'en' ? 'YOUR CONVERSATIONS GROW INTO RICHER STORIES' : 'BESZÉLGETÉSEID TÖRTÉNETEKKÉ FEJLŐDNEK'),
    getContentText('premium-feature-3', language === 'en' ? '**ÉLŐ NYELVTANULÁS**' : '**ÉLŐ NYELVTANULÁS**'),
    getContentText('premium-feature-4', language === 'en' ? 'MASTER TRICKY WORDS AND SYNONYMS' : 'SAJÁTÍTSD EL A NEHÉZ SZAVAKAT ÉS SZINONIMÁKAT'),
    getContentText('premium-feature-5', language === 'en' ? 'CONVERSATION PRACTICE WITH VIC\'S TIPS' : 'BESZÉLGETÉSI GYAKORLAT VIC TIPPJEIVEL'),
    getContentText('premium-feature-6', language === 'en' ? 'AUDIO LESSONS FOR BUSY DAYS' : 'AUDIO LECKÉK ELFOGLALT NAPOKRA')
  ];

  const freemiumFeatures = [
    getContentText('freemium-feature-1', language === 'en' ? 'DISCOVER NEW WORDS' : 'FEDEZZ FEL ÚJ SZAVAKAT'),
    getContentText('freemium-feature-2', language === 'en' ? 'BUILD YOUR WORD BANK' : 'ÉPÍTSD A SZÓKINCSED'),
    getContentText('freemium-feature-3', language === 'en' ? 'GET PRACTICE SESSIONS' : 'GYAKORLÓ FELADATOKAT KAPSZ'),
    getContentText('freemium-feature-4', language === 'en' ? 'GET YOUR MEMORY CARD' : 'MEMÓRIAKÁRTYÁT KAPSZ')
  ];

  // Animation for section entrance
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.2 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => observer.disconnect();
  }, []);
  
  // Auto-cycling animation for premium features
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isInView && premiumFeatures.length > 0) {
      interval = setInterval(() => {
        setActiveFeature(prev => {
          if (prev === null || prev >= premiumFeatures.length - 1) {
            return 0;
          }
          return prev + 1;
        });
      }, 2500);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isInView, premiumFeatures.length]);

  return (
    <div 
      ref={sectionRef}
      className={`plan-comparison-section ${className}`}
      style={{ 
        marginTop: '80px',
        padding: isMobile ? '40px 15px' : '60px 20px',
        background: 'linear-gradient(135deg, #4F3993 0%, #2D0051 100%)',
        borderRadius: '20px',
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translateY(0)' : 'translateY(50px)',
        transition: 'opacity 0.8s ease-out, transform 0.8s ease-out',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div
        className="gradient-overlay"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          opacity: 0.2,
          background:
            "radial-gradient(circle at 20% 30%, rgba(130, 210, 250, 0.5) 0%, transparent 30%), " +
            "radial-gradient(circle at 80% 70%, rgba(79, 57, 147, 0.5) 0%, transparent 40%)",
          zIndex: 1,
        }}
      ></div>

      <div style={{ position: 'relative', zIndex: 2 }}>
      {/* Header Section */}
      <div style={{ textAlign: 'center', marginBottom: '50px' }}>
        <h2 style={{ 
          fontSize: isMobile ? '28px' : '38px',
          marginBottom: '15px',
          color: 'white',
          display: 'inline-block',
          padding: '0 10px'
        }}>
          {getContentText('choose-plan-title', language === 'en' ? 'Meet Vic, Your AI Language Teacher' : 'Ismerje meg Vicit, az AI nyelvtanárod')}
        </h2>
        
        <p style={{
          fontSize: isMobile ? '16px' : '18px',
          color: 'rgba(255, 255, 255, 0.9)',
          maxWidth: '600px',
          margin: '0 auto',
          lineHeight: '1.6'
        }}>
          {getContentText('choose-plan-subtitle', 
            language === 'en' 
              ? 'Vic adapts to your learning style and grows with you through every conversation'
              : 'Vic alkalmazkodik a tanulási stílusodhoz és minden beszélgetésen keresztül veled fejlődik'
          )}
        </p>
      </div>

      {/* Three-Column Layout: Freemium | Vic | Premium */}
      <div style={{ 
        display: 'grid',
        gridTemplateColumns: isMobile ? '1fr' : '1fr 300px 1fr',
        gap: isMobile ? '30px' : '20px',
        alignItems: 'center',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        
        {/* Freemium Plan */}
        <div style={{
          background: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)',
          borderRadius: '20px',
          padding: isMobile ? '30px 20px' : '40px 30px',
          border: '2px solid #dee2e6',
          position: 'relative',
          opacity: isInView ? 1 : 0,
          transform: isInView ? 'translateX(0)' : 'translateX(-30px)',
          transition: 'opacity 0.8s ease-out, transform 0.8s ease-out',
          minHeight: '400px'
        }}>
          <div style={{
            background: 'linear-gradient(135deg, #6c757d 0%, #495057 100%)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '20px',
            fontSize: '14px',
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: '20px',
            display: 'inline-block'
          }}>
            {getContentText('plan-free-text', language === 'en' ? 'FREE' : 'INGYENES')}
          </div>
          
          <h3 style={{
            fontSize: isMobile ? '24px' : '28px',
            fontWeight: 'bold',
            color: '#495057',
            marginBottom: '15px'
          }}>
            {getContentText('freemium-title', 'FREEMIUM')}
          </h3>
          
          <p style={{
            color: '#6c757d',
            fontSize: '16px',
            marginBottom: '25px',
            lineHeight: '1.5'
          }}>
            {getContentText('freemium-subtitle', 
              language === 'en' 
                ? 'Start your journey with Vic and discover the basics of personalized learning'
                : 'Kezdd el utazásodat Vic-kel és fedezd fel a személyre szabott tanulás alapjait'
            )}
          </p>
          
          <ul style={{
            listStyle: 'none',
            padding: 0,
            margin: 0
          }}>
            {freemiumFeatures.map((feature, index) => (
              <li key={index} style={{
                display: 'flex',
                alignItems: 'center',
                marginBottom: '12px',
                fontSize: '14px',
                color: '#495057'
              }}>
                <div style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  background: '#6c757d',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: '12px',
                  flexShrink: 0
                }}>
                  <Check size={14} color="white" />
                </div>
                <span>{feature}</span>
              </li>
            ))}
          </ul>
          
          {/* Memory Card Visual */}
          <div style={{
            marginTop: '30px',
            transform: 'scale(0.8)',
            transformOrigin: 'center'
          }}>
            <MemoryCard />
          </div>
        </div>

        {/* Vic - Central Character */}
        <div style={{
          textAlign: 'center',
          position: 'relative',
          opacity: isInView ? 1 : 0,
          transform: isInView ? 'scale(1)' : 'scale(0.8)',
          transition: 'opacity 1s ease-out, transform 1s ease-out',
          order: isMobile ? -1 : 0
        }}>
          <div style={{
            position: 'relative',
            display: 'inline-block'
          }}>
            <img 
              src={vicImage} 
              alt="Vic - Your AI Language Teacher" 
              style={{
                width: isMobile ? '200px' : '280px',
                height: 'auto',
                borderRadius: '20px',
                boxShadow: '0 20px 40px rgba(0, 0, 0, 0.15)',
                background: 'linear-gradient(135deg, #4c3e99 0%, #2d5a87 50%, #1e4d72 100%)',
                padding: '10px'
              }}
            />
            
            {/* Floating elements around Vic */}
            <div style={{
              position: 'absolute',
              top: '10px',
              left: '-60px',
              background: 'rgba(255, 255, 255, 0.95)',
              borderRadius: '25px',
              padding: '8px 12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
              animation: 'float 3s ease-in-out infinite',
              fontSize: '12px',
              fontWeight: 'bold',
              color: '#301A4B',
              whiteSpace: 'nowrap',
              zIndex: 10
            }}>
              <Sparkles size={14} color="#667eea" style={{ marginRight: '6px' }} />
              {getContentText('vic-label', language === 'en' ? 'Vic, your virtual teacher' : 'Vic, a virtuális tanárod')}
            </div>
            
            <div style={{
              position: 'absolute',
              top: '60px',
              right: '-15px',
              background: 'rgba(255, 255, 255, 0.9)',
              borderRadius: '50%',
              width: '35px',
              height: '35px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
              animation: 'float 3s ease-in-out infinite 0.5s'
            }}>
              <Heart size={16} color="#e74c3c" />
            </div>
            
            <div style={{
              position: 'absolute',
              bottom: '40px',
              left: '-15px',
              background: 'rgba(255, 255, 255, 0.9)',
              borderRadius: '50%',
              width: '35px',
              height: '35px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
              animation: 'float 3s ease-in-out infinite 1s'
            }}>
              <Star size={16} color="#f39c12" />
            </div>
          </div>
        </div>

        {/* Premium Plan */}
        <div style={{
          background: 'linear-gradient(135deg, #e67e22 0%, #d35400 100%)',
          borderRadius: '20px',
          padding: isMobile ? '30px 20px' : '40px 30px',
          border: '2px solid #d35400',
          position: 'relative',
          color: 'white',
          opacity: isInView ? 1 : 0,
          transform: isInView ? 'translateX(0)' : 'translateX(30px)',
          transition: 'opacity 0.8s ease-out, transform 0.8s ease-out',
          minHeight: '400px'
        }}>
          <div style={{
            background: 'linear-gradient(135deg, #f39c12 0%, #e67e22 100%)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '20px',
            fontSize: '14px',
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: '20px',
            display: 'inline-block',
            position: 'relative'
          }}>
            <Crown size={16} style={{ marginRight: '6px' }} />
            {getContentText('plan-recommended-text', language === 'en' ? 'RECOMMENDED' : 'AJÁNLOTT')}
          </div>
          
          <h3 style={{
            fontSize: isMobile ? '24px' : '28px',
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '15px'
          }}>
            {getContentText('premium-title', 'PREMIUM')}
          </h3>
          
          <p style={{
            color: 'rgba(255, 255, 255, 0.9)',
            fontSize: '16px',
            marginBottom: '25px',
            lineHeight: '1.5'
          }}>
            {getContentText('premium-subtitle', 
              language === 'en' 
                ? 'Unlock Vic\'s full potential with advanced features and personalized learning paths'
                : 'Használd ki Vic teljes potenciálját fejlett funkciókkal és személyre szabott tanulási utakkal'
            )}
          </p>
          
          <ul style={{
            listStyle: 'none',
            padding: 0,
            margin: 0
          }}>
            {premiumFeatures.map((feature, index) => (
              <li key={index} style={{
                display: 'flex',
                alignItems: 'center',
                marginBottom: '12px',
                fontSize: '14px',
                color: 'white',
                backgroundColor: activeFeature === index ? 'rgba(255, 255, 255, 0.1)' : 'transparent',
                padding: '8px',
                borderRadius: '8px',
                transition: 'all 0.3s ease'
              }}>
                <div style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  background: activeFeature === index ? '#f39c12' : 'rgba(255, 255, 255, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: '12px',
                  flexShrink: 0,
                  transform: activeFeature === index ? 'scale(1.1)' : 'scale(1)',
                  transition: 'all 0.3s ease'
                }}>
                  <Star size={14} color="white" />
                </div>
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      </div>
    </div>
  );
};

export default PlanComparisonSection;