import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Cpu, BookOpen, Repeat, BarChart } from "lucide-react";
import PlanComparisonSection from "./PlanComparisonSection";
import MemoryCard from "./MemoryCard";
import cafeImage from "@assets/Pubd020425.png";
import libraryImage from "@assets/Pubd260325.png";
import cookingImage from "@assets/Pubd080125.png";

const FeaturesSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();

  const features = [
    {
      title: getContentText('feature-ai-title', language === 'en' ? "AI-Powered Learning" : "AI-Alapú Tanulás"),
      description: getContentText('feature-ai-desc', language === 'en' ? "Our AI adapts to your learning style and creates personalized study plans" : "Az AI-nk alkalmazkodik a tanulási stílusodhoz és személyre szabott tanulási tervet készít"),
      icon: <Cpu className="feature-icon" size={36} />,
      delay: 0.1
    },
    {
      title: getContentText('feature-context-title', language === 'en' ? "Real-Life Contexts" : "Valós Élethelyzetek"),
      description: getContentText('feature-context-desc', language === 'en' ? "Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios" : "Tanulj szavakat értelmes környezetben, mint kávézók, könyvtárak és utazási helyzetek"),
      icon: <BookOpen className="feature-icon" size={36} />,
      delay: 0.3
    },
    {
      title: getContentText('feature-spaced-title', language === 'en' ? "Spaced Repetition" : "Időzített Ismétlés"),
      description: getContentText('feature-spaced-desc', language === 'en' ? "Our scientifically-proven system ensures you remember words for the long term" : "Tudományosan bizonyított rendszerünk biztosítja a szavak hosszú távú megjegyzését"),
      icon: <Repeat className="feature-icon" size={36} />,
      delay: 0.5
    },
    {
      title: getContentText('feature-progress-title', language === 'en' ? "Progress Tracking" : "Előrehaladás Nyomon Követése"),
      description: getContentText('feature-progress-desc', language === 'en' ? "Track your learning journey with detailed statistics and achievements" : "Kövesd nyomon a tanulási utadat részletes statisztikákkal és eredményekkel"),
      icon: <BarChart className="feature-icon" size={36} />,
      delay: 0.7
    }
  ];

  return (
    <section id="features" className="features-section">
      <div className="container">
        <div className="section-header">
          <h2>{getContentText('features-heading', language === 'en' ? "Why Choose VOC2GO?" : "Miért válaszd a VOC2GO-t?")}</h2>
          <p>{getContentText('features-description', language === 'en' ? "Discover how our app makes language learning effective and enjoyable" : "Fedezd fel, hogyan teszi applikációnk hatékonnyá és élvezetessé a nyelvtanulást")}</p>
        </div>

        <div className="features-grid">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="feature-card"
              style={{ 
                animationDelay: `${feature.delay}s`,
                opacity: 0,
                animation: 'fadeInUp 0.5s ease forwards'
              }}
            >
              <div className="feature-icon-container">
                {feature.icon}
              </div>
              <h3>{t(feature.title)}</h3>
              <p>{t(feature.description)}</p>
            </div>
          ))}
        </div>
        
        {/* No Plan Comparison Section here - moved to LearnersSection */}
      </div>
    </section>
  );
};

export default FeaturesSection;