import React from "react";
import { useLanguage } from "../context/LanguageContext";
import logo from "@assets/JoV2VLogo240815.png";

interface AdminDashboardProps {
  onClose: () => void;
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, onLogout }) => {
  const { t } = useLanguage();
  
  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    onLogout();
  };
  
  return (
    <div className="admin-overlay">
      <div className="admin-container">
        <div className="admin-header">
          <img src={logo} alt="VOC2GO" className="admin-logo" />
          <h2>{t("Admin Dashboard")}</h2>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        
        <div className="admin-content">
          <div className="admin-welcome">
            <h3>{t("Welcome to VOC2GO Admin Dashboard")}</h3>
            <p>{t("Manage your website content, campaigns, and user data from this dashboard.")}</p>
            
            <button className="admin-logout-btn" onClick={handleLogout}>
              {t("Logout")}
            </button>
          </div>
          
          <div className="admin-stats">
            <div className="stat-card">
              <h4>{t("Subscribers")}</h4>
              <p className="stat-number">245</p>
            </div>
            <div className="stat-card">
              <h4>{t("Campaign Progress")}</h4>
              <p className="stat-number">35%</p>
              <div className="progress-bar">
                <div className="progress" style={{ width: "35%" }}></div>
              </div>
            </div>
            <div className="stat-card">
              <h4>{t("Media Files")}</h4>
              <p className="stat-number">12</p>
            </div>
          </div>
          
          <div className="admin-tabs">
            <div className="admin-tab active">{t("Dashboard")}</div>
            <div className="admin-tab">{t("Campaigns")}</div>
            <div className="admin-tab">{t("Media")}</div>
            <div className="admin-tab">{t("Subscribers")}</div>
            <div className="admin-tab">{t("Settings")}</div>
          </div>
          
          <div className="admin-main-content">
            <h3>{t("Recent Activity")}</h3>
            <ul className="activity-list">
              <li>{t("New subscriber")}: maria@example.com</li>
              <li>{t("Campaign")} "Early Bird" {t("received a new backer")}</li>
              <li>{t("New feedback received from")}: john@example.com</li>
              <li>{t("Website settings updated")}</li>
            </ul>
            
            <h3>{t("Quick Actions")}</h3>
            <div className="admin-actions">
              <button className="admin-button">{t("Manage Content")}</button>
              <button className="admin-button">{t("View Subscribers")}</button>
              <button className="admin-button">{t("Campaign Settings")}</button>
              <button className="admin-button">{t("Upload Media")}</button>
            </div>
            
            <p className="admin-note">
              <small>
                {t("This is a simplified admin interface. In a production environment, these buttons would connect to actual database operations and management features.")}
              </small>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;