import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import logo from "@assets/JoV2VLogo240815.png";
import { Menu, X } from "lucide-react";

const Header: React.FC = () => {
  const { t, language, setLanguage } = useLanguage();
  const { getContentText } = useContent();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("home");
  const [underlineStyle, setUnderlineStyle] = useState({ left: 0, width: 0 });
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const navLinksRef = useRef<HTMLDivElement>(null);
  
  // Toggle language between English and Hungarian
  const handleLanguageChange = () => {
    setLanguage(language === 'en' ? 'hu' : 'en');
  };
  
  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Update underline position based on active section
  const updateUnderlinePosition = () => {
    if (!navLinksRef.current) return;
    
    // Check if navigation is visible (not on mobile)
    const navContainer = navLinksRef.current;
    const containerStyles = window.getComputedStyle(navContainer);
    if (containerStyles.display === 'none') return;
    
    const activeLink = navLinksRef.current.querySelector(`[data-section="${activeSection}"]`) as HTMLElement;
    if (activeLink) {
      const containerRect = navContainer.getBoundingClientRect();
      let left: number, width: number;
      
      // For the campaign section, measure only the main text span, not the badge
      if (activeSection === 'campaign') {
        const mainTextSpan = activeLink.querySelector('span:first-child') as HTMLElement;
        if (mainTextSpan) {
          const spanRect = mainTextSpan.getBoundingClientRect();
          left = spanRect.left - containerRect.left;
          width = spanRect.width;

        } else {
          const linkRect = activeLink.getBoundingClientRect();
          left = linkRect.left - containerRect.left;
          width = linkRect.width;
        }
      } else {
        const linkRect = activeLink.getBoundingClientRect();
        left = linkRect.left - containerRect.left;
        width = linkRect.width;

      }
      
      if (width && width > 0 && containerRect.width > 0) {
        setUnderlineStyle({
          left: Math.max(0, left),
          width: Math.max(0, width)
        });
      }
    }
  };
  
  // Close mobile menu when clicking outside
  const handleClickOutside = (event: MouseEvent) => {
    if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node)) {
      setMobileMenuOpen(false);
    }
  };
  
  // Add scroll event listener with scrollspy functionality
  useEffect(() => {
    const handleScroll = () => {
      // Handle header style change on scroll
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
      
      // Detect current page from URL hash
      const currentHash = window.location.hash.slice(1) || "home";
      const validPages = ["home", "learners", "supporters", "project", "contact"];
      const currentPage = validPages.includes(currentHash) ? currentHash : "home";
      
      // Set active section based on current page
      setActiveSection(currentPage);
    };
    
    const handleHashChange = () => {
      handleScroll();
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', updateUnderlinePosition);
    window.addEventListener('hashchange', handleHashChange);
    
    // Initial check to set the active section
    handleScroll();
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', updateUnderlinePosition);
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  // Update underline position when active section or language changes
  useEffect(() => {
    // Use requestAnimationFrame to ensure DOM is fully rendered
    const frame = requestAnimationFrame(() => {
      const timer = setTimeout(() => {
        updateUnderlinePosition();
      }, 100);
      return () => clearTimeout(timer);
    });
    
    return () => cancelAnimationFrame(frame);
  }, [activeSection, language]);

  return (
    <header className={`site-header ${scrolled ? 'scrolled' : ''}`}>
      <div className="container nav-container">
        <div className="logo-container">
          <a href="#home">
            <img src={logo} alt="VOC2GO" className="logo" />
          </a>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="desktop-nav">
          <div className="nav-links" ref={navLinksRef} style={{ position: 'relative' }}>
            {language === 'en' ? (
              <>
                <a href="#home" className="nav-link" data-section="home">
                  <span style={{ color: activeSection === "home" ? "#F7941D" : "" }}>HOME</span>
                </a>
                <a href="#learners" className="nav-link" data-section="learners">
                  <span style={{ color: activeSection === "learners" ? "#F7941D" : "" }}>LEARNERS</span>
                </a>
                <a href="#supporters" className="nav-link" data-section="supporters">
                  <span style={{ color: activeSection === "supporters" ? "#F7941D" : "" }}>SUPPORTERS</span>
                  <span style={{ 
                    fontSize: '12px', 
                    backgroundColor: '#F7941D', 
                    color: 'white',
                    padding: '3px 8px',
                    borderRadius: '20px',
                    marginLeft: '5px',
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap'
                  }}>Join Campaign</span>
                </a>
                <a href="#project" className="nav-link" data-section="project">
                  <span style={{ color: activeSection === "project" ? "#F7941D" : "" }}>PROJECT</span>
                </a>
                <a href="#contact" className="nav-link" data-section="contact">
                  <span style={{ color: activeSection === "contact" ? "#F7941D" : "" }}>CONTACT</span>
                </a>
              </>
            ) : (
              <>
                <a href="#home" className="nav-link" data-section="home">
                  <span style={{ color: activeSection === "home" ? "#F7941D" : "" }}>FŐOLDAL</span>
                </a>
                <a href="#learners" className="nav-link" data-section="learners">
                  <span style={{ color: activeSection === "learners" ? "#F7941D" : "" }}>TANULÓK</span>
                </a>
                <a href="#supporters" className="nav-link" data-section="supporters">
                  <span style={{ color: activeSection === "supporters" ? "#F7941D" : "" }}>TÁMOGATÓK</span>
                  <span style={{ 
                    fontSize: '12px', 
                    backgroundColor: '#F7941D', 
                    color: 'white',
                    padding: '3px 8px',
                    borderRadius: '20px',
                    marginLeft: '5px',
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap'
                  }}>Kampány Csatlakozás</span>
                </a>
                <a href="#project" className="nav-link" data-section="project">
                  <span style={{ color: activeSection === "project" ? "#F7941D" : "" }}>PROJEKT</span>
                </a>
                <a href="#contact" className="nav-link" data-section="contact">
                  <span style={{ color: activeSection === "contact" ? "#F7941D" : "" }}>KAPCSOLAT</span>
                </a>
              </>
            )}
            
            {/* Animated underline */}
            <div 
              className="nav-underline"
              style={{
                position: 'absolute',
                bottom: '-2px',
                height: '3px',
                backgroundColor: '#F7941D',
                borderRadius: '1.5px',
                transition: 'all 0.3s ease',
                left: `${underlineStyle.left}px`,
                width: `${underlineStyle.width}px`,
                opacity: underlineStyle.width > 0 ? 1 : 0
              }}
            />
          </div>
        </nav>
        
        {/* Language Button moved to the far right */}
        <div style={{ marginLeft: 'auto' }}>
          <button 
            onClick={handleLanguageChange} 
            className="language-btn" 
            style={{ 
              backgroundColor: '#F7941D', 
              color: 'white',
              padding: '5px 12px',
              borderRadius: '4px',
              fontWeight: 'bold',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            {language === 'en' ? 'HU' : 'ANGOL'}
          </button>
        </div>
        
        {/* Mobile Menu Button */}
        <div className="mobile-menu-button">
          <button 
            onClick={toggleMobileMenu} 
            aria-label="Toggle menu" 
            className="hamburger-button"
            style={{ color: '#4FBDB7' }} // Light green/teal from VOC2GO palette
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <div 
          ref={mobileMenuRef}
          className={`mobile-nav ${mobileMenuOpen ? 'open' : ''}`}
        >
          <div className="mobile-nav-header">
            <img src={logo} alt="VOC2GO" className="logo" />
            <button onClick={toggleMobileMenu} className="close-mobile-menu">
              <X size={24} />
            </button>
          </div>
          
          <div className="mobile-nav-links">
            {language === 'en' ? (
              <>
                <a 
                  href="#home" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "home" ? "#F7941D" : "" }}
                >
                  HOME
                </a>
                <a 
                  href="#learners" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "learners" ? "#F7941D" : "" }}
                >
                  LEARNERS
                </a>
                <a 
                  href="#supporters" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    color: activeSection === "supporters" ? "#F7941D" : ""
                  }}
                >
                  SUPPORTERS
                  <span style={{ 
                    fontSize: '10px', 
                    backgroundColor: '#F7941D', 
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '20px',
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap'
                  }}>Join our Indiegogo</span>
                </a>
                <a 
                  href="#project" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "project" ? "#F7941D" : "" }}
                >
                  PROJECT
                </a>
                <a 
                  href="#contact" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "contact" ? "#F7941D" : "" }}
                >
                  CONTACT
                </a>
              </>
            ) : (
              <>
                <a 
                  href="#home" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "home" ? "#F7941D" : "" }}
                >
                  FŐOLDAL
                </a>
                <a 
                  href="#learners" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "learners" ? "#F7941D" : "" }}
                >
                  TANULÓK
                </a>
                <a 
                  href="#supporters" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    color: activeSection === "supporters" ? "#F7941D" : ""
                  }}
                >
                  TÁMOGATÓK
                  <span style={{ 
                    fontSize: '10px', 
                    backgroundColor: '#F7941D', 
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '20px',
                    fontWeight: 'bold',
                    whiteSpace: 'nowrap'
                  }}>Indiegogo kampány</span>
                </a>
                <a 
                  href="#project" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "project" ? "#F7941D" : "" }}
                >
                  PROJEKT
                </a>
                <a 
                  href="#contact" 
                  onClick={() => setMobileMenuOpen(false)} 
                  className="mobile-nav-link"
                  style={{ color: activeSection === "contact" ? "#F7941D" : "" }}
                >
                  KAPCSOLAT
                </a>
              </>
            )}
            
            <div className="mobile-nav-actions">
              <button 
                onClick={handleLanguageChange} 
                className="language-btn mobile"
                style={{ 
                  backgroundColor: '#F7941D', 
                  color: 'white',
                  padding: '8px 15px',
                  borderRadius: '4px',
                  fontWeight: 'bold'
                }}
              >
                {language === 'en' ? 'HU' : 'ANGOL'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;