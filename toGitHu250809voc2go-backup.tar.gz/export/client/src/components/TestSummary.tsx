import React from 'react';

const TestSummary: React.FC = () => {
  return (
    <div style={{
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      background: '#2196f3',
      color: 'white',
      padding: '15px 20px',
      borderRadius: '12px',
      boxShadow: '0 4px 20px rgba(33, 150, 243, 0.3)',
      zIndex: 9999,
      maxWidth: '300px',
      fontSize: '14px'
    }}>
      <div style={{ fontWeight: 'bold', marginBottom: '10px' }}>
        🧪 Testing Tools Available
      </div>
      <div style={{ marginBottom: '8px' }}>
        <kbd style={{ 
          background: 'rgba(255,255,255,0.2)', 
          padding: '2px 6px', 
          borderRadius: '3px',
          marginRight: '8px'
        }}>
          Ctrl+M
        </kbd>
        Mobile Responsivity Test
      </div>
      <div>
        <kbd style={{ 
          background: 'rgba(255,255,255,0.2)', 
          padding: '2px 6px', 
          borderRadius: '3px',
          marginRight: '8px'
        }}>
          Ctrl+A
        </kbd>
        Admin Functionality Test
      </div>
    </div>
  );
};

export default TestSummary;