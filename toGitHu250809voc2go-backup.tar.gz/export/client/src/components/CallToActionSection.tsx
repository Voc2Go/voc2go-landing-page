import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const CallToActionSection: React.FC = () => {
  const { language } = useLanguage();
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.trim(),
          source: 'cta',
          language: language,
        }),
      });

      if (response.ok) {
        setIsSubmitted(true);
        setEmail('');
        timeoutRef.current = setTimeout(() => {
          setIsSubmitted(false);
          setShowEmailForm(false);
        }, 3000);
      }
    } catch (error) {
      console.error('Error submitting email:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Cleanup effect
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <section className="py-16 px-4" style={{ backgroundColor: "#6a3de8" }}>
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="bg-white/10 p-8 md:p-12 rounded-2xl shadow-xl text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            {language === "en" 
              ? "Ready to Revolutionize Your Language Learning?" 
              : "Készen állsz, hogy forradalmasítsd a nyelvtanulásodat?"}
          </h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            {language === "en"
              ? "Join Voc2Go today and experience a smarter, more personalized way to master new languages."
              : "Csatlakozz a Voc2Go-hoz még ma, és tapasztald meg az okosabb, személyre szabottabb módját az új nyelvek elsajátításának."}
          </p>
          <div className="space-y-4 md:space-y-0 md:flex md:justify-center md:gap-4">
            {!showEmailForm ? (
              <>
                <a 
                  href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block py-3 px-8 bg-white text-purple-700 hover:bg-white/90 font-bold rounded-full transition duration-300 shadow-lg transform hover:-translate-y-1"
                >
                  {language === "en" ? "Support Our Campaign" : "Támogasd a kampányunkat"}
                </a>
                <a 
                  href="#learners" 
                  className="inline-block py-3 px-8 bg-transparent text-white border-2 border-white hover:bg-white/10 font-bold rounded-full transition duration-300 shadow-lg transform hover:-translate-y-1 flex items-center justify-center gap-2"
                >
                  {language === "en" ? "Learn More" : "Tudj meg többet"}
                  <ArrowRight size={16} />
                </a>
              </>
            ) : (
              <form onSubmit={handleEmailSubmit} className="w-full max-w-md mx-auto">
                {isSubmitted ? (
                  <div className="bg-green-500 text-white py-4 px-6 rounded-full text-center font-semibold">
                    {language === "en" ? "Thank you for your support!" : "Köszönjük a támogatást!"}
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={language === "en" ? "Enter your email..." : "Add meg az email címed..."}
                      className="py-3 px-4 rounded-full border-2 border-white/30 bg-white/10 text-white placeholder-white/70 focus:outline-none focus:border-white/80 transition duration-300"
                      required
                    />
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        className="flex-1 py-3 px-6 bg-white text-purple-700 hover:bg-white/90 font-bold rounded-full transition duration-300 shadow-lg transform hover:-translate-y-1 disabled:opacity-50"
                      >
                        {isSubmitting 
                          ? (language === "en" ? "Submitting..." : "Küldés...")
                          : (language === "en" ? "Join Campaign" : "Csatlakozás")
                        }
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowEmailForm(false)}
                        className="py-3 px-6 bg-transparent text-white border-2 border-white hover:bg-white/10 font-bold rounded-full transition duration-300"
                      >
                        {language === "en" ? "Cancel" : "Mégse"}
                      </button>
                    </div>
                  </div>
                )}
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CallToActionSection;