import React, { useState, useEffect } from "react";
import { useLanguage } from "../context/LanguageContext";
import { Clock } from "lucide-react";

const CountdownTimer: React.FC = () => {
  const { language } = useLanguage();
  
  // Campaign end date - set to 30 days from now for demo
  const campaignEndDate = new Date();
  campaignEndDate.setDate(campaignEndDate.getDate() + 30);
  
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = campaignEndDate.getTime() - now;

      if (distance > 0) {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const timeUnits = [
    { value: timeLeft.days, label: language === 'en' ? 'Days' : 'Nap' },
    { value: timeLeft.hours, label: language === 'en' ? 'Hours' : 'Óra' },
    { value: timeLeft.minutes, label: language === 'en' ? 'Minutes' : 'Perc' },
    { value: timeLeft.seconds, label: language === 'en' ? 'Seconds' : 'Másodperc' }
  ];

  return (
    <div style={{
      background: "linear-gradient(135deg, rgba(255, 117, 24, 0.1) 0%, rgba(255, 117, 24, 0.05) 100%)",
      borderRadius: "16px",
      padding: "30px",
      margin: "40px 0",
      border: "2px solid rgba(255, 117, 24, 0.2)",
      textAlign: "center"
    }}>
      <div style={{ 
        display: "flex", 
        alignItems: "center", 
        justifyContent: "center",
        gap: "10px",
        marginBottom: "20px"
      }}>
        <Clock size={24} style={{ color: "#FF7518" }} />
        <h3 style={{ 
          fontSize: "1.5rem", 
          color: "#FF7518",
          fontWeight: "bold",
          margin: "0"
        }}>
          {language === 'en' ? "Support VOC2GO's Development" : "Támogasd a VOC2GO Fejlesztését"}
        </h3>
      </div>
      
      <p style={{ 
        fontSize: "1.1rem", 
        color: "#666",
        marginBottom: "25px"
      }}>
        {language === 'en' 
          ? "Back us at any level for exclusive updates and early beta access—and our heartfelt thanks"
          : "Támogass bármilyen szinten exkluzív frissítésekért és korai béta hozzáférésért—és hálás köszönetünkért"
        }
      </p>
      
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: "15px",
        maxWidth: "400px",
        margin: "0 auto"
      }}>
        {timeUnits.map((unit, index) => (
          <div key={index} style={{
            background: "white",
            borderRadius: "12px",
            padding: "15px 10px",
            boxShadow: "0 4px 15px rgba(0, 0, 0, 0.1)",
            border: "1px solid rgba(255, 117, 24, 0.1)"
          }}>
            <div style={{
              fontSize: "1.8rem",
              fontWeight: "bold",
              color: "#FF7518",
              lineHeight: "1"
            }}>
              {unit.value.toString().padStart(2, '0')}
            </div>
            <div style={{
              fontSize: "0.8rem",
              color: "#666",
              fontWeight: "500",
              marginTop: "5px"
            }}>
              {unit.label}
            </div>
          </div>
        ))}
      </div>
      
      <div style={{ marginTop: "25px" }}>
        <a
          href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "inline-block",
            padding: "12px 30px",
            background: "#FF7518",
            color: "white",
            borderRadius: "8px",
            textDecoration: "none",
            fontWeight: "600",
            transition: "all 0.3s ease",
            boxShadow: "0 4px 15px rgba(255, 117, 24, 0.3)"
          }}
        >
          {language === 'en' ? "Secure Early Access Now" : "Biztosítsd a korai hozzáférést most"}
        </a>
      </div>
    </div>
  );
};

export default CountdownTimer;