import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { motion } from "framer-motion";
import voc2goBackground from "@assets/Screenshot 2025-05-22 at 22.10.51.png";

const VocTaglineSection: React.FC = () => {
  const { language } = useLanguage();

  // Content based on selected language
  const content = {
    en: {
      tagline1: "YOUR WORDS",
      tagline2: "YOUR STYLE",
      tagline3: "YOUR ENGLISH",
      buttonText: "Get VOC2GO Now",
    },
    hu: {
      tagline1: "A TE SZAVAID",
      tagline2: "A TE STÍLUSOD",
      tagline3: "A TE ANGOLOD",
      buttonText: "Szerezd meg a VOC2GO-t most",
    },
  };

  const currentContent = language === "hu" ? content.hu : content.en;

  return (
    <section
      style={{
        padding: "30px 0",
        position: "relative",
        overflow: "hidden",
        backgroundImage: `url(${voc2goBackground})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        marginTop: "0",
        marginBottom: "0",
      }}
    >
      <div
        className="overlay"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          zIndex: 1,
        }}
      ></div>

      <div className="container" style={{ position: "relative", zIndex: 2 }}>
        <div
          className="content-wrapper"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            padding: "20px 0",
          }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h1
              style={{
                color: "white",
                fontSize: "42px",
                fontWeight: "bold",
                marginBottom: "0px",
                textShadow: "0 2px 4px rgba(0,0,0,0.3)",
              }}
            >
              VOC2GO
            </h1>
            <div style={{ marginBottom: "25px" }}>
              <h2
                style={{
                  color: "white",
                  fontSize: "28px",
                  fontWeight: "500",
                  marginBottom: "5px",
                  textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                }}
              >
                {currentContent.tagline1}
              </h2>
              <h2
                style={{
                  color: "white",
                  fontSize: "28px",
                  fontWeight: "500",
                  marginBottom: "5px",
                  textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                }}
              >
                {currentContent.tagline2}
              </h2>
              <h2
                style={{
                  color: "white",
                  fontSize: "28px",
                  fontWeight: "500",
                  marginBottom: "25px",
                  textShadow: "0 2px 4px rgba(0,0,0,0.3)",
                }}
              >
                {currentContent.tagline3}
              </h2>
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              style={{
                backgroundColor: "#F7941D",
                color: "white",
                border: "none",
                padding: "12px 30px",
                borderRadius: "30px",
                fontSize: "18px",
                fontWeight: "bold",
                cursor: "pointer",
                boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
                position: "relative",
                overflow: "hidden",
              }}
              className="hero-button"
            >
              <div
                className="shine"
                style={{
                  position: "absolute",
                  top: "-50%",
                  left: "-50%",
                  width: "200%",
                  height: "200%",
                  backgroundImage:
                    "linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%)",
                  transform: "rotate(30deg)",
                  animation: "shine 3s infinite linear",
                }}
              ></div>
              {currentContent.buttonText}
            </motion.button>
          </motion.div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes shine {
            0% {
              left: -100%;
            }
            20%, 100% {
              left: 100%;
            }
          }
        `
      }} />
    </section>
  );
};

export default VocTaglineSection;