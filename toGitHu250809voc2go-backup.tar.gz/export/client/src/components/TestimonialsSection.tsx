import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Star, Quote } from "lucide-react";

const TestimonialsSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Custom validation for Hungarian language
    const nameInput = e.currentTarget.querySelector('input[name="name"]') as HTMLInputElement;
    const emailInput = e.currentTarget.querySelector('input[name="email"]') as HTMLInputElement;
    
    if (nameInput && !nameInput.validity.valid) {
      if (language === 'hu') {
        nameInput.setCustomValidity('Kérjük, töltsd ki ezt a mezőt');
      } else {
        nameInput.setCustomValidity('');
      }
      nameInput.reportValidity();
      return;
    }
    
    if (emailInput && !emailInput.validity.valid) {
      if (language === 'hu') {
        if (emailInput.validity.valueMissing) {
          emailInput.setCustomValidity('Kérjük, töltsd ki ezt a mezőt');
        } else if (emailInput.validity.typeMismatch) {
          emailInput.setCustomValidity('Kérjük, adj meg egy érvényes email címet');
        } else {
          emailInput.setCustomValidity('Kérjük, adj meg egy érvényes email címet');
        }
      } else {
        emailInput.setCustomValidity('');
      }
      emailInput.reportValidity();
      return;
    }
    
    if (!formData.name.trim() || !formData.email.trim()) return;

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          email: formData.email.trim(),
          source: 'testimonials_early_access',
          language: language,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // New subscription successful
        setIsSubmitted(true);
        setFormData({ name: '', email: '' });
        timeoutRef.current = setTimeout(() => {
          setIsSubmitted(false);
          setShowForm(false);
        }, 3000);
      } else if (response.status === 409) {
        // Email already subscribed - still show success
        setIsSubmitted(true);
        setFormData({ name: '', email: '' });
        timeoutRef.current = setTimeout(() => {
          setIsSubmitted(false);
          setShowForm(false);
        }, 3000);
      } else {
        console.error('Early access subscription error:', data.message || 'Unknown error');
        alert(language === 'en' ? 'Error subscribing. Please try again.' : 'Hiba a feliratkozásban. Kérjük, próbáld újra.');
      }
    } catch (error) {
      console.error('Error submitting early access form:', error);
      alert(language === 'en' ? 'Network error. Please try again.' : 'Hálózati hiba. Kérjük, próbáld újra.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Cleanup effect
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Reset custom validation on input change
    e.target.setCustomValidity('');
  };

  // Testimonials are now managed through admin content system
  // Each testimonial can be edited via admin panel
  const testimonials = [
    {
      name: getContentText('testimonial-1-name', language === 'en' ? "Sarah Johnson" : "Johnson Sarah"),
      role: getContentText('testimonial-1-role', language === 'en' ? "English Teacher" : "Angoltanár"),
      text: getContentText('testimonial-1-text', language === 'en' 
        ? "VOC2GO has transformed how I teach vocabulary. My students are more engaged and remember words better through the story-based approach."
        : "A VOC2GO átalakította, hogyan tanítok szókincset. A diákjaim jobban bevonódnak és jobban megjegyzik a szavakat a történetalapú megközelítés révén."),
      rating: 5,
      improvement: getContentText('testimonial-1-improvement', language === 'en' ? "40% better retention" : "40%-kal jobb megjegyzés")
    },
    {
      name: getContentText('testimonial-2-name', language === 'en' ? "Michael Chen" : "Chen Michael"),
      role: getContentText('testimonial-2-role', language === 'en' ? "Business Professional" : "Üzleti szakember"),
      text: getContentText('testimonial-2-text', language === 'en' 
        ? "The AI-powered conversations feel natural and help me practice real workplace scenarios. It's like having a personal English tutor."
        : "Az AI-alapú beszélgetések természetesek és segítenek gyakorolni valós munkahelyi helyzeteket. Mintha személyes angoltanárom lenne."),
      rating: 5,
      improvement: getContentText('testimonial-2-improvement', language === 'en' ? "Confident in meetings" : "Magabiztos megbeszéléseken")
    },
    {
      name: getContentText('testimonial-3-name', language === 'en' ? "Anna Kovács" : "Kovács Anna"),
      role: getContentText('testimonial-3-role', language === 'en' ? "University Student" : "Egyetemista"),
      text: getContentText('testimonial-3-text', language === 'en' 
        ? "Finally, an app that understands my learning style. The personalized stories make vocabulary stick in my mind effortlessly."
        : "Végre egy alkalmazás, amely megérti a tanulási stílusomat. A személyre szabott történetek könnyedén megragadják a szókincsmet."),
      rating: 5,
      improvement: getContentText('testimonial-3-improvement', language === 'en' ? "2x faster learning" : "2x gyorsabb tanulás")
    }
  ];

  const stats = [
    { 
      number: getContentText('testimonials-stat1-number', "94%"), 
      label: getContentText('testimonials-stat1-label', language === 'en' ? "User Satisfaction" : "Felhasználói Elégedettség") 
    },
    { 
      number: getContentText('testimonials-stat2-number', "3x"), 
      label: getContentText('testimonials-stat2-label', language === 'en' ? "Faster Learning" : "Gyorsabb Tanulás") 
    },
    { 
      number: getContentText('testimonials-stat3-number', "85%"), 
      label: getContentText('testimonials-stat3-label', language === 'en' ? "Retention Rate" : "Megjegyzési Arány") 
    },
    { 
      number: getContentText('testimonials-stat4-number', "500+"), 
      label: getContentText('testimonials-stat4-label', language === 'en' ? "Beta Testers" : "Béta Tesztelő") 
    }
  ];

  return (
    <section id="testimonials" style={{
      padding: "80px 0",
      background: "linear-gradient(135deg, rgba(45, 0, 81, 0.95) 0%, rgba(92, 55, 199, 0.95) 100%)",
      color: "white",
      position: "relative",
      overflow: "hidden"
    }}>
      <div className="container" style={{ maxWidth: "1200px", margin: "0 auto", padding: "0 20px", position: "relative", zIndex: 2 }}>
        <div className="section-header" style={{ textAlign: "center", marginBottom: "60px" }}>
          <h2 style={{ 
            fontSize: "2.5rem", 
            marginBottom: "20px",
            background: "linear-gradient(90deg, #44d1c6, #ffffff)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            fontWeight: "bold"
          }}>
            {getContentText('testimonials-heading', language === 'en' ? "What Early Users Say" : "Mit mondanak a korai felhasználók")}
          </h2>
          
          <p style={{ 
            fontSize: "1.2rem", 
            maxWidth: "800px", 
            margin: "0 auto",
            color: "rgba(255, 255, 255, 0.9)",
            lineHeight: "1.6"
          }}>
            {getContentText('testimonials-description', language === 'en' 
              ? "Real feedback from beta testers, language researchers, and early adopters who've experienced the VOC2GO difference."
              : "Valódi visszajelzések béta tesztelőktől, nyelvkutatóktól és korai felhasználóktól, akik megtapasztalták a VOC2GO különbségét."
            )}
          </p>
        </div>

        {/* Stats Grid */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
          gap: "30px",
          marginBottom: "60px",
          padding: "40px",
          background: "rgba(255, 255, 255, 0.1)",
          borderRadius: "16px",
          backdropFilter: "blur(10px)",
          border: "1px solid rgba(255, 255, 255, 0.2)"
        }}>
          {stats.map((stat, index) => (
            <div key={index} style={{ textAlign: "center" }}>
              <div style={{ 
                fontSize: "2.5rem", 
                fontWeight: "bold", 
                color: "#44d1c6",
                marginBottom: "5px"
              }}>
                {stat.number}
              </div>
              <div style={{ 
                fontSize: "0.9rem", 
                color: "rgba(255, 255, 255, 0.8)",
                fontWeight: "500"
              }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
        
        {/* Testimonials Grid */}
        <div style={{ 
          display: "grid", 
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", 
          gap: "30px"
        }}>
          {testimonials.map((testimonial, index) => (
            <div key={index} style={{ 
              background: "rgba(255, 255, 255, 0.1)",
              borderRadius: "16px",
              padding: "30px",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.2)",
              position: "relative",
              transition: "transform 0.3s ease"
            }}>
              <Quote size={40} style={{ 
                color: "#44d1c6", 
                marginBottom: "20px",
                opacity: 0.7
              }} />
              
              <div style={{ 
                display: "flex", 
                marginBottom: "15px" 
              }}>
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} size={16} style={{ color: "#FFD700", fill: "#FFD700" }} />
                ))}
              </div>
              
              <p style={{ 
                fontSize: "1rem", 
                lineHeight: "1.6",
                marginBottom: "20px",
                color: "rgba(255, 255, 255, 0.9)",
                fontStyle: "italic"
              }}>
                "{testimonial.text}"
              </p>
              
              <p style={{ 
                fontSize: "0.9rem", 
                color: "#44d1c6",
                fontWeight: "600",
                margin: "0 0 20px 0"
              }}>
                🎯 {testimonial.improvement}
              </p>
              
              <div>
                <h4 style={{ 
                  fontSize: "1.1rem", 
                  fontWeight: "bold", 
                  marginBottom: "5px",
                  color: "white"
                }}>
                  {testimonial.name}
                </h4>
                <p style={{ 
                  fontSize: "0.9rem", 
                  color: "rgba(255, 255, 255, 0.7)",
                  margin: "0"
                }}>
                  {testimonial.role}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        <div style={{ 
          textAlign: "center", 
          marginTop: "60px"
        }}>
          <h3 style={{ 
            fontSize: "1.8rem", 
            marginBottom: "15px",
            color: "#44d1c6"
          }}>
            {getContentText('testimonials-cta-title', language === 'en' 
              ? "Join 500+ Early Supporters" 
              : "Csatlakozz a 500+ korai támogatóhoz"
            )}
          </h3>
          
          <p style={{ 
            fontSize: "1.1rem", 
            marginBottom: "25px",
            color: "rgba(255, 255, 255, 0.9)"
          }}>
            {getContentText('testimonials-cta-description', language === 'en' 
              ? "Be part of the language learning revolution. Limited early access spots remaining."
              : "Légy része a nyelvtanulási forradalomnak. Korlátozott korai hozzáférési helyek állnak rendelkezésre."
            )}
          </p>
          
          {!showForm ? (
            <button
              onClick={() => setShowForm(true)}
              className="testimonials-cta-button"
              style={{
                display: "inline-block",
                padding: "16px 36px",
                background: "#FF7518",
                color: "white",
                borderRadius: "8px",
                border: "none",
                fontWeight: "600",
                fontSize: "1.1rem",
                cursor: "pointer",
                transition: "all 0.3s ease",
                boxShadow: "0 4px 15px rgba(255, 117, 24, 0.3)",
                width: "100%",
                maxWidth: "400px",
                textAlign: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis"
              }}
            >
              {getContentText('testimonials-cta-button', language === 'en' ? "Secure Your Spot Now" : "Biztosítsd helyed most")}
            </button>
          ) : (
            <div className="testimonials-form-container" style={{
              background: "rgba(255, 255, 255, 0.1)",
              padding: "20px",
              borderRadius: "12px",
              border: "1px solid rgba(255, 255, 255, 0.2)",
              maxWidth: "500px",
              margin: "0 auto",
              width: "100%"
            }}>
              <h3 className="testimonials-form-title" style={{ 
                color: "white", 
                marginBottom: "20px",
                textAlign: "center",
                fontSize: "1.5rem"
              }}>
                {language === 'en' ? 'Get Early Access' : 'Szerezz korai hozzáférést'}
              </h3>
              
              <p className="testimonials-form-description" style={{ 
                color: "rgba(255, 255, 255, 0.8)", 
                marginBottom: "25px",
                textAlign: "center",
                fontSize: "1rem"
              }}>
                {language === 'en' 
                  ? 'We will inform you about our Indiegogo campaign launch'
                  : 'Értesítünk az Indiegogo kampányunk indulásáról'
                }
              </p>
              
              {isSubmitted ? (
                <div className="testimonials-success-message" style={{
                  background: "rgba(68, 209, 198, 0.2)",
                  padding: "20px",
                  borderRadius: "8px",
                  textAlign: "center",
                  color: "#44d1c6",
                  fontWeight: "600"
                }}>
                  {language === 'en' ? "Thank you! We'll be in touch soon." : "Köszönjük! Hamarosan jelentkezünk."}
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="testimonials-form">
                  <div className="testimonials-form-field" style={{ marginBottom: "20px" }}>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder={language === 'en' ? "Your Name" : "Neved"}
                      required
                      className="testimonials-form-input"
                      style={{
                        width: "100%",
                        padding: "12px 16px",
                        borderRadius: "8px",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                        background: "rgba(255, 255, 255, 0.9)",
                        fontSize: "16px",
                        outline: "none",
                        boxSizing: "border-box"
                      }}
                    />
                  </div>
                  
                  <div className="testimonials-form-field" style={{ marginBottom: "25px" }}>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder={language === 'en' ? "Your Email" : "Email címed"}
                      required
                      className="testimonials-form-input"
                      style={{
                        width: "100%",
                        padding: "12px 16px",
                        borderRadius: "8px",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                        background: "rgba(255, 255, 255, 0.9)",
                        fontSize: "16px",
                        outline: "none",
                        boxSizing: "border-box"
                      }}
                    />
                  </div>
                  
                  <div className="testimonials-form-buttons" style={{ 
                    display: "flex", 
                    gap: "10px",
                    flexDirection: "row",
                    flexWrap: "wrap"
                  }}>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="testimonials-form-submit"
                      style={{
                        flex: 1,
                        minWidth: "120px",
                        padding: "12px 16px",
                        background: "#FF7518",
                        color: "white",
                        border: "none",
                        borderRadius: "8px",
                        fontSize: "16px",
                        fontWeight: "600",
                        cursor: isSubmitting ? "not-allowed" : "pointer",
                        opacity: isSubmitting ? 0.7 : 1,
                        transition: "all 0.3s ease"
                      }}
                    >
                      {isSubmitting 
                        ? (language === 'en' ? "Submitting..." : "Küldés...") 
                        : (language === 'en' ? "Notify Me" : "Értesíts")}
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setShowForm(false)}
                      className="testimonials-form-cancel"
                      style={{
                        padding: "12px 16px",
                        minWidth: "100px",
                        background: "rgba(255, 255, 255, 0.2)",
                        color: "white",
                        border: "1px solid rgba(255, 255, 255, 0.3)",
                        borderRadius: "8px",
                        fontSize: "16px",
                        cursor: "pointer",
                        transition: "all 0.3s ease"
                      }}
                    >
                      {language === 'en' ? "Cancel" : "Mégse"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Background decorations */}
      <div style={{
        position: "absolute",
        width: "400px",
        height: "400px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(68, 209, 198, 0.2) 0%, rgba(68, 209, 198, 0) 70%)",
        top: "-150px",
        right: "-150px",
        zIndex: 1
      }}></div>
      
      <div style={{
        position: "absolute",
        width: "500px",
        height: "500px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(255, 117, 24, 0.1) 0%, rgba(255, 117, 24, 0) 70%)",
        bottom: "-200px",
        left: "-200px",
        zIndex: 1
      }}></div>
    </section>
  );
};

export default TestimonialsSection;