import React, { useState, useEffect } from 'react';
import { X, Save, Eye, Edit3, Key, User, Settings, RefreshCw, Monitor, Smartphone } from 'lucide-react';
import AdminContentManager from './AdminContentManager';

interface AdminPanelProps {
  onClose: () => void;
}

interface AdminUser {
  id: number;
  loginName: string;
  lastLogin: Date;
}

interface ContentSection {
  id: number;
  sectionId: string;
  title: string;
  content: string;
  language: string;
  modifiedBy: string;
  lastModified: Date;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'content' | 'settings' | 'preview'>('content');
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [contentSections, setContentSections] = useState<ContentSection[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [editData, setEditData] = useState<{ title: string; content: string }>({ title: '', content: '' });
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hu'>('en');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [credentialsForm, setCredentialsForm] = useState({
    currentPassword: '',
    newLoginName: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    fetchAdminData();
    fetchContentSections();
  }, [currentLanguage]);

  const fetchAdminData = async () => {
    try {
      const response = await fetch('/api/admin/me', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setAdmin(data.admin);
      }
    } catch (error) {
      console.error('Failed to fetch admin data:', error);
    }
  };

  const fetchContentSections = async () => {
    try {
      const response = await fetch(`/api/admin/content?language=${currentLanguage}`, {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setContentSections(data.sections);
      }
    } catch (error) {
      console.error('Failed to fetch content sections:', error);
    }
  };

  const handleSaveContent = async (sectionId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/content/${sectionId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          title: editData.title,
          content: editData.content,
          language: currentLanguage
        })
      });

      if (response.ok) {
        await fetchContentSections();
        setEditingSection(null);
        setEditData({ title: '', content: '' });
      } else {
        setError('Failed to save content');
      }
    } catch (error) {
      setError('Network error while saving content');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateCredentials = async () => {
    if (credentialsForm.newPassword !== credentialsForm.confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/admin/update-credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          currentPassword: credentialsForm.currentPassword,
          newLoginName: credentialsForm.newLoginName || undefined,
          newPassword: credentialsForm.newPassword || undefined
        })
      });

      if (response.ok) {
        await fetchAdminData();
        setCredentialsForm({ currentPassword: '', newLoginName: '', newPassword: '', confirmPassword: '' });
        setError(null);
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to update credentials');
      }
    } catch (error) {
      setError('Network error while updating credentials');
    } finally {
      setLoading(false);
    }
  };

  const startEditing = (section: ContentSection) => {
    setEditingSection(section.sectionId);
    setEditData({ title: section.title, content: section.content });
  };

  const cancelEditing = () => {
    setEditingSection(null);
    setEditData({ title: '', content: '' });
  };

  const tabButtonStyle = (isActive: boolean) => ({
    padding: '12px 24px',
    border: 'none',
    borderRadius: '8px 8px 0 0',
    backgroundColor: isActive ? '#5C37C7' : '#f8f9fa',
    color: isActive ? 'white' : '#6c757d',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    fontWeight: '600',
    fontSize: '14px'
  });

  return (
    <div 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        backdropFilter: 'blur(4px)'
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        style={{
          background: 'white',
          borderRadius: '16px',
          width: '95%',
          maxWidth: '1200px',
          height: '90vh',
          maxHeight: '800px',
          position: 'relative',
          boxShadow: '0 25px 50px rgba(0, 0, 0, 0.25)',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Header */}
        <div style={{ 
          padding: '24px 32px', 
          borderBottom: '1px solid #e9ecef',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h2 style={{ margin: 0, color: '#2D0051', fontSize: '24px', fontWeight: '700' }}>
              Admin Panel
            </h2>
            {admin && (
              <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                Welcome, {admin.loginName}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '8px',
              borderRadius: '50%',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <X size={24} color="#666" />
          </button>
        </div>

        {/* Tabs */}
        <div style={{ 
          display: 'flex', 
          borderBottom: '1px solid #e9ecef',
          paddingLeft: '32px'
        }}>
          <button
            onClick={() => setActiveTab('content')}
            style={tabButtonStyle(activeTab === 'content')}
          >
            <Edit3 size={16} style={{ marginRight: '8px' }} />
            Content Management
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            style={tabButtonStyle(activeTab === 'settings')}
          >
            <Settings size={16} style={{ marginRight: '8px' }} />
            Settings
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            style={tabButtonStyle(activeTab === 'preview')}
          >
            <Eye size={16} style={{ marginRight: '8px' }} />
            Live Preview
          </button>
        </div>

        {/* Content Area */}
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {error && (
            <div style={{
              margin: '16px 32px',
              padding: '12px 16px',
              backgroundColor: '#FEF2F2',
              border: '1px solid #FCA5A5',
              borderRadius: '8px',
              color: '#B91C1C',
              fontSize: '14px'
            }}>
              {error}
            </div>
          )}

          {activeTab === 'content' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0, color: '#2D0051' }}>Website Content Management</h3>
                  <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                    Edit content sections organized by menu structure
                  </p>
                </div>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                  <select
                    value={currentLanguage}
                    onChange={(e) => setCurrentLanguage(e.target.value as 'en' | 'hu')}
                    style={{
                      padding: '8px 12px',
                      border: '1px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                  >
                    <option value="en">English</option>
                    <option value="hu">Hungarian</option>
                  </select>
                </div>
              </div>
              
              <AdminContentManager currentLanguage={currentLanguage} />
            </div>
          )}

          {activeTab === 'settings' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ margin: 0, color: '#2D0051' }}>Admin Settings</h3>
                <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                  Update admin credentials and system settings
                </p>
              </div>
              
              <div style={{
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                padding: '24px',
                marginBottom: '24px'
              }}>
                <h4 style={{ margin: '0 0 16px 0', color: '#2D0051' }}>Change Admin Credentials</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      Current Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.currentPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, currentPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      New Login Name
                    </label>
                    <input
                      type="text"
                      value={credentialsForm.newLoginName}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, newLoginName: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      New Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.newPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, newPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.confirmPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <button
                    onClick={handleUpdateCredentials}
                    disabled={loading}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#5C37C7',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    {loading ? 'Updating...' : 'Update Credentials'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'preview' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0, color: '#2D0051' }}>Live Preview</h3>
                  <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                    Preview your changes in real-time
                  </p>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => setPreviewMode('desktop')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'desktop' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'desktop' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Monitor size={16} />
                    Desktop
                  </button>
                  <button
                    onClick={() => setPreviewMode('mobile')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'mobile' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'mobile' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Smartphone size={16} />
                    Mobile
                  </button>
                </div>
              </div>
              
              <div style={{
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                height: '500px',
                overflow: 'hidden'
              }}>
                <iframe
                  src={window.location.origin}
                  style={{
                    width: previewMode === 'mobile' ? '375px' : '100%',
                    height: '100%',
                    border: 'none',
                    margin: previewMode === 'mobile' ? '0 auto' : '0',
                    display: 'block'
                  }}
                  title="Live Preview"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const handleUpdateCredentials = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/admin/update-credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          currentPassword: credentialsForm.currentPassword,
          newLoginName: credentialsForm.newLoginName,
          newPassword: credentialsForm.newPassword,
          confirmPassword: credentialsForm.confirmPassword
        })
      });
      
      if (response.ok) {
        setCredentialsForm({
          currentPassword: '',
          newLoginName: '',
          newPassword: '',
          confirmPassword: ''
        });
        // Refresh admin data
        await fetchAdminData();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to update credentials');
      }
    } catch (err) {
      setError('Error updating credentials');
    } finally {
      setLoading(false);
    }
  };
};
                <div key={section.id} style={{
                  border: '1px solid #e9ecef',
                  borderRadius: '8px',
                  marginBottom: '16px',
                  padding: '20px'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                    <h4 style={{ margin: 0, color: '#2D0051', fontSize: '18px' }}>
                      {section.sectionId}
                    </h4>
                    <button
                      onClick={() => startEditing(section)}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#44d1c6',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '12px'
                      }}
                    >
                      <Edit3 size={14} style={{ marginRight: '4px' }} />
                      Edit
                    </button>
                  </div>

                  {editingSection === section.sectionId ? (
                    <div>
                      <input
                        type="text"
                        value={editData.title}
                        onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                        placeholder="Section Title"
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          marginBottom: '12px',
                          fontSize: '14px'
                        }}
                      />
                      <textarea
                        value={editData.content}
                        onChange={(e) => setEditData({ ...editData, content: e.target.value })}
                        placeholder="Section Content"
                        rows={6}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          marginBottom: '12px',
                          fontSize: '14px',
                          resize: 'vertical'
                        }}
                      />
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          onClick={() => handleSaveContent(section.sectionId)}
                          disabled={loading}
                          style={{
                            padding: '8px 16px',
                            backgroundColor: '#28a745',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: loading ? 'not-allowed' : 'pointer'
                          }}
                        >
                          <Save size={14} style={{ marginRight: '4px' }} />
                          Save
                        </button>
                        <button
                          onClick={cancelEditing}
                          style={{
                            padding: '8px 16px',
                            backgroundColor: '#6c757d',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p style={{ margin: '0 0 8px', fontWeight: '600' }}>{section.title}</p>
                      <p style={{ margin: '0 0 12px', color: '#6c757d' }}>{section.content}</p>
                      <small style={{ color: '#9ca3af' }}>
                        Last modified by {section.modifiedBy} on {new Date(section.lastModified).toLocaleDateString()}
                      </small>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'settings' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <h3 style={{ margin: '0 0 24px', color: '#2D0051' }}>Admin Settings</h3>
              
              <div style={{ 
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                padding: '24px',
                marginBottom: '24px'
              }}>
                <h4 style={{ margin: '0 0 16px', color: '#2D0051', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Key size={18} />
                  Update Credentials
                </h4>
                
                <div style={{ display: 'grid', gap: '16px', maxWidth: '400px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '14px' }}>
                      Current Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.currentPassword}
                      onChange={(e) => setCredentialsForm({ ...credentialsForm, currentPassword: e.target.value })}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '14px' }}>
                      New Login Name (optional)
                    </label>
                    <input
                      type="text"
                      value={credentialsForm.newLoginName}
                      onChange={(e) => setCredentialsForm({ ...credentialsForm, newLoginName: e.target.value })}
                      placeholder={admin?.loginName}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '14px' }}>
                      New Password (optional)
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.newPassword}
                      onChange={(e) => setCredentialsForm({ ...credentialsForm, newPassword: e.target.value })}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '14px' }}>
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.confirmPassword}
                      onChange={(e) => setCredentialsForm({ ...credentialsForm, confirmPassword: e.target.value })}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  
                  <button
                    onClick={handleUpdateCredentials}
                    disabled={loading || !credentialsForm.currentPassword}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#5C37C7',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: loading || !credentialsForm.currentPassword ? 'not-allowed' : 'pointer',
                      fontWeight: '600'
                    }}
                  >
                    Update Credentials
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'preview' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 style={{ margin: 0, color: '#2D0051' }}>Live Preview</h3>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => setPreviewMode('desktop')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'desktop' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'desktop' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Monitor size={16} />
                    Desktop
                  </button>
                  <button
                    onClick={() => setPreviewMode('mobile')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'mobile' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'mobile' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Smartphone size={16} />
                    Mobile
                  </button>
                </div>
              </div>
              
              <div style={{
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                height: '500px',
                overflow: 'hidden'
              }}>
                <iframe
                  src={window.location.origin}
                  style={{
                    width: previewMode === 'mobile' ? '375px' : '100%',
                    height: '100%',
                    border: 'none',
                    margin: previewMode === 'mobile' ? '0 auto' : '0',
                    display: 'block'
                  }}
                  title="Live Preview"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;