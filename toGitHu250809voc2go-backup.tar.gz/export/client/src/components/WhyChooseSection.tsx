import React, { useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { ArrowRight, Mail, CheckCircle } from "lucide-react";

const WhyChooseSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email, 
          source: "mission_support",
          language: language 
        }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setIsSubmitted(true);
        setEmail("");
      } else if (response.status === 409) {
        // Email already subscribed - still show success
        setIsSubmitted(true);
        setEmail("");
      } else {
        console.error('Mission support subscription error:', data.message || 'Unknown error');
        alert(language === 'en' ? 'Error subscribing. Please try again.' : 'Hiba a feliratkozásban. Kérjük, próbáld újra.');
      }
    } catch (error) {
      console.error('Mission support email submission failed:', error);
      alert(language === 'en' ? 'Network error. Please try again.' : 'Hálózati hiba. Kérjük, próbáld újra.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <section id="why-choose" className="why-choose-section" style={{
      padding: "80px 0",
      background: "linear-gradient(135deg, rgba(45, 0, 81, 0.97) 0%, rgba(92, 55, 199, 0.97) 100%)",
      color: "white",
      position: "relative",
      overflow: "hidden"
    }}>
      <div className="container" style={{ maxWidth: "1200px", margin: "0 auto", padding: "0 20px" }}>
        <div className="section-content" style={{ 
          position: "relative", 
          zIndex: 2,
          padding: "40px"
        }}>
          <h2 style={{ 
            fontSize: "2.5rem", 
            marginBottom: "30px", 
            textAlign: "center",
            color: "#44d1c6",
            fontWeight: "bold"
          }}>
            {getContentText('why-choose-title', language === 'en' ? "Why Choose Voc2Go?" : "Miért pont a Voc2Go?")}
          </h2>
          
          <div style={{ marginBottom: "30px", fontSize: "1.1rem", lineHeight: "1.6" }}>
            <p>
              {getContentText('why-choose-description', language === 'en' ? 'Voc2Go is built on real stories, engaging AI conversations, and a science-based approach to learning. Other apps don\'t answer all five key questions:' : 'Mert végre nem unalmas, nem kötelező, és nem elavult. Ez egy olyan nyelvtanulás, amit:')}
            </p>
            
            <ul style={{ 
              marginTop: "20px", 
              paddingLeft: "20px",
              listStyleType: "none"
            }}>
              <li style={{ marginBottom: "10px", display: "flex", alignItems: "center" }}>
                <span style={{ color: "#44d1c6", marginRight: "10px" }}>•</span> {getContentText('key-question-1', language === 'en' ? 'Is it easy to use?' : 'Könnyű használni')}
              </li>
              <li style={{ marginBottom: "10px", display: "flex", alignItems: "center" }}>
                <span style={{ color: "#44d1c6", marginRight: "10px" }}>•</span> {getContentText('key-question-2', language === 'en' ? 'Do I remember what I learn?' : 'Valóban megjegyzed a szavakat')}
              </li>
              <li style={{ marginBottom: "10px", display: "flex", alignItems: "center" }}>
                <span style={{ color: "#44d1c6", marginRight: "10px" }}>•</span> {getContentText('key-question-3', language === 'en' ? 'Are all my senses involved – hearing, seeing, speaking?' : 'A hallásodra, látásodra és beszédedre is hat')}
              </li>
              <li style={{ marginBottom: "10px", display: "flex", alignItems: "center" }}>
                <span style={{ color: "#44d1c6", marginRight: "10px" }}>•</span> {getContentText('key-question-4', language === 'en' ? 'Is this relevant to me?' : 'Rólad szól, nem az applikációról')}
              </li>
              <li style={{ marginBottom: "10px", display: "flex", alignItems: "center" }}>
                <span style={{ color: "#44d1c6", marginRight: "10px" }}>•</span> {getContentText('key-question-5', language === 'en' ? 'Will this make me curious to explore English on my own?' : 'Kíváncsivá fog tenni és motivál, hogy folytasd')}
              </li>
            </ul>
            
            {language === 'en' ? (
              <p style={{ marginTop: "20px" }}>
                {getContentText('voc2go-answers', 'Voc2Go answers these with interactive AI-powered conversations and personalized language journeys.')}
              </p>
            ) : null}
          </div>
          
          <div style={{ marginBottom: "30px" }}>
            <h3 style={{ 
              fontSize: "1.8rem", 
              marginBottom: "20px",
              color: "#44d1c6",
              fontWeight: "600" 
            }}>
              {getContentText('who-is-voc2go-for-title', language === 'en' ? "Who Is Voc2Go For?" : "Kinek szól?")}
            </h3>
            
            <p style={{ fontSize: "1.1rem", lineHeight: "1.6" }}>
              {getContentText('who-is-voc2go-for-description', language === 'en' 
                ? "Voc2Go is perfect for anyone who needs real-world English that they can use right away. Whether you're working, traveling, studying, or just want to connect, Voc2Go is designed for you. Ideal for adult learners, professionals, students, and travelers."
                : "Mindenkinek, aki életszerű angolt szeretne. Ha dolgozol, utazol, egyetemre jársz, vagy egyszerűen csak szeretnél megszólalni angolul – itt a helyed. Különösen hasznos fiatal felnőtteknek, pályakezdőknek, diákoknak, digitális nomádoknak, nyelvrajongók minden korosztályának."
              )}
            </p>
          </div>
          
          <div style={{ marginBottom: "40px" }}>
            <h3 style={{ 
              fontSize: "1.8rem", 
              marginBottom: "20px",
              color: "#44d1c6",
              fontWeight: "600" 
            }}>
              {getContentText('our-promise-title', language === 'en' ? "Our Promise" : "Mit ígérünk?")}
            </h3>
            
            <p style={{ 
              fontSize: "1.1rem", 
              lineHeight: "1.6",
              fontWeight: "500",
              fontStyle: "italic",
              textAlign: "center"
            }}>
              {getContentText('our-promise-description', language === 'en' 
                ? "With Voc2Go, you don't just learn English. You feel it, you speak it, and you own it."
                : "Nem csak tanulni fogsz angolul. Megérted. Használod. A tiéd lesz."
              )}
            </p>
          </div>
          
          <div style={{ textAlign: "center" }}>
            {isSubmitted ? (
              <div style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '15px',
                padding: '20px',
                background: 'rgba(68, 209, 198, 0.1)',
                borderRadius: '12px',
                border: '1px solid rgba(68, 209, 198, 0.3)',
                maxWidth: '400px',
                margin: '0 auto'
              }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  borderRadius: '50%',
                  background: '#44d1c6',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'white'
                }}>
                  <CheckCircle size={30} />
                </div>
                <p style={{ 
                  fontSize: '18px',
                  fontWeight: '500',
                  color: 'white',
                  margin: 0
                }}>
                  {language === "en" 
                    ? "Thank you for supporting our mission!" 
                    : "Köszönjük, hogy támogatod küldetésünket!"
                  }
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '10px',
                flexWrap: 'wrap',
                maxWidth: '500px',
                margin: '0 auto'
              }}>
                <div style={{ position: 'relative', flex: '1', minWidth: '280px' }}>
                  <div style={{ 
                    position: 'absolute', 
                    left: '15px', 
                    top: '50%', 
                    transform: 'translateY(-50%)',
                    color: '#44d1c6'
                  }}>
                    <Mail size={18} />
                  </div>
                  <input 
                    type="email" 
                    placeholder={language === "en" ? "Enter your email to support us" : "Email címed a támogatáshoz"}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    style={{
                      width: '100%',
                      padding: '14px 14px 14px 50px',
                      borderRadius: '8px',
                      border: '1px solid rgba(255, 255, 255, 0.3)',
                      background: 'rgba(255, 255, 255, 0.1)',
                      color: 'white',
                      fontSize: '16px',
                      outline: 'none',
                      transition: 'all 0.3s ease'
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = '#44d1c6';
                      e.target.style.background = 'rgba(255, 255, 255, 0.15)';
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      e.target.style.background = 'rgba(255, 255, 255, 0.1)';
                    }}
                  />
                </div>
                <button 
                  type="submit"
                  disabled={isLoading}
                  style={{
                    padding: '14px 30px',
                    backgroundColor: '#FF7518',
                    color: 'white',
                    border: 'none',
                    borderRadius: '8px',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: isLoading ? 'not-allowed' : 'pointer',
                    transition: 'all 0.3s ease',
                    boxShadow: '0 4px 15px rgba(255, 117, 24, 0.3)',
                    opacity: isLoading ? 0.7 : 1,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px'
                  }}
                  onMouseEnter={(e) => {
                    if (!isLoading) {
                      e.currentTarget.style.transform = 'translateY(-2px)';
                      e.currentTarget.style.boxShadow = '0 8px 25px rgba(255, 117, 24, 0.4)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isLoading) {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 4px 15px rgba(255, 117, 24, 0.3)';
                    }
                  }}
                >
                  {isLoading 
                    ? (language === "en" ? "Submitting..." : "Küldés...")
                    : getContentText('support-mission-button', language === 'en' ? "Support Our Mission" : "Támogasd a Küldetésünket")
                  }
                  {!isLoading && <ArrowRight size={18} />}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
      
      {/* Background decorations */}
      <div style={{
        position: "absolute",
        width: "300px",
        height: "300px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(68, 209, 198, 0.3) 0%, rgba(68, 209, 198, 0) 70%)",
        top: "-100px",
        right: "-100px",
        zIndex: 1
      }}></div>
      
      <div style={{
        position: "absolute",
        width: "400px",
        height: "400px",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(92, 55, 199, 0.2) 0%, rgba(92, 55, 199, 0) 70%)",
        bottom: "-150px",
        left: "-150px",
        zIndex: 1
      }}></div>
    </section>
  );
};

export default WhyChooseSection;