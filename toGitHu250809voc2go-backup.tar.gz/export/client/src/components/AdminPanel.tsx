import React, { useState, useEffect } from 'react';
import { X, Key, Eye, Monitor, Smartphone, Users, MessageSquare, Mail, Star, Calendar, Tag, Globe, Map } from 'lucide-react';
import AdminContentManager from './AdminContentManager';
import AdminSiteMap from './AdminSiteMap';

interface AdminPanelProps {
  onClose: () => void;
}

interface AdminUser {
  id: number;
  loginName: string;
  lastLogin: Date;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'sitemap' | 'content' | 'settings' | 'preview' | 'subscribers' | 'feedback'>('sitemap');
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState<'en' | 'hu'>('en');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [subscribers, setSubscribers] = useState<any[]>([]);
  const [feedbacks, setFeedbacks] = useState<any[]>([]);
  const [credentialsForm, setCredentialsForm] = useState({
    currentPassword: '',
    newLoginName: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    fetchAdminData();
  }, []);

  useEffect(() => {
    if (activeTab === 'subscribers') {
      fetchSubscribers();
    } else if (activeTab === 'feedback') {
      fetchFeedbacks();
    }
  }, [activeTab]);

  const fetchAdminData = async () => {
    try {
      const response = await fetch('/api/admin/me', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setAdmin(data.admin);
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        setError(errorData.error || 'Failed to fetch admin data');
        console.error('Admin data fetch failed:', response.status, errorData);
      }
    } catch (error) {
      setError('Network error while fetching admin data');
      console.error('Failed to fetch admin data:', error);
    }
  };

  const fetchSubscribers = async () => {
    try {
      const response = await fetch('/api/admin/subscribers', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setSubscribers(data.subscribers || []);
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        setError(errorData.error || 'Failed to fetch subscribers');
        console.error('Subscribers fetch failed:', response.status, errorData);
      }
    } catch (error) {
      setError('Network error while fetching subscribers');
      console.error('Failed to fetch subscribers:', error);
    }
  };

  const fetchFeedbacks = async () => {
    try {
      const response = await fetch('/api/admin/feedbacks', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setFeedbacks(data.feedbacks || []);
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        setError(errorData.error || 'Failed to fetch feedbacks');
        console.error('Feedbacks fetch failed:', response.status, errorData);
      }
    } catch (error) {
      setError('Network error while fetching feedbacks');
      console.error('Failed to fetch feedbacks:', error);
    }
  };

  const getSourceColor = (source: string): string => {
    switch (source) {
      case 'campaign': return '#e74c3c';
      case 'support': return '#3498db';
      case 'newsletter': return '#2ecc71';
      case 'newsletter_project': return '#1b5e20';
      case 'newsletter_home': return '#388e3c';
      case 'feedback': return '#f39c12';
      default: return '#6c757d';
    }
  };

  const formatSource = (source: string): string => {
    switch (source) {
      case 'campaign': return 'Campaign';
      case 'support': return 'Support';
      case 'newsletter': return 'Newsletter';
      case 'newsletter_project': return 'Project Page';
      case 'newsletter_home': return 'Home Page';
      case 'feedback': return 'Feedback';
      default: return source.charAt(0).toUpperCase() + source.slice(1).replace('_', ' ');
    }
  };

  const handleUpdateCredentials = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/admin/update-credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          currentPassword: credentialsForm.currentPassword,
          newLoginName: credentialsForm.newLoginName,
          newPassword: credentialsForm.newPassword,
          confirmPassword: credentialsForm.confirmPassword
        })
      });
      
      if (response.ok) {
        setCredentialsForm({
          currentPassword: '',
          newLoginName: '',
          newPassword: '',
          confirmPassword: ''
        });
        // Refresh admin data
        await fetchAdminData();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to update credentials');
      }
    } catch (err) {
      setError('Error updating credentials');
    } finally {
      setLoading(false);
    }
  };

  const tabButtonStyle = (isActive: boolean) => ({
    padding: '12px 24px',
    backgroundColor: isActive ? '#5C37C7' : 'transparent',
    color: isActive ? 'white' : '#6c757d',
    border: 'none',
    borderBottom: isActive ? '3px solid #5C37C7' : '3px solid transparent',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
    transition: 'all 0.3s ease',
    display: 'flex',
    alignItems: 'center'
  });

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 10000
    }}>
      <div style={{
        width: window.innerWidth <= 768 ? '95vw' : '90vw',
        height: window.innerWidth <= 768 ? '95vh' : '90vh',
        maxWidth: '1200px',
        backgroundColor: 'white',
        borderRadius: '12px',
        boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden'
      }}>
        {/* Header */}
        <div style={{
          padding: window.innerWidth <= 768 ? '16px 20px' : '24px 32px',
          borderBottom: '1px solid #e9ecef',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h2 style={{ margin: 0, color: '#2D0051', fontSize: window.innerWidth <= 768 ? '20px' : '24px', fontWeight: '700' }}>
              Admin Panel
            </h2>
            {admin && (
              <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                Welcome, {admin.loginName}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '8px',
              borderRadius: '50%',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <X size={24} color="#666" />
          </button>
        </div>

        {/* Tabs */}
        <div style={{ 
          display: 'flex', 
          borderBottom: '1px solid #e9ecef',
          paddingLeft: window.innerWidth <= 768 ? '16px' : '32px',
          overflowX: 'auto'
        }}>
          <button
            onClick={() => setActiveTab('sitemap')}
            style={{
              ...tabButtonStyle(activeTab === 'sitemap'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            <Map size={16} style={{ marginRight: '8px' }} />
            {window.innerWidth <= 768 ? 'Map' : 'Site Map'}
          </button>
          <button
            onClick={() => setActiveTab('content')}
            style={{
              ...tabButtonStyle(activeTab === 'content'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            {window.innerWidth <= 768 ? 'Content' : 'Content Management'}
          </button>
          <button
            onClick={() => setActiveTab('subscribers')}
            style={{
              ...tabButtonStyle(activeTab === 'subscribers'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            <Users size={16} style={{ marginRight: '8px' }} />
            {window.innerWidth <= 768 ? `Subs (${subscribers.length})` : `Subscribers (${subscribers.length})`}
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            style={{
              ...tabButtonStyle(activeTab === 'feedback'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            <MessageSquare size={16} style={{ marginRight: '8px' }} />
            {window.innerWidth <= 768 ? `FB (${feedbacks.length})` : `Feedback (${feedbacks.length})`}
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            style={{
              ...tabButtonStyle(activeTab === 'settings'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            <Key size={16} style={{ marginRight: '8px' }} />
            Settings
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            style={{
              ...tabButtonStyle(activeTab === 'preview'),
              fontSize: window.innerWidth <= 768 ? '12px' : '14px',
              padding: window.innerWidth <= 768 ? '8px 12px' : '12px 24px',
              whiteSpace: 'nowrap'
            }}
          >
            <Eye size={16} style={{ marginRight: '8px' }} />
            Preview
          </button>
        </div>

        {/* Content Area */}
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {error && (
            <div style={{
              margin: '16px 32px',
              padding: '12px 16px',
              backgroundColor: '#FEF2F2',
              border: '1px solid #FCA5A5',
              borderRadius: '8px',
              color: '#B91C1C',
              fontSize: '14px'
            }}>
              {error}
            </div>
          )}

          {activeTab === 'sitemap' && (
            <div style={{ padding: '20px', flex: 1, overflow: 'auto' }}>
              <AdminSiteMap />
            </div>
          )}

          {activeTab === 'content' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto', width: '100%', boxSizing: 'border-box' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0, color: '#2D0051' }}>Website Content Management</h3>
                </div>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                  <select
                    value={currentLanguage}
                    onChange={(e) => setCurrentLanguage(e.target.value as 'en' | 'hu')}
                    style={{
                      padding: '8px 12px',
                      border: '1px solid #ddd',
                      borderRadius: '6px',
                      fontSize: '14px'
                    }}
                  >
                    <option value="en">English</option>
                    <option value="hu">Hungarian</option>
                  </select>
                </div>
              </div>
              
              <div style={{ width: '100%' }}>
                <AdminContentManager 
                  currentLanguage={currentLanguage} 
                  onLanguageChange={setCurrentLanguage}
                />
              </div>
            </div>
          )}

          {activeTab === 'subscribers' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h3 style={{ margin: 0, color: '#2D0051', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Users size={20} />
                      Newsletter Subscribers ({subscribers.length})
                    </h3>
                    <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                      Track all email subscriptions across the site
                    </p>
                  </div>
                  <button
                    onClick={fetchSubscribers}
                    style={{
                      padding: '8px 16px',
                      background: '#007bff',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      fontSize: '14px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    🔄 Refresh
                  </button>
                </div>
              </div>
              
              <div style={{ 
                background: '#f8f9fa', 
                borderRadius: '8px', 
                overflow: 'hidden',
                border: '1px solid #e9ecef'
              }}>
                <div style={{ 
                  padding: window.innerWidth <= 768 ? '12px' : '16px', 
                  background: '#fff', 
                  borderBottom: '1px solid #e9ecef',
                  display: 'grid',
                  gridTemplateColumns: window.innerWidth <= 768 ? '1fr' : '2fr 1fr 1fr 1fr',
                  gap: window.innerWidth <= 768 ? '8px' : '16px',
                  fontWeight: '600',
                  fontSize: window.innerWidth <= 768 ? '12px' : '14px',
                  color: '#495057'
                }}>
                  {window.innerWidth <= 768 ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Mail size={14} />
                      Email / Source / Language / Date
                    </div>
                  ) : (
                    <>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Mail size={16} />
                        Email
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Tag size={16} />
                        Source
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Globe size={16} />
                        Language
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Calendar size={16} />
                        Subscribed
                      </div>
                    </>
                  )}
                </div>
                
                <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                  {subscribers.length === 0 ? (
                    <div style={{ 
                      padding: '40px', 
                      textAlign: 'center', 
                      color: '#6c757d',
                      fontSize: '14px'
                    }}>
                      No subscribers yet. Email subscriptions will appear here.
                    </div>
                  ) : (
                    subscribers.map((subscriber, index) => (
                      <div key={subscriber.id} style={{ 
                        padding: window.innerWidth <= 768 ? '12px' : '16px',
                        background: index % 2 === 0 ? '#fff' : '#f8f9fa',
                        display: window.innerWidth <= 768 ? 'block' : 'grid',
                        gridTemplateColumns: window.innerWidth <= 768 ? 'none' : '2fr 1fr 1fr 1fr',
                        gap: window.innerWidth <= 768 ? '8px' : '16px',
                        fontSize: window.innerWidth <= 768 ? '12px' : '14px',
                        borderBottom: index < subscribers.length - 1 ? '1px solid #e9ecef' : 'none'
                      }}>
                        {window.innerWidth <= 768 ? (
                          <div>
                            <div style={{ 
                              fontWeight: '500',
                              color: '#2D0051',
                              wordBreak: 'break-word',
                              marginBottom: '4px'
                            }}>
                              {subscriber.email}
                            </div>
                            <div style={{ 
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                              fontSize: '11px',
                              color: '#6c757d'
                            }}>
                              <span style={{ 
                                padding: '2px 6px',
                                background: getSourceColor(subscriber.source),
                                color: 'white',
                                borderRadius: '3px',
                                fontSize: '10px',
                                fontWeight: '500'
                              }}>
                                {formatSource(subscriber.source)}
                              </span>
                              <span>{subscriber.language?.toUpperCase() || 'EN'}</span>
                              <span>{new Date(subscriber.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div style={{ 
                              fontWeight: '500',
                              color: '#2D0051',
                              wordBreak: 'break-word'
                            }}>
                              {subscriber.email}
                            </div>
                            <div style={{ 
                              padding: '4px 8px',
                              background: getSourceColor(subscriber.source),
                              color: 'white',
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: '500',
                              textAlign: 'center',
                              whiteSpace: 'nowrap'
                            }}>
                              {formatSource(subscriber.source)}
                            </div>
                            <div style={{ color: '#6c757d' }}>
                              {subscriber.language?.toUpperCase() || 'EN'}
                            </div>
                            <div style={{ color: '#6c757d' }}>
                              {new Date(subscriber.createdAt).toLocaleDateString()}
                            </div>
                          </>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ margin: 0, color: '#2D0051', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <MessageSquare size={20} />
                  User Feedback ({feedbacks.length})
                </h3>
                <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                  Monitor user feedback and ratings
                </p>
              </div>
              
              <div style={{ 
                background: '#f8f9fa', 
                borderRadius: '8px', 
                overflow: 'hidden',
                border: '1px solid #e9ecef'
              }}>
                <div style={{ maxHeight: '500px', overflowY: 'auto' }}>
                  {feedbacks.length === 0 ? (
                    <div style={{ 
                      padding: '40px', 
                      textAlign: 'center', 
                      color: '#6c757d',
                      fontSize: '14px'
                    }}>
                      No feedback yet. User feedback will appear here.
                    </div>
                  ) : (
                    feedbacks.map((feedback, index) => (
                      <div key={feedback.id} style={{ 
                        padding: window.innerWidth <= 768 ? '16px' : '20px',
                        background: '#fff',
                        borderBottom: index < feedbacks.length - 1 ? '1px solid #e9ecef' : 'none'
                      }}>
                        <div style={{ 
                          display: 'flex', 
                          justifyContent: 'space-between',
                          alignItems: 'flex-start',
                          marginBottom: '12px',
                          flexDirection: window.innerWidth <= 768 ? 'column' : 'row',
                          gap: window.innerWidth <= 768 ? '8px' : '0'
                        }}>
                          <div style={{ flex: 1 }}>
                            <div style={{ 
                              fontWeight: '600',
                              color: '#2D0051',
                              marginBottom: '4px',
                              fontSize: window.innerWidth <= 768 ? '14px' : '16px'
                            }}>
                              {feedback.name || 'Anonymous'} ({feedback.email})
                            </div>
                            <div style={{ 
                              display: 'flex',
                              alignItems: 'center',
                              gap: window.innerWidth <= 768 ? '8px' : '12px',
                              fontSize: window.innerWidth <= 768 ? '12px' : '13px',
                              color: '#6c757d',
                              flexWrap: 'wrap'
                            }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Star size={14} />
                                {feedback.rating}/5
                              </div>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Tag size={14} />
                                {formatSource(feedback.source)}
                              </div>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <Calendar size={14} />
                                {new Date(feedback.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                          <div style={{ 
                            padding: '4px 8px',
                            background: feedback.status === 'new' ? '#ffc107' : '#28a745',
                            color: 'white',
                            borderRadius: '4px',
                            fontSize: '12px',
                            fontWeight: '500',
                            alignSelf: window.innerWidth <= 768 ? 'flex-start' : 'auto'
                          }}>
                            {feedback.status?.toUpperCase() || 'NEW'}
                          </div>
                        </div>
                        <div style={{ 
                          color: '#495057',
                          lineHeight: '1.6',
                          fontSize: window.innerWidth <= 768 ? '13px' : '14px',
                          padding: window.innerWidth <= 768 ? '8px' : '12px',
                          background: '#f8f9fa',
                          borderRadius: '6px',
                          borderLeft: '4px solid #5C37C7'
                        }}>
                          {feedback.message}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px' }}>
                <h3 style={{ margin: 0, color: '#2D0051' }}>Admin Settings</h3>
                <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                  Update admin credentials and system settings
                </p>
              </div>
              
              <div style={{
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                padding: '24px',
                marginBottom: '24px'
              }}>
                <h4 style={{ margin: '0 0 16px 0', color: '#2D0051' }}>Change Admin Credentials</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      Current Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.currentPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, currentPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      New Login Name
                    </label>
                    <input
                      type="text"
                      value={credentialsForm.newLoginName}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, newLoginName: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      New Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.newPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, newPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', color: '#374151' }}>
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      value={credentialsForm.confirmPassword}
                      onChange={(e) => setCredentialsForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '6px',
                        fontSize: '14px'
                      }}
                    />
                  </div>
                  <button
                    onClick={handleUpdateCredentials}
                    disabled={loading}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#5C37C7',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      cursor: loading ? 'not-allowed' : 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    {loading ? 'Updating...' : 'Update Credentials'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'preview' && (
            <div style={{ padding: '32px', flex: 1, overflow: 'auto' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ margin: 0, color: '#2D0051' }}>Live Preview</h3>
                  <p style={{ margin: '4px 0 0', color: '#6c757d', fontSize: '14px' }}>
                    Preview your changes in real-time
                  </p>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => setPreviewMode('desktop')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'desktop' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'desktop' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Monitor size={16} />
                    Desktop
                  </button>
                  <button
                    onClick={() => setPreviewMode('mobile')}
                    style={{
                      padding: '8px 16px',
                      backgroundColor: previewMode === 'mobile' ? '#5C37C7' : '#f8f9fa',
                      color: previewMode === 'mobile' ? 'white' : '#6c757d',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Smartphone size={16} />
                    Mobile
                  </button>
                </div>
              </div>
              
              <div style={{
                border: '1px solid #e9ecef',
                borderRadius: '8px',
                height: '500px',
                overflow: 'hidden'
              }}>
                <iframe
                  src={window.location.origin}
                  style={{
                    width: previewMode === 'mobile' ? '375px' : '100%',
                    height: '100%',
                    border: 'none',
                    margin: previewMode === 'mobile' ? '0 auto' : '0',
                    display: 'block'
                  }}
                  title="Live Preview"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;