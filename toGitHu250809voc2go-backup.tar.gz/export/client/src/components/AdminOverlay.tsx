import React, { useState, useEffect, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import logo from "@assets/JoV2VLogo240815.png";
import AdminContentManager from "./AdminContentManager";

interface AdminOverlayProps {
  onClose: () => void;
}

const AdminOverlay: React.FC<AdminOverlayProps> = ({ onClose }) => {
  const { t } = useLanguage();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showWebView, setShowWebView] = useState(false);
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [showContentManager, setShowContentManager] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStatus, setPublishStatus] = useState<null | 'success' | 'error'>(null);
  const [lastDeployTime, setLastDeployTime] = useState<string | null>(
    localStorage.getItem('lastDeployTime')
  );
  const [credentials, setCredentials] = useState({
    username: "",
    password: ""
  });
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const timeoutRefs = useRef<NodeJS.Timeout[]>([]);
  
  // Check if already logged in on mount and cleanup timeouts
  useEffect(() => {
    const loggedIn = localStorage.getItem("adminLoggedIn") === "true";
    if (loggedIn) {
      setIsLoggedIn(true);
    }
    
    // Cleanup all timeouts on unmount
    return () => {
      timeoutRefs.current.forEach(clearTimeout);
      timeoutRefs.current = [];
    };
  }, []);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    // Simple mock login
    const loginTimeout = setTimeout(() => {
      if (credentials.username === "admin" && credentials.password === "admin123") {
        setIsLoggedIn(true);
        localStorage.setItem("adminLoggedIn", "true");
      } else {
        setError(t("Invalid username or password"));
      }
      setIsLoading(false);
    }, 800);
    timeoutRefs.current.push(loginTimeout);
  };
  
  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    setIsLoggedIn(false);
  };
  
  const toggleWebView = () => {
    setShowWebView(!showWebView);
  };
  
  const handleTabClick = (tabName: string) => {
    setActiveTab(tabName);
  };
  
  const handleManageContent = () => {
    setShowContentManager(true);
  };
  
  const handleContentSave = (data: any) => {
    // In a real app, this would save to backend
    console.log("Content saved:", data);
    setShowContentManager(false);
    
    // Show success notification
    setPublishStatus('success');
    const successTimeout = setTimeout(() => {
      setPublishStatus(null);
    }, 3000);
    timeoutRefs.current.push(successTimeout);
  };
  
  const handlePublishWebsite = () => {
    setIsPublishing(true);
    setPublishStatus(null);
    
    // Simulate publishing/deployment process
    const publishTimeout = setTimeout(() => {
      setIsPublishing(false);
      setPublishStatus('success');
      
      // Save the current timestamp to localStorage
      const currentTime = new Date().toLocaleString();
      localStorage.setItem('lastDeployTime', currentTime);
      setLastDeployTime(currentTime);
      
      // Reset status message after 5 seconds
      const resetTimeout = setTimeout(() => {
        setPublishStatus(null);
      }, 5000);
      timeoutRefs.current.push(resetTimeout);
    }, 3000);
    timeoutRefs.current.push(publishTimeout);
  };
  
  return (
    <div className="admin-overlay">
      {isLoggedIn ? (
        showWebView ? (
          // Web View
          <div className="website-preview-container">
            <div className="preview-header">
              <h2>{t("Website Preview")}</h2>
              <div className="preview-controls">
                <button className="back-button" onClick={toggleWebView}>
                  {t("Back to Admin")}
                </button>
                <button className="close-button" onClick={onClose}>×</button>
              </div>
            </div>
            <iframe 
              src={window.location.origin} 
              title="Website Preview" 
              className="website-iframe"
            />
          </div>
        ) : showContentManager ? (
          // Content Manager View
          <div className="admin-container content-editor-view">
            <div className="admin-header">
              <img src={logo} alt="VOC2GO" className="admin-logo" />
              <h2>{t("Content Management")}</h2>
              <button className="close-button" onClick={() => setShowContentManager(false)}>×</button>
            </div>
            <AdminContentManager 
              currentLanguage="en"
              onLanguageChange={() => {}}
            />
          </div>
        ) : (
          // Admin Dashboard
          <div className="admin-container">
            <div className="admin-header">
              <img src={logo} alt="VOC2GO" className="admin-logo" />
              <h2>{t("Admin Dashboard")}</h2>
              <button className="close-button" onClick={onClose}>×</button>
            </div>
            
            <div className="admin-content">
              <div className="admin-welcome">
                <h3>{t("Welcome to VOC2GO Admin Dashboard")}</h3>
                <p>{t("Manage your website content, campaigns, and user data from this dashboard.")}</p>
                <div className="admin-welcome-actions">
                  <button className="admin-logout-btn" onClick={handleLogout}>
                    {t("Logout")}
                  </button>
                  <button className="admin-view-website-btn" onClick={toggleWebView}>
                    {t("View Website")}
                  </button>
                </div>
              </div>
              
              <div className="admin-stats">
                <div className="stat-card">
                  <h4>{t("Subscribers")}</h4>
                  <p className="stat-number">245</p>
                </div>
                <div className="stat-card">
                  <h4>{t("Campaign Progress")}</h4>
                  <p className="stat-number">35%</p>
                  <div className="progress-bar">
                    <div className="progress" style={{ width: "35%" }}></div>
                  </div>
                </div>
                <div className="stat-card">
                  <h4>{t("Media Files")}</h4>
                  <p className="stat-number">12</p>
                </div>
              </div>
              
              <div className="admin-tabs">
                <div 
                  className={`admin-tab ${activeTab === "Dashboard" ? "active" : ""}`}
                  onClick={() => handleTabClick("Dashboard")}
                >
                  {t("Dashboard")}
                </div>
                <div 
                  className={`admin-tab ${activeTab === "Content" ? "active" : ""}`}
                  onClick={() => handleTabClick("Content")}
                >
                  {t("Content")}
                </div>
                <div 
                  className={`admin-tab ${activeTab === "Campaigns" ? "active" : ""}`}
                  onClick={() => handleTabClick("Campaigns")}
                >
                  {t("Campaigns")}
                </div>
                <div 
                  className={`admin-tab ${activeTab === "Media" ? "active" : ""}`}
                  onClick={() => handleTabClick("Media")}
                >
                  {t("Media")}
                </div>
                <div 
                  className={`admin-tab ${activeTab === "Settings" ? "active" : ""}`}
                  onClick={() => handleTabClick("Settings")}
                >
                  {t("Settings")}
                </div>
              </div>
              
              <div className="admin-main-content">
                {activeTab === "Dashboard" && (
                  <>
                    <h3>{t("Recent Activity")}</h3>
                    <ul className="activity-list">
                      <li>{t("New subscriber")}: maria@example.com</li>
                      <li>{t("Campaign")} "Early Bird" {t("received a new backer")}</li>
                      <li>{t("New feedback received from")}: john@example.com</li>
                      <li>{t("Website settings updated")}</li>
                    </ul>
                    
                    <h3>{t("Quick Actions")}</h3>
                    <div className="admin-actions">
                      <button className="admin-button" onClick={handleManageContent}>{t("Manage Content")}</button>
                      <button className="admin-button">{t("View Subscribers")}</button>
                      <button className="admin-button">{t("Campaign Settings")}</button>
                      <button className="admin-button">{t("Upload Media")}</button>
                      <button className="admin-button highlight" onClick={toggleWebView}>{t("View Website")}</button>
                    </div>
                  </>
                )}
                
                {activeTab === "Content" && (
                  <>
                    <h3>{t("Website Content")}</h3>
                    <p>{t("Manage and edit content for different sections of your website in both English and Hungarian.")}</p>
                    
                    <div className="content-sections">
                      <div className="content-section-card" onClick={handleManageContent}>
                        <h4>{t("Hero Section")}</h4>
                        <p>{t("Edit main headline, subheadline, and call-to-action buttons")}</p>
                        <button className="edit-btn">{t("Edit")}</button>
                      </div>
                      
                      <div className="content-section-card" onClick={handleManageContent}>
                        <h4>{t("Features Section")}</h4>
                        <p>{t("Edit feature headings, descriptions, and benefits")}</p>
                        <button className="edit-btn">{t("Edit")}</button>
                      </div>
                      
                      <div className="content-section-card" onClick={handleManageContent}>
                        <h4>{t("Vision Section")}</h4>
                        <p>{t("Edit vision statement, market information, and goals")}</p>
                        <button className="edit-btn">{t("Edit")}</button>
                      </div>
                      
                      <div className="content-section-card" onClick={handleManageContent}>
                        <h4>{t("Campaign Section")}</h4>
                        <p>{t("Edit campaign details, rewards, and pricing")}</p>
                        <button className="edit-btn">{t("Edit")}</button>
                      </div>
                    </div>
                    
                    <button 
                      className="manage-all-content-btn" 
                      onClick={handleManageContent}
                    >
                      {t("Manage All Content")}
                    </button>
                  </>
                )}
                
                {(activeTab === "Dashboard" || activeTab === "Settings") && (
                  <>
                    <h3>{t("Website Deployment")}</h3>
                    <div className="publish-container">
                      <div className="publish-info">
                        {lastDeployTime && (
                          <p className="last-deploy-time">
                            {t("Last deployed")}: <span>{lastDeployTime}</span>
                          </p>
                        )}
                        {publishStatus === 'success' && (
                          <div className="publish-notification success">
                            {t("Website published successfully!")}
                          </div>
                        )}
                        {publishStatus === 'error' && (
                          <div className="publish-notification error">
                            {t("Deployment failed. Please try again.")}
                          </div>
                        )}
                      </div>
                      <button 
                        className={`publish-button ${isPublishing ? 'publishing' : ''}`}
                        onClick={handlePublishWebsite}
                        disabled={isPublishing}
                      >
                        {isPublishing ? (
                          <>
                            <span className="spinner"></span>
                            {t("Publishing...")}
                          </>
                        ) : (
                          t("Publish Website")
                        )}
                      </button>
                    </div>
                  </>
                )}
                
                {activeTab === "Settings" && (
                  <>
                    <h3>{t("Language Settings")}</h3>
                    <div className="language-settings">
                      <div className="settings-info">
                        <p>{t("Manage translations and language options for your website.")}</p>
                        <p>{t("Current languages supported")}: <strong>English, Hungarian</strong></p>
                      </div>
                      <button className="settings-button" onClick={handleManageContent}>
                        {t("Manage Translations")}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )
      ) : (
        // Login Form
        <div className="admin-login-container">
          <div className="login-header">
            <img src={logo} alt="VOC2GO" className="admin-logo" />
            <h2>{t("Admin Login")}</h2>
            <button className="close-button" onClick={onClose}>×</button>
          </div>
          
          {error && <div className="error-message">{error}</div>}
          
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="username">{t("Username")}</label>
              <input
                type="text"
                id="username"
                name="username"
                value={credentials.username}
                onChange={handleChange}
                required
                placeholder={t("Enter your username")}
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="password">{t("Password")}</label>
              <input
                type="password"
                id="password"
                name="password"
                value={credentials.password}
                onChange={handleChange}
                required
                placeholder={t("Enter your password")}
              />
            </div>
            
            <div className="form-actions">
              <button 
                type="submit" 
                className="login-button"
                disabled={isLoading}
              >
                {isLoading ? t("Logging in...") : t("Login")}
              </button>
            </div>
          </form>
          
          <div className="login-hint">
            <p>{t("Use these credentials")}:</p>
            <p><strong>{t("Username")}</strong>: admin</p>
            <p><strong>{t("Password")}</strong>: admin123</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOverlay;