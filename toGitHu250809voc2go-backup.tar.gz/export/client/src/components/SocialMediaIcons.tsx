import React, { useState, useEffect } from 'react';
import { Instagram, Facebook, Linkedin, Globe, Heart, ExternalLink } from 'lucide-react';
import { FaPinterest } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';
import { SiBehance } from 'react-icons/si';

interface SocialLinks {
  instagram?: string;
  facebook?: string;
  linkedin?: string;
  behance?: string;
  kofi?: string;
  pinterest?: string;
  twitter?: string;
  website?: string;
}

interface SocialMediaIconsProps {
  memberId: string;
}

const SocialMediaIcons: React.FC<SocialMediaIconsProps> = ({ memberId }) => {
  const [socialLinks, setSocialLinks] = useState<SocialLinks>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSocialLinks();
  }, [memberId]);

  const loadSocialLinks = async () => {
    try {
      const response = await fetch(`/api/team-socials/${memberId}`);
      const data = await response.json();
      
      if (response.ok && data.socials) {
        setSocialLinks(data.socials);
      }
    } catch (err) {
      console.error('Error loading social links:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSocialClick = (url: string) => {
    let finalUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      finalUrl = 'https://' + url;
    }
    window.open(finalUrl, '_blank', 'noopener,noreferrer');
  };

  if (loading) {
    return null;
  }

  // Create array of available social platforms with their data
  const availableSocials = [];
  
  // Only show icons for platforms with valid, non-empty URLs
  if (socialLinks.instagram && socialLinks.instagram.trim() && socialLinks.instagram.trim() !== '') {
    availableSocials.push({
      key: 'instagram',
      icon: Instagram,
      color: '#E4405F',
      url: socialLinks.instagram.trim()
    });
  }
  
  if (socialLinks.facebook && socialLinks.facebook.trim() && socialLinks.facebook.trim() !== '') {
    availableSocials.push({
      key: 'facebook', 
      icon: Facebook,
      color: '#1877F2',
      url: socialLinks.facebook.trim()
    });
  }
  
  if (socialLinks.linkedin && socialLinks.linkedin.trim() && socialLinks.linkedin.trim() !== '') {
    availableSocials.push({
      key: 'linkedin',
      icon: Linkedin, 
      color: '#0A66C2',
      url: socialLinks.linkedin.trim()
    });
  }
  
  if (socialLinks.behance && socialLinks.behance.trim() && socialLinks.behance.trim() !== '') {
    availableSocials.push({
      key: 'behance',
      icon: SiBehance,
      color: '#1769FF', 
      url: socialLinks.behance.trim()
    });
  }
  
  if (socialLinks.kofi && socialLinks.kofi.trim() && socialLinks.kofi.trim() !== '') {
    availableSocials.push({
      key: 'kofi',
      icon: Heart,
      color: '#FF5E5B',
      url: socialLinks.kofi.trim()
    });
  }
  
  if (socialLinks.pinterest && socialLinks.pinterest.trim() && socialLinks.pinterest.trim() !== '') {
    availableSocials.push({
      key: 'pinterest',
      icon: FaPinterest,
      color: '#E60023',
      url: socialLinks.pinterest.trim()
    });
  }
  
  if (socialLinks.twitter && socialLinks.twitter.trim() && socialLinks.twitter.trim() !== '') {
    availableSocials.push({
      key: 'twitter',
      icon: FaXTwitter,
      color: '#000000',
      url: socialLinks.twitter.trim()
    });
  }
  
  if (socialLinks.website && socialLinks.website.trim() && socialLinks.website.trim() !== '') {
    availableSocials.push({
      key: 'website',
      icon: ExternalLink,
      color: '#6366F1',
      url: socialLinks.website.trim()
    });
  }

  // Don't render if no social links
  if (availableSocials.length === 0) {
    return null;
  }

  return (
    <div 
      style={{ 
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '20px',
        marginTop: '20px',
        width: '100%'
      }}
    >
      {availableSocials.map(({ key, icon: Icon, color, url }) => (
        <button
          key={key}
          onClick={() => handleSocialClick(url)}
          style={{
            width: '48px',
            height: '48px',
            borderRadius: '50%',
            backgroundColor: color,
            border: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'transform 0.2s ease',
            outline: 'none'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
          }}
          title={`Visit ${key} profile`}
          aria-label={`Visit ${key} profile`}
        >
          {(key === 'pinterest' || key === 'twitter' || key === 'behance') ? (
            <Icon size={22} color="white" />
          ) : (
            <Icon size={22} color="white" />
          )}
        </button>
      ))}
    </div>
  );
};

export default SocialMediaIcons;