import React, { useState, useRef } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { ChevronDown } from "lucide-react";

const FAQSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();
  const [openItems, setOpenItems] = useState<number[]>([]);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);
  const faqRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent, index: number) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        const nextIndex = (index + 1) % faqRefs.current.length;
        faqRefs.current[nextIndex]?.focus();
        break;
      case 'ArrowUp':
        e.preventDefault();
        const prevIndex = (index - 1 + faqRefs.current.length) % faqRefs.current.length;
        faqRefs.current[prevIndex]?.focus();
        break;
      case 'Home':
        e.preventDefault();
        faqRefs.current[0]?.focus();
        break;
      case 'End':
        e.preventDefault();
        faqRefs.current[faqRefs.current.length - 1]?.focus();
        break;
    }
  };

  const faqs = [
    {
      question: getContentText('faq-question-1', language === 'en' 
        ? "How is VOC2GO different from other language learning apps?"
        : "Miben különbözik a VOC2GO más nyelvtanuló alkalmazásoktól?"),
      answer: getContentText('faq-answer-1', language === 'en'
        ? "VOC2GO uses AI to create personalized conversations and stories based on YOUR interests and goals. Instead of generic lessons, you learn vocabulary through meaningful contexts that matter to you. Our story-driven approach ensures 85% better retention compared to traditional apps."
        : "A VOC2GO MI-t használ személyre szabott beszélgetések és történetek létrehozására, amelyek az ÖN érdeklődési köréhez és céljaihoz igazodnak. Általános leckék helyett olyan jelentős kontextusokban tanul szókincset, amelyek fontosak az Ön számára. Történetvezérelt megközelítésünk 85%-kal jobb megjegyzést biztosít a hagyományos alkalmazásokhoz képest.")
    },
    {
      question: getContentText('faq-question-2', language === 'en' 
        ? "How does the hour-based access model work?"
        : "Hogyan működik az óraalapú hozzáférési modell?"),
      answer: getContentText('faq-answer-2', language === 'en'
        ? "You pay for a specific number of premium access hours during the MVP phase. This means you only pay for the time you actually use the premium features - no monthly subscriptions or recurring fees. Your hours don't expire and you can use them at your own pace."
        : "Egy meghatározott számú prémium hozzáférési órát fizetsz ki az MVP fázis alatt. Ez azt jelenti, hogy csak azért az időért fizetsz, amit ténylegesen használsz a prémium funkciókkal - nincsenek havi előfizetések vagy visszatérő díjak. Az órák nem járnak le, és a saját tempódban használhatod őket.")
    },
    {
      question: getContentText('faq-question-3', language === 'en' 
        ? "When will the app be available?"
        : "Mikor lesz elérhető az alkalmazás?"),
      answer: getContentText('faq-answer-3', language === 'en'
        ? "We plan to launch the MVP (beta version) within 6 months of successful funding. Early supporters will get access 2 months before public release. The full version with all premium features will follow 3-4 months after the MVP launch."
        : "A sikeres finanszírozást követően 6 hónapon belül tervezzük az MVP (béta verzió) elindítását. A korai támogatók 2 hónappal a nyilvános kiadás előtt férhetnek hozzá. A teljes verzió minden prémium funkcióval az MVP indítása után 3-4 hónappal követi.")
    },
    {
      question: getContentText('faq-question-4', language === 'en' 
        ? "What devices will VOC2GO support?"
        : "Milyen eszközöket támogat majd a VOC2GO?"),
      answer: getContentText('faq-answer-4', language === 'en'
        ? "VOC2GO will be available on iOS and Android smartphones and tablets. We're also planning a web version for desktop users. All your progress syncs across devices, so you can learn anywhere, anytime."
        : "A VOC2GO elérhető lesz iOS és Android okostelefonokon és táblagépeken. Asztali felhasználók számára webes verziót is tervezünk. Az összes előrehaladás szinkronizálódik az eszközök között, így bárhol, bármikor tanulhat.")
    },
    {
      question: getContentText('faq-question-5', language === 'en' 
        ? "Is there a refund policy?"
        : "Van visszatérítési szabályzat?"),
      answer: getContentText('faq-answer-5', language === 'en'
        ? "As stated in our campaign terms, all contributions are final and non-refundable. This is standard for crowdfunding campaigns as funds are immediately used for development. However, we're committed to delivering on our promises and providing regular updates on our progress."
        : "Ahogy a kampány feltételeiben szerepel, minden hozzájárulás végleges és nem visszatéríthető. Ez standard a crowdfunding kampányoknál, mivel a forrásokat azonnal fejlesztésre használjuk. Azonban elkötelezettek vagyunk ígéreteink betartása és rendszeres előrehaladási frissítések nyújtása mellett.")
    },
    {
      question: getContentText('faq-question-6', language === 'en' 
        ? "How much content will be available at launch?"
        : "Mennyi tartalom lesz elérhető az indításkor?"),
      answer: getContentText('faq-answer-6', language === 'en'
        ? "The MVP will include 5,000+ vocabulary words, 100+ story scenarios, and conversation practice in 20+ topics. We'll continuously add content based on user feedback. Premium supporters get access to advanced features like speaking practice and personalized learning paths."
        : "Az MVP 5000+ szókincssót, 100+ történetforgatókönyvet és beszélgetésgyakorlatot tartalmaz 20+ témában. Folyamatosan bővítjük a tartalmat a felhasználói visszajelzések alapján. A prémium támogatók hozzáférnek a fejlett funkciókhoz, mint a beszédgyakorlat és a személyre szabott tanulási útvonalak.")
    },
    {
      question: getContentText('faq-question-7', language === 'en' 
        ? "Can I use VOC2GO offline?"
        : "Használhatom a VOC2GO-t offline?"),
      answer: getContentText('faq-answer-7', language === 'en'
        ? "Yes! While the AI conversation features require internet connectivity, you can download lessons and practice materials for offline use. Perfect for learning during commutes or while traveling."
        : "Igen! Míg az MI beszélgetési funkciók internetkapcsolatot igényelnek, letöltheti a leckéket és gyakorlati anyagokat offline használatra. Tökéletes tanuláshoz ingázás közben vagy utazás közben.")
    }
  ];

  return (
    <section 
      id="faq" 
      role="region"
      aria-labelledby="faq-heading"
      style={{
        padding: "80px 0",
        background: "linear-gradient(135deg, rgba(245, 245, 247, 1) 0%, rgba(255, 255, 255, 1) 100%)",
        position: "relative"
      }}
    >
      <div className="container" style={{ maxWidth: "800px", margin: "0 auto", padding: "0 20px" }}>
        <div className="section-header" style={{ textAlign: "center", marginBottom: "60px" }}>
          <h2 
            id="faq-heading"
            style={{ 
              fontSize: "2.5rem", 
              marginBottom: "20px",
              background: "linear-gradient(90deg, #5C37C7, #44d1c6)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              fontWeight: "bold"
            }}
          >
            {getContentText('faq-heading', language === 'en' ? "Frequently Asked Questions" : "Gyakran Ismételt Kérdések")}
          </h2>
          
          <p style={{ 
            fontSize: "1.2rem", 
            maxWidth: "600px", 
            margin: "0 auto",
            color: "#666",
            lineHeight: "1.6"
          }}>
            {getContentText('faq-description', language === 'en' 
              ? "Everything you need to know about VOC2GO and our crowdfunding campaign."
              : "Minden, amit tudnia kell a VOC2GO-ról és crowdfunding kampányunkról."
            )}
          </p>
        </div>
        
        <div style={{ maxWidth: "700px", margin: "0 auto" }}>
          {faqs.map((faq, index) => {
            const isOpen = openItems.includes(index);
            return (
              <div
                key={index}
                style={{
                  background: "white",
                  borderRadius: "12px",
                  marginBottom: "20px",
                  boxShadow: isOpen ? "0 8px 30px rgba(92, 55, 199, 0.15)" : "0 4px 20px rgba(0, 0, 0, 0.08)",
                  overflow: "hidden",
                  border: isOpen ? "2px solid rgba(92, 55, 199, 0.2)" : "1px solid rgba(92, 55, 199, 0.1)",
                  transition: "all 0.4s cubic-bezier(0.4, 0, 0.2, 1)",
                  transform: isOpen ? "scale(1.02)" : "scale(1)"
                }}
              >
                <button
                  ref={(el) => faqRefs.current[index] = el}
                  onClick={() => toggleItem(index)}
                  onKeyDown={(e) => handleKeyDown(e, index)}
                  onFocus={() => setFocusedIndex(index)}
                  onBlur={() => setFocusedIndex(null)}
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${index}`}
                  id={`faq-question-${index}`}
                  style={{
                    width: "100%",
                    padding: "20px 24px",
                    background: focusedIndex === index ? "rgba(92, 55, 199, 0.05)" : "transparent",
                    border: "none",
                    textAlign: "left",
                    cursor: "pointer",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontSize: "1.1rem",
                    fontWeight: "600",
                    color: "#2D0051",
                    transition: "all 0.3s ease",
                    outline: focusedIndex === index ? "2px solid #5C37C7" : "none",
                    outlineOffset: "2px"
                  }}
                >
                  <span style={{ paddingRight: "16px" }}>{faq.question}</span>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      flexShrink: 0,
                      transform: isOpen ? "rotate(180deg)" : "rotate(0deg)",
                      transition: "transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                    }}
                    aria-hidden="true"
                  >
                    <ChevronDown size={20} style={{ color: "#5C37C7" }} />
                  </span>
                </button>
                
                <div
                  id={`faq-answer-${index}`}
                  role="region"
                  aria-labelledby={`faq-question-${index}`}
                  style={{
                    maxHeight: isOpen ? "500px" : "0",
                    overflow: "hidden",
                    transition: "all 0.4s cubic-bezier(0.4, 0, 0.2, 1)",
                    opacity: isOpen ? 1 : 0,
                    transform: isOpen ? "translateY(0)" : "translateY(-10px)"
                  }}
                >
                  <div style={{ padding: "0 24px 24px", borderTop: "1px solid rgba(0, 0, 0, 0.05)" }}>
                    <p style={{
                      margin: "16px 0 0",
                      lineHeight: "1.6",
                      color: "#4D4D4D",
                      fontSize: "1rem"
                    }}>
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;