import React, { useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { CheckCircle, Crown, Globe, Mail, Star, Zap, BookOpen, Users } from "lucide-react";
import { useAdaptiveCardSize } from "../hooks/useAdaptiveCardSize";
import "../styles/adaptive-cards.css";

interface RewardCardProps {
  title: string;
  price: string;
  benefits: string[];
  limitText?: string;
  delay: number;
  icon: React.ReactNode;
  featured?: boolean;
  getContentText: (key: string, fallback: string) => string;
  language: string;
}

// Newsletter Card Component
interface NewsletterCardProps {
  subscribed: boolean;
  email: string;
  setEmail: (email: string) => void;
  handleSubscribe: (e: React.FormEvent) => void;
}

const NewsletterCard: React.FC<NewsletterCardProps> = ({ subscribed, email, setEmail, handleSubscribe }) => {
  const { t } = useLanguage();
  const { getCardStyle, getTitleStyle, getContentDensityClass } = useAdaptiveCardSize();
  
  const cardStyle = getCardStyle('generic');
  const titleStyle = getTitleStyle();
  
  return (
    <div 
      className={`adaptive-card ${getContentDensityClass()}`}
      style={{
        background: 'rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2)',
        textAlign: 'center',
        marginBottom: '40px',
        ...cardStyle
      }}
    >
      <div className="adaptive-card-content">
        <div className="adaptive-card-header" style={{ justifyContent: 'center', marginBottom: 'var(--section-spacing)' }}>
          <h3 
            className="adaptive-card-title"
            style={{ 
              fontWeight: 'bold',
              color: 'white',
              textAlign: 'center',
              width: '100%',
              ...titleStyle
            }}
          >
            {t("Stay Updated")}
          </h3>
        </div>
        
        <div className="adaptive-card-body" style={{ maxWidth: '500px', margin: '0 auto' }}>
          <p style={{ 
            opacity: '0.8',
            marginBottom: 'var(--section-spacing)',
            lineHeight: 'var(--line-height)',
            color: 'white'
          }}>
            {t("Subscribe to our newsletter for campaign updates and be the first to know when we launch")}
          </p>
          
          {subscribed ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '15px',
              padding: '20px',
              background: 'rgba(255, 255, 255, 0.05)',
              borderRadius: '12px'
            }}>
              <div style={{
                width: '60px',
                height: '60px',
                borderRadius: '50%',
                background: '#44d1c6',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
              }}>
                <CheckCircle size={30} />
              </div>
              <p style={{ 
                fontSize: '18px',
                fontWeight: '500',
                color: 'white'
              }}>{t("Thanks for subscribing!")}</p>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} style={{ width: '100%' }}>
              <div style={{ position: 'relative', marginBottom: '20px' }}>
                <div style={{ 
                  position: 'absolute', 
                  left: '15px', 
                  top: '50%', 
                  transform: 'translateY(-50%)',
                  color: '#44d1c6'
                }}>
                  <Mail size={18} />
                </div>
                <input 
                  type="email" 
                  id="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder={t("Enter your email address")}
                  style={{
                    width: '100%',
                    padding: '14px 14px 14px 45px',
                    borderRadius: '8px',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    background: 'rgba(255, 255, 255, 0.05)',
                    color: 'white',
                    fontSize: '16px',
                    transition: 'all 0.3s ease',
                    outline: 'none'
                  }}
                />
              </div>
              <button 
                type="submit" 
                style={{
                  background: 'linear-gradient(to right, #F7941D, #e78100)',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  padding: '14px 30px',
                  fontSize: '16px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '10px',
                  width: '100%',
                  transition: 'all 0.3s ease',
                  boxShadow: '0 8px 20px rgba(247, 148, 29, 0.3)',
                  minHeight: '44px'
                }}
                onMouseEnter={(e) => {
                  const target = e.currentTarget;
                  target.style.transform = 'translateY(-5px)';
                  target.style.boxShadow = '0 12px 25px rgba(247, 148, 29, 0.4)';
                }}
                onMouseLeave={(e) => {
                  const target = e.currentTarget;
                  target.style.transform = 'translateY(0)';
                  target.style.boxShadow = '0 8px 20px rgba(247, 148, 29, 0.3)';
                }}
              >
                {t("Subscribe")}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

const RewardCard: React.FC<RewardCardProps> = ({ title, price, benefits, limitText, delay, icon, featured = false, getContentText, language }) => {
  const { t } = useLanguage();
  
  return (
    <div 
      style={{ 
        animationDelay: `${delay}s`,
        opacity: 0,
        animation: 'fadeInUp 0.5s ease forwards',
        background: featured 
          ? 'linear-gradient(135deg, rgba(247, 148, 29, 0.2) 0%, rgba(68, 209, 198, 0.1) 100%)' 
          : 'rgba(255, 255, 255, 0.05)',
        backdropFilter: 'blur(10px)',
        borderRadius: '16px',
        padding: '30px',
        border: featured 
          ? '1px solid rgba(247, 148, 29, 0.3)' 
          : '1px solid rgba(255, 255, 255, 0.1)',
        boxShadow: featured 
          ? '0 15px 35px rgba(0, 0, 0, 0.25)' 
          : '0 10px 30px rgba(0, 0, 0, 0.15)',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        position: 'relative',
        overflow: 'hidden',
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
      }}
      className={featured ? 'featured-card' : ''}
      onMouseEnter={(e) => {
        const target = e.currentTarget;
        target.style.transform = 'translateY(-10px)';
        target.style.boxShadow = featured 
          ? '0 20px 40px rgba(0, 0, 0, 0.3)' 
          : '0 15px 35px rgba(0, 0, 0, 0.2)';
      }}
      onMouseLeave={(e) => {
        const target = e.currentTarget;
        target.style.transform = 'translateY(0)';
        target.style.boxShadow = featured 
          ? '0 15px 35px rgba(0, 0, 0, 0.25)' 
          : '0 10px 30px rgba(0, 0, 0, 0.15)';
      }}
    >
      {featured && (
        <div style={{
          position: 'absolute',
          top: '12px',
          right: '-30px',
          background: '#F7941D',
          color: 'white',
          padding: '5px 40px',
          transform: 'rotate(45deg)',
          fontSize: '12px',
          fontWeight: 'bold',
          boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)'
        }}>
          {t("MOST POPULAR")}
        </div>
      )}
      
      <div style={{ 
        display: 'flex',
        alignItems: 'center',
        gap: '15px',
        marginBottom: '20px'
      }}>
        <div style={{
          width: '50px',
          height: '50px',
          borderRadius: '50%',
          background: featured ? '#F7941D' : 'rgba(255, 255, 255, 0.1)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: featured ? 'white' : '#44d1c6'
        }}>
          {icon}
        </div>
        <h3 style={{ 
          margin: 0, 
          fontSize: '22px', 
          fontWeight: 'bold',
          color: 'white'
        }}>{t(title)}</h3>
      </div>
      
      <div style={{
        fontSize: '36px',
        fontWeight: 'bold',
        marginBottom: '25px',
        color: featured ? '#F7941D' : 'white'
      }}>{price}</div>
      
      <ul style={{
        listStyle: 'none',
        padding: 0,
        margin: '0 0 25px 0',
        flex: 1
      }}>
        {benefits.map((benefit, index) => (
          <li key={index} style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: '10px',
            marginBottom: '15px',
            color: 'rgba(255, 255, 255, 0.9)'
          }}>
            <div style={{ color: featured ? '#F7941D' : '#44d1c6', marginTop: '3px' }}>
              <CheckCircle size={18} />
            </div>
            <span style={{ fontSize: '16px' }}>{t(benefit)}</span>
          </li>
        ))}
      </ul>
      
      {limitText && (
        <div style={{
          background: 'rgba(255, 255, 255, 0.1)',
          padding: '10px 15px',
          borderRadius: '8px',
          fontSize: '14px',
          marginBottom: '25px',
          textAlign: 'center',
          color: 'rgba(255, 255, 255, 0.8)'
        }}>
          {t(limitText)}
        </div>
      )}
      
      <button style={{
        background: featured 
          ? 'linear-gradient(to right, #F7941D, #e78100)' 
          : 'rgba(255, 255, 255, 0.1)',
        color: 'white',
        border: featured ? 'none' : '1px solid rgba(255, 255, 255, 0.3)',
        borderRadius: '8px',
        padding: '14px 20px',
        fontSize: '16px',
        fontWeight: '600',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '10px',
        width: '100%',
        transition: 'all 0.3s ease',
        boxShadow: featured ? '0 8px 20px rgba(247, 148, 29, 0.3)' : 'none'
      }}
      onMouseEnter={(e) => {
        const target = e.currentTarget;
        target.style.transform = 'translateY(-5px)';
        if (featured) {
          target.style.boxShadow = '0 12px 25px rgba(247, 148, 29, 0.4)';
        } else {
          target.style.background = 'rgba(255, 255, 255, 0.15)';
        }
      }}
      onMouseLeave={(e) => {
        const target = e.currentTarget;
        target.style.transform = 'translateY(0)';
        if (featured) {
          target.style.boxShadow = '0 8px 20px rgba(247, 148, 29, 0.3)';
        } else {
          target.style.background = 'rgba(255, 255, 255, 0.1)';
        }
      }}
      >
        {getContentText('support-us-button', language === 'en' ? "Support Us" : "Támogass Minket")}
      </button>
    </div>
  );
};

const CampaignSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  
  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, language }),
      });
      
      if (response.ok) {
        setSubscribed(true);
        setEmail('');
      } else {
        const errorData = await response.json();
        console.error('Subscription failed:', errorData.message);
      }
    } catch (error) {
      console.error('Network error:', error);
    }
  };
  
  const rewards = language === 'en' ? [
    {
      title: "Early Bird Access",
      price: "$15",
      benefits: [
        "Get the app before everyone else",
        "3-month premium subscription",
        "Early access to new features"
      ],
      limitText: "Limited to first 100 backers",
      icon: <Zap size={24} />,
      delay: 0.1,
      featured: false
    },
    {
      title: "Premium Supporter",
      price: "$25",
      benefits: [
        "Lifetime access to premium features",
        "Exclusive supporter badge",
        "Monthly language pack updates"
      ],
      limitText: "Only 50 spots available",
      icon: <Crown size={24} />,
      delay: 0.3,
      featured: true
    },
    {
      title: "Language Bundle",
      price: "$40",
      benefits: [
        "Access to all language packs",
        "Lifetime premium subscription",
        "Priority customer support"
      ],
      limitText: "Unlimited availability",
      icon: <Globe size={24} />,
      delay: 0.5,
      featured: false
    }
  ] : [
    {
      title: "Korai Támogató",
      price: "$15",
      benefits: [
        "Kapd meg az appot mindenki előtt",
        "3 hónapos prémium előfizetés",
        "Korai hozzáférés új funkciókhoz"
      ],
      limitText: "Limitált az első 100 támogatóra",
      icon: <Zap size={24} />,
      delay: 0.1,
      featured: false
    },
    {
      title: "Prémium Támogató",
      price: "$25",
      benefits: [
        "Élethosszig tartó prémium funkciók",
        "Exkluzív támogatói jelvény",
        "Havi nyelvcsomag frissítések"
      ],
      limitText: "Csak 50 hely elérhető",
      icon: <Crown size={24} />,
      delay: 0.3,
      featured: true
    },
    {
      title: "Nyelvi Csomag",
      price: "$40",
      benefits: [
        "Hozzáférés minden nyelvcsomaghoz",
        "Élethosszig tartó prémium előfizetés",
        "Elsőbbségi ügyfélszolgálat"
      ],
      limitText: "Korlátlan elérhetőség",
      icon: <Globe size={24} />,
      delay: 0.5,
      featured: false
    }
  ];

  // Key features for the app
  const features = [
    {
      icon: <Zap size={24} />,
      title: "AI-Powered Learning",
      description: "Our AI adapts to your learning style and creates personalized study plans"
    },
    {
      icon: <BookOpen size={24} />,
      title: "Real-Life Contexts",
      description: "Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios"
    }
  ];
  
  // Campaign stats
  const stats = [
    { value: "250+", label: "Backers" },
    { value: "$12,500", label: "Raised" },
    { value: "75%", label: "Funded" }
  ];

  return (
    <section id="campaign" style={{ 
      paddingTop: "120px", 
      paddingBottom: "40px",
      background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
      color: "white",
      minHeight: "80vh"
    }}>
      <div className="container">
        {/* Key Features section */}
        <div style={{ 
          marginBottom: '80px', 
          padding: '40px'
        }}>
          <div style={{ textAlign: "center", marginBottom: "40px" }}>
            <h2 style={{ 
              fontSize: "32px", 
              fontWeight: "bold", 
              marginBottom: "15px"
            }}>{t("Why Choose VOC2GO?")}</h2>
            <p style={{ 
              opacity: "0.8", 
              maxWidth: "600px", 
              margin: "0 auto"
            }}>{t("Discover how our app makes language learning effective and enjoyable")}</p>
          </div>
          
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '30px',
            marginTop: '30px'
          }}>
            {features.map((feature, index) => (
              <div key={index} style={{ 
                display: 'flex',
                alignItems: 'flex-start',
                gap: '20px',
                padding: '25px'
              }}>
                <div style={{
                  color: '#44d1c6',
                  fontSize: '24px'
                }}>
                  {feature.icon}
                </div>
                <div>
                  <h3 style={{ 
                    color: 'white', 
                    fontSize: '20px',
                    marginTop: '0',
                    marginBottom: '10px',
                    fontWeight: '600'
                  }}>{t(feature.title)}</h3>
                  <p style={{ 
                    color: 'rgba(255, 255, 255, 0.8)', 
                    fontSize: '16px',
                    margin: '0',
                    lineHeight: '1.6'
                  }}>
                    {t(feature.description)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>


        
        {/* Call to action */}
        <div style={{
          textAlign: 'center',
          marginBottom: '0px'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '20px',
            flexWrap: 'wrap'
          }}>
            <a href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494" target="_blank" rel="noopener noreferrer" style={{
              background: 'linear-gradient(to right, #F7941D, #e78100)',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '30px',
              padding: '16px 32px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '10px',
              transition: 'all 0.3s ease',
              boxShadow: '0 8px 20px rgba(247, 148, 29, 0.3)'
            }}
            onMouseEnter={(e) => {
              const target = e.currentTarget;
              target.style.transform = 'translateY(-5px)';
              target.style.boxShadow = '0 12px 25px rgba(247, 148, 29, 0.4)';
            }}
            onMouseLeave={(e) => {
              const target = e.currentTarget;
              target.style.transform = 'translateY(0)';
              target.style.boxShadow = '0 8px 20px rgba(247, 148, 29, 0.3)';
            }}
            >
              <Users size={20} />
              {t("Visit Our Indiegogo Page")}
            </a>
            
            <a href="mailto:voc2go@gmail.com?subject=Voc2Go%20Campaign%20Feedback&body=Name:%0A%0AEmail:%0A%0AFeedback:%0A%0A" style={{
              background: 'rgba(255, 255, 255, 0.1)',
              color: 'white',
              textDecoration: 'none',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              borderRadius: '30px',
              padding: '16px 32px',
              fontSize: '18px',
              fontWeight: '600',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '10px',
              transition: 'all 0.3s ease'
            }}
            onMouseEnter={(e) => {
              const target = e.currentTarget;
              target.style.transform = 'translateY(-5px)';
              target.style.background = 'rgba(255, 255, 255, 0.15)';
            }}
            onMouseLeave={(e) => {
              const target = e.currentTarget;
              target.style.transform = 'translateY(0)';
              target.style.background = 'rgba(255, 255, 255, 0.1)';
            }}
            >
              <Star size={20} />
              {language === 'hu' ? "Várjuk a véleményed!" : "Email Us Feedback"}
            </a>
          </div>
        </div>
        

      </div>
    </section>
  );
};

export default CampaignSection;