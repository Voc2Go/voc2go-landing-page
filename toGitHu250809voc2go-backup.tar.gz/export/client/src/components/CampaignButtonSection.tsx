import React, { useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { Mail, CheckCircle } from "lucide-react";

const CampaignButtonSection: React.FC = () => {
  const { language } = useLanguage();
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email, 
          source: "campaign",
          language: language 
        }),
      });
      
      if (response.ok) {
        setIsSubmitted(true);
        setEmail("");
      }
    } catch (error) {
      console.error('Campaign email submission failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-16 px-4" style={{ 
      backgroundColor: "#6a3de8",
      background: "linear-gradient(135deg, rgba(45, 0, 81, 0.97) 0%, rgba(92, 55, 199, 0.97) 100%)",
    }}>
      <div className="max-w-5xl mx-auto text-center">

      </div>
    </section>
  );
};

export default CampaignButtonSection;