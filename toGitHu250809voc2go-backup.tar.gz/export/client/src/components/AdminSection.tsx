import React, { useState } from "react";
import logo from "@assets/JoV2VLogo240815.png";

// Simple admin section that can be shown/hidden
const AdminSection: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (credentials.username === "admin" && credentials.password === "admin123") {
      setIsLoggedIn(true);
      setError("");
    } else {
      setError("Invalid username or password");
    }
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCredentials(prev => ({ ...prev, [name]: value }));
  };
  
  if (isLoggedIn) {
    return (
      <div className="admin-overlay">
        <div className="admin-container">
          <div className="admin-header">
            <img src={logo} alt="VOC2GO" className="admin-logo" />
            <h2>Admin Panel</h2>
            <button className="close-button" onClick={onClose}>×</button>
          </div>
          
          <div className="admin-content">
            <h3>Welcome to the VOC2GO Admin Panel</h3>
            <p>Here you can manage your website content, campaigns, and media.</p>
            
            <div className="admin-stats">
              <div className="stat-card">
                <h4>Subscribers</h4>
                <p className="stat-number">245</p>
              </div>
              <div className="stat-card">
                <h4>Campaign Progress</h4>
                <p className="stat-number">35%</p>
                <div className="progress-bar">
                  <div className="progress" style={{ width: "35%" }}></div>
                </div>
              </div>
              <div className="stat-card">
                <h4>Media Files</h4>
                <p className="stat-number">12</p>
              </div>
            </div>
            
            <div className="admin-actions">
              <button className="admin-button">Manage Content</button>
              <button className="admin-button">View Subscribers</button>
              <button className="admin-button">Campaign Settings</button>
            </div>
            
            <p><small>This is a simplified admin interface. Full functionality would be implemented in a production environment.</small></p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="admin-overlay">
      <div className="admin-login-container">
        <div className="login-header">
          <img src={logo} alt="VOC2GO" className="admin-logo" />
          <h2>Admin Login</h2>
          <button className="close-button" onClick={onClose}>×</button>
        </div>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              value={credentials.username}
              onChange={handleInputChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={credentials.password}
              onChange={handleInputChange}
              required
            />
          </div>
          
          <div className="form-actions">
            <button type="submit" className="login-button">Login</button>
          </div>
        </form>
        
        <div className="login-hint">
          <p><strong>Hint:</strong> Use "admin" / "admin123"</p>
        </div>
      </div>
    </div>
  );
};

export default AdminSection;