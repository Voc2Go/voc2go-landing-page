import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { motion } from "framer-motion";
import cafeImage from "@assets/Screenshot 2025-05-22 at 22.32.44.png";

const VocCampaignPromoSection: React.FC = () => {
  const { language } = useLanguage();

  // Content based on selected language
  const content = {
    en: {
      title: "VOC2GO",
      tagline: "YOUR WORDS, YOUR STYLE, YOUR ENGLISH",
      description: "Let's shape the future of language learning together! Join us and help rethink how the world learns languages! Support our campaign on Indiegogo!",
      buttonText: "Join Our Campaign",
    },
    hu: {
      title: "VOC2GO",
      tagline: "A TE SZAVAID, A TE STÍLUSOD, A TE ANGOLOD",
      description: "Alakítsuk együtt a nyelvtanulás jövőjét! Csatlakozz hozzánk és segíts újragondolni, hogyan tanul a világ nyelveket! Támogasd kampányunkat az Indiegogon!",
      buttonText: "Csatlakozz a kampányunkhoz",
    },
  };

  const currentContent = language === "hu" ? content.hu : content.en;

  return (
    <section
      style={{
        backgroundColor: "#5CD9B7", // Turquoise background
        padding: "50px 20px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div className="container">
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "30px",
          }}
        >
          {/* Left side content */}
          <div
            style={{
              flex: "1",
              minWidth: "300px",
              color: "#333",
            }}
          >
            <h2
              style={{
                fontSize: "42px",
                fontWeight: "bold",
                marginBottom: "10px",
                color: "#333",
              }}
            >
              {currentContent.title}
            </h2>
            <h3
              style={{
                fontSize: "22px",
                fontWeight: "bold",
                marginBottom: "25px",
                color: "#333",
                maxWidth: "450px",
                lineHeight: 1.3,
              }}
            >
              {currentContent.tagline}
            </h3>
            <p
              style={{
                fontSize: "18px",
                marginBottom: "30px",
                color: "#333",
                maxWidth: "450px",
                lineHeight: 1.5,
              }}
            >
              {currentContent.description}
            </p>
            <motion.a
              href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              style={{
                backgroundColor: "#FF7A3C", // Orange button
                color: "white",
                border: "none",
                padding: "14px 30px",
                borderRadius: "30px",
                fontSize: "18px",
                fontWeight: "bold",
                cursor: "pointer",
                boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
                textDecoration: "none",
                display: "inline-block",
                textAlign: "center"
              }}
            >
              {currentContent.buttonText}
            </motion.a>
          </div>

          {/* Right side image */}
          <div
            style={{
              flex: "1",
              minWidth: "300px",
              position: "relative",
            }}
          >
            <div
              style={{
                position: "relative",
                borderRadius: "10px",
                overflow: "hidden",
                boxShadow: "0 10px 30px rgba(0,0,0,0.15)",
              }}
            >
              <img
                src={cafeImage}
                alt="Coffee shop scene"
                style={{
                  width: "100%",
                  height: "auto",
                  display: "block",
                  borderRadius: "10px",
                }}
              />
              
              {/* Purple decorative element */}
              <div
                style={{
                  position: "absolute",
                  bottom: "0",
                  left: "0",
                  width: "30%",
                  height: "60%",
                  background: "linear-gradient(135deg, #673AB7 0%, #9C27B0 100%)",
                  clipPath: "polygon(0 100%, 100% 100%, 100% 0)",
                  zIndex: 1,
                  opacity: 0.7,
                }}
              ></div>
              
              {/* VOC2GO Logo */}
              <div
                style={{
                  position: "absolute",
                  top: "20px",
                  right: "20px",
                  backgroundColor: "#673AB7",
                  color: "white",
                  padding: "5px 10px",
                  borderRadius: "5px",
                  fontWeight: "bold",
                  zIndex: 2,
                }}
              >
                Voc2Go
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VocCampaignPromoSection;