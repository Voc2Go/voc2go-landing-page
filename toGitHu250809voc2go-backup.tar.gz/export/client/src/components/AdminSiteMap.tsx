import React from "react";
import { Map, ArrowDown, Home, Users, Gift, Phone, MessageSquare } from "lucide-react";

const AdminSiteMap: React.FC = () => {
  const siteStructure = [
    {
      section: "🏠 FŐOLDAL (HOME)",
      icon: <Home size={20} />,
      description: "Main landing page content",
      subsections: [
        { name: "Hero Section", location: "Top banner with title and buttons", ids: ["hero-title", "hero-subtitle-1", "hero-subtitle-2"] },
        { name: "About Section", location: "About VOC2GO description", ids: ["about-title", "about-content"] },
        { name: "Why Choose Section", location: "Features and benefits", ids: ["why-choose-title", "features-main"] },
        { name: "Team Section", location: "Team introduction", ids: ["team-title", "team-description", "team-button"] },
        { name: "Testimonials", location: "User feedback and stats", ids: ["testimonials-heading", "testimonial-1-name"] },
        { name: "FAQ Section", location: "Frequently asked questions", ids: ["faq-heading", "faq-question-1"] },
        { name: "Comparison Table", location: "VOC2GO vs competitors", ids: ["comparison-heading", "comparison-feature-1"] },
        { name: "Newsletter", location: "Email subscription form", ids: ["newsletter-title", "newsletter-button"] },
        { name: "Pricing Info", location: "Basic pricing information", ids: ["pricing-heading", "pricing-content"] }
      ]
    },
    {
      section: "👥 TANULÓK (LEARNERS)",
      icon: <Users size={20} />,
      description: "For language learners - personas and pricing",
      subsections: [
        { name: "Who is VOC2GO for?", location: "Four persona cards (Jenci, Natasha, Elisabeth, Lee)", ids: ["who-is-voc2go-for-title", "persona-jenci-title"] },
        { name: "Support Button", location: "After Lee persona: 'Támogass az Indiegogo-n'", ids: ["support-mission-button"] },
        { name: "PAY-AS-YOU-GO BOXES", location: "🔥 4 colored boxes after Indiegogo button", ids: ["pay-as-you-go-title", "pay-flexible-title", "pay-schedule-title", "pay-pace-title"], highlight: true },
        { name: "Plan Comparison", location: "Freemium vs Premium comparison", ids: ["choose-plan-title", "freemium-title", "premium-title"] },
        { name: "Key Questions", location: "Why choose VOC2GO section", ids: ["key-question-1", "our-promise-title"] }
      ]
    },
    {
      section: "🎁 TÁMOGATÓK (SUPPORTERS)",
      icon: <Gift size={20} />,
      description: "Campaign and support information",
      subsections: [
        { name: "Campaign Section", location: "Indiegogo campaign info", ids: ["campaign"] },
        { name: "Development Roadmap", location: "Project timeline", ids: ["roadmap"] },
        { name: "Support Tiers", location: "Contribution levels and rewards", ids: ["support-heading", "support-tier-1-title"] }
      ]
    },
    {
      section: "👨‍💼 PROJEKT (PROJECT)",
      icon: <MessageSquare size={20} />,
      description: "Team and project information",
      subsections: [
        { name: "Team Information", location: "Detailed team descriptions", ids: ["project-team", "team-content"] },
        { name: "Team Member Profiles", location: "Individual team member bios", ids: ["member-1-name", "member-2-name"] },
        { name: "Team Actions", location: "Team-related buttons and CTAs", ids: ["team-button", "meet-team-button"] }
      ]
    },
    {
      section: "📞 KAPCSOLAT (CONTACT)",
      icon: <Phone size={20} />,
      description: "Contact and feedback forms",
      subsections: [
        { name: "Contact Section", location: "Contact form and info", ids: ["contact-title"] },
        { name: "Feedback Section", location: "User feedback form", ids: ["feedback"] }
      ]
    },
    {
      section: "🦶 LÁBLÉC (FOOTER)",
      icon: <ArrowDown size={20} />,
      description: "Footer content at bottom of page",
      subsections: [
        { name: "Footer Information", location: "Bottom page contact info", ids: ["footer", "footer-about"] }
      ]
    }
  ];

  return (
    <div style={{ 
      padding: '20px',
      maxWidth: '1000px',
      margin: '0 auto',
      backgroundColor: '#f8fafc',
      borderRadius: '12px',
      border: '1px solid #e2e8f0'
    }}>
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '12px', 
        marginBottom: '24px',
        padding: '16px',
        background: 'linear-gradient(135deg, #5C37C7, #44d1c6)',
        borderRadius: '8px',
        color: 'white'
      }}>
        <Map size={24} />
        <h2 style={{ margin: 0, fontSize: '20px', fontWeight: '600' }}>
          VOC2GO Website Structure Map
        </h2>
      </div>
      
      <div style={{ 
        backgroundColor: '#fef3c7',
        border: '1px solid #f59e0b',
        borderRadius: '8px',
        padding: '16px',
        marginBottom: '24px'
      }}>
        <h3 style={{ margin: '0 0 8px 0', color: '#92400e', fontSize: '16px' }}>
          🗺️ How to Use This Map:
        </h3>
        <ul style={{ margin: 0, paddingLeft: '20px', color: '#92400e' }}>
          <li><strong>Section Names</strong> = Filter buttons in admin (HOME, LEARNERS, etc.)</li>
          <li><strong>Subsections</strong> = Groups of content you can edit</li>
          <li><strong>Location</strong> = Where it appears on the website</li>
          <li><strong>🔥 Highlighted</strong> = The pricing boxes you were looking for!</li>
        </ul>
      </div>

      <div style={{ display: 'grid', gap: '20px' }}>
        {siteStructure.map((section, index) => (
          <div key={index} style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            border: '1px solid #e2e8f0',
            overflow: 'hidden',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <div style={{
              padding: '16px',
              backgroundColor: '#f1f5f9',
              borderBottom: '1px solid #e2e8f0',
              display: 'flex',
              alignItems: 'center',
              gap: '12px'
            }}>
              {section.icon}
              <div>
                <h3 style={{ margin: '0 0 4px 0', fontSize: '18px', fontWeight: '600' }}>
                  {section.section}
                </h3>
                <p style={{ margin: 0, fontSize: '14px', color: '#64748b' }}>
                  {section.description}
                </p>
              </div>
            </div>
            
            <div style={{ padding: '16px' }}>
              {section.subsections.map((sub, subIndex) => (
                <div key={subIndex} style={{
                  padding: '12px',
                  marginBottom: '12px',
                  backgroundColor: sub.highlight ? '#fef3c7' : '#f8fafc',
                  borderRadius: '8px',
                  border: sub.highlight ? '2px solid #f59e0b' : '1px solid #e2e8f0',
                  position: 'relative'
                }}>
                  {sub.highlight && (
                    <div style={{
                      position: 'absolute',
                      top: '-8px',
                      right: '12px',
                      backgroundColor: '#f59e0b',
                      color: 'white',
                      padding: '4px 8px',
                      borderRadius: '12px',
                      fontSize: '12px',
                      fontWeight: '600'
                    }}>
                      🔥 THIS IS IT!
                    </div>
                  )}
                  <h4 style={{ 
                    margin: '0 0 8px 0', 
                    fontSize: '16px', 
                    fontWeight: '600',
                    color: sub.highlight ? '#92400e' : '#1e293b'
                  }}>
                    {sub.name}
                  </h4>
                  <p style={{ 
                    margin: '0 0 8px 0', 
                    fontSize: '14px', 
                    color: sub.highlight ? '#92400e' : '#64748b',
                    fontStyle: 'italic'
                  }}>
                    📍 {sub.location}
                  </p>
                  <div style={{ 
                    display: 'flex', 
                    flexWrap: 'wrap', 
                    gap: '6px',
                    marginTop: '8px'
                  }}>
                    {sub.ids.map((id, idIndex) => (
                      <code key={idIndex} style={{
                        fontSize: '12px',
                        backgroundColor: sub.highlight ? '#fcd34d' : '#e2e8f0',
                        color: sub.highlight ? '#92400e' : '#374151',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        border: sub.highlight ? '1px solid #f59e0b' : '1px solid #cbd5e1'
                      }}>
                        {id}
                      </code>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div style={{
        marginTop: '24px',
        padding: '16px',
        backgroundColor: '#f0f9ff',
        border: '1px solid #0ea5e9',
        borderRadius: '8px'
      }}>
        <h3 style={{ margin: '0 0 8px 0', color: '#0369a1', fontSize: '16px' }}>
          💡 Quick Navigation Tips:
        </h3>
        <ul style={{ margin: 0, paddingLeft: '20px', color: '#0369a1' }}>
          <li>Use the page filter buttons (HOME, LEARNERS, etc.) to jump to sections</li>
          <li>Look for orange highlighting in Hungarian admin to find missing translations</li>
          <li>The 🔥 highlighted "PAY-AS-YOU-GO BOXES" are what you see after the Lee persona</li>
          <li>Section IDs in gray boxes help you identify exactly what to edit</li>
        </ul>
      </div>
    </div>
  );
};

export default AdminSiteMap;