import React, { useState, useEffect } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Check, Star, Users, BookOpen, Brain, ChevronLeft, ChevronRight } from "lucide-react";
import { useAdaptiveCardSize } from "../hooks/useAdaptiveCardSize";
import "../styles/adaptive-cards.css";

// Vision Card Component
interface VisionCardProps {
  title: string;
  items: string[];
  icon: React.ReactNode;
  bgColor: string;
  borderColor: string;
  delay: number;
  isMarketCard?: boolean;
  isImageCard?: boolean;
  imageUrl?: string;
  imageAlt?: string;
}

const VisionCard: React.FC<VisionCardProps> = ({ title, items, icon, bgColor, borderColor, delay, isMarketCard, isImageCard, imageUrl, imageAlt }) => {
  const { getCardStyle, getTitleStyle, getIconStyle, getContentDensityClass } = useAdaptiveCardSize();
  
  const cardStyle = getCardStyle('vision');
  const titleStyle = getTitleStyle();
  const iconStyle = getIconStyle();
  
  return (
    <div 
      className={`adaptive-card adaptive-card-animate-in ${getContentDensityClass()}`}
      style={{ 
        background: isImageCard && bgColor === "transparent" ? "transparent" : bgColor,
        border: isImageCard && borderColor === "transparent" ? "none" : `1px solid ${borderColor}`,
        backdropFilter: isImageCard && bgColor === "transparent" ? "none" : "blur(10px)",
        animationDelay: `${delay}s`,
        color: "white",
        ...cardStyle
      }}
    >
      <div className="adaptive-card-header">
        <div 
          className="adaptive-card-icon"
          style={{
            background: "rgba(255, 255, 255, 0.1)",
            color: "white",
            ...iconStyle
          }}
        >
          {icon}
        </div>
        
        <h3 
          className="adaptive-card-title"
          style={{ 
            color: "white",
            ...titleStyle
          }}
        >
          {title}
        </h3>
      </div>
      
      <div className="adaptive-card-body">
        {isImageCard && imageUrl ? (
          <div style={{ textAlign: "center", position: "relative", marginBottom: "var(--section-spacing)" }}>
            <img 
              src={imageUrl}
              alt={imageAlt || title}
              style={{ 
                maxWidth: "100%", 
                borderRadius: "8px",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)"
              }} 
            />
          </div>
        ) : isMarketCard ? (
          <div style={{ textAlign: "center", position: "relative", marginBottom: "var(--section-spacing)" }}>
            <img 
              src="/assets/MVP_market.jpg" 
              alt="Global Market Map" 
              style={{ 
                maxWidth: "100%", 
                borderRadius: "8px",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)"
              }} 
            />
          </div>
        ) : null}
        
        {!isImageCard && (
          <ul className="adaptive-card-list">
            {items.map((item, index) => (
              <li key={index} className="adaptive-card-list-item">
                <Check size={18} style={{ 
                  color: "#44d1c6", 
                  flexShrink: 0,
                  marginTop: "2px"
                }} />
                <span style={{ 
                  color: "rgba(255, 255, 255, 0.9)",
                  fontWeight: item.startsWith('**') && item.endsWith('**') ? "bold" : "normal",
                  background: item.startsWith('**') && item.endsWith('**') ? "rgba(68, 209, 198, 0.2)" : "transparent",
                  padding: item.startsWith('**') && item.endsWith('**') ? "4px 8px" : "0",
                  borderRadius: item.startsWith('**') && item.endsWith('**') ? "4px" : "0",
                  border: item.startsWith('**') && item.endsWith('**') ? "1px solid rgba(68, 209, 198, 0.3)" : "none"
                }}>
                  {item.startsWith('**') && item.endsWith('**') ? item.slice(2, -2) : item}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

// Vision Carousel Component
interface VisionCarouselCard {
  title: string;
  items: string[];
  icon: React.ReactNode;
  bgColor: string;
  borderColor: string;
  isMarketCard?: boolean;
  isImageCard?: boolean;
  imageUrl?: string;
  imageAlt?: string;
}

interface VisionCarouselProps {
  cards: VisionCarouselCard[];
}

const VisionCarousel: React.FC<VisionCarouselProps> = ({ cards }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [cardsPerView, setCardsPerView] = useState(3);

  // Responsive cards per view and mobile detection
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    const updateCardsPerView = () => {
      const width = window.innerWidth;
      if (width >= 1200) {
        setCardsPerView(3);
        setIsMobile(false);
      } else if (width >= 768) {
        setCardsPerView(2);
        setIsMobile(false);
      } else {
        setCardsPerView(1);
        setIsMobile(true);
      }
    };

    updateCardsPerView();
    window.addEventListener('resize', updateCardsPerView);
    return () => window.removeEventListener('resize', updateCardsPerView);
  }, []);

  // Auto-rotate carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        const maxIndex = Math.max(0, cards.length - cardsPerView);
        return prev >= maxIndex ? 0 : prev + 1;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [cards.length, cardsPerView]);

  const nextSlide = () => {
    const maxIndex = Math.max(0, cards.length - cardsPerView);
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1));
  };

  const prevSlide = () => {
    const maxIndex = Math.max(0, cards.length - cardsPerView);
    setCurrentIndex((prev) => (prev <= 0 ? maxIndex : prev - 1));
  };

  const goToSlide = (index: number) => {
    const maxIndex = Math.max(0, cards.length - cardsPerView);
    setCurrentIndex(Math.min(index, maxIndex));
  };

  return (
    <div style={{ 
      position: "relative", 
      marginBottom: "60px",
      overflow: "hidden"
    }}>
      {/* Navigation Arrows - positioned over carousel content */}
      <button
        onClick={prevSlide}
        style={{
          position: "absolute",
          left: "20px",
          top: "50%",
          transform: "translateY(-50%)",
          zIndex: 10,
          background: "rgba(0, 0, 0, 0.5)",
          border: "none",
          borderRadius: "6px",
          width: "40px",
          height: "40px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          color: "white",
          backdropFilter: "blur(10px)",
          transition: "all 0.3s ease",
          opacity: 0.8
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.opacity = "1";
          e.currentTarget.style.background = "rgba(0, 0, 0, 0.7)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.opacity = "0.8";
          e.currentTarget.style.background = "rgba(0, 0, 0, 0.5)";
        }}
      >
        <ChevronLeft size={20} />
      </button>

      <button
        onClick={nextSlide}
        style={{
          position: "absolute",
          right: "20px",
          top: "50%",
          transform: "translateY(-50%)",
          zIndex: 10,
          background: "rgba(0, 0, 0, 0.5)",
          border: "none",
          borderRadius: "6px",
          width: "40px",
          height: "40px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          color: "white",
          backdropFilter: "blur(10px)",
          transition: "all 0.3s ease",
          opacity: 0.8
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.opacity = "1";
          e.currentTarget.style.background = "rgba(0, 0, 0, 0.7)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.opacity = "0.8";
          e.currentTarget.style.background = "rgba(0, 0, 0, 0.5)";
        }}
      >
        <ChevronRight size={20} />
      </button>

      {/* Carousel Container */}
      <div style={{
        display: "flex",
        transform: `translateX(-${currentIndex * (100 / cardsPerView)}%)`,
        transition: "transform 0.5s ease",
        gap: "30px"
      }}>
        {cards.map((card, index) => (
          <div
            key={index}
            style={{
              flex: `0 0 calc(${100 / cardsPerView}% - ${(cardsPerView - 1) * 30 / cardsPerView}px)`,
              minHeight: "400px"
            }}
          >
            <VisionCard
              title={card.title}
              items={card.items}
              icon={card.icon}
              bgColor={card.bgColor}
              borderColor={card.borderColor}
              delay={0}
              isMarketCard={card.isMarketCard}
              isImageCard={card.isImageCard}
              imageUrl={card.imageUrl}
              imageAlt={card.imageAlt}
            />
          </div>
        ))}
      </div>

      {/* Carousel Indicators - Hidden on mobile */}
      {!isMobile && (
        <div style={{
          display: "flex",
          justifyContent: "center",
          gap: "10px",
          marginTop: "30px"
        }}>
          {Array.from({ length: Math.max(1, cards.length - cardsPerView + 1) }).map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              style={{
                width: "12px",
                height: "12px",
                borderRadius: "50%",
                border: "none",
                background: index === currentIndex ? "#44d1c6" : "rgba(255, 255, 255, 0.3)",
                cursor: "pointer",
                transition: "all 0.3s ease",
                padding: 0,
                minWidth: "12px",
                minHeight: "12px"
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const VisionSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  
  // Content sections based on language
  const content = {
    en: {
      title: "Reinventing learning vocabulary",
      subtitle: "",
      
      section1: {
        title: "Traditional apps",
        items: [
          "One-size-fits-all lessons",
          "Rote memorization over real understanding",
          "Poor retention",
          "Low speaking confidence"
        ]
      },
      
      section2: {
        title: "Our Solution",
        items: [
          "No pre-made lessons",
          "Learning happens through real AI conversations",
          "Vocabulary is based on your life and goals",
          "Words live inside your stories for deeper memory"
        ]
      },
      
      section3: {
        title: "Why It Works",
        items: [
          "AI That Learns You",
          "Adapts in real-time to your level and interests",
          "Story-Driven Learning – boosts retention and makes it fun",
          "Built on Proven Language Science",
          "From an expert with 20+ years' experience"
        ]
      },
      
      section4: {
        title: "Business Model",
        items: [
          "Free: word discovery + basic practice",
          "Premium: personalized paths, speaking & listening training, smart review",
          "B2B: corporate training & educational licensing"
        ]
      },
      
      section5: {
        title: "Market Opportunity",
        items: [
          "1.5B English learners globally",
          "$60B+ digital language learning market by 2027", 
          "Surging demand for AI-powered personalization"
        ]
      },
      
      section6: {
        title: "Why Invest?",
        items: [
          "Unique position: story-based vocab learning, not found elsewhere",
          "Scalable across languages & markets",
          "Strong early traction and user engagement",
          "Tech meets proven pedagogy"
        ]
      },
      
      tagline: "Voc2Go: Your Words. Your Style. Your English.",
      finalLine: "Join us and make personalized English learning the new global standard."
    },
    
    hu: {
      title: "Újragondoljuk a szókincstanulást",
      subtitle: "",
      
      section1: {
        title: "Hagyományos appok",
        items: [
          "Általános, érdektelen leckék",
          "Magolás értelmes tanulás helyett",
          "Nem maradnak meg a szavak",
          "Kevés beszédgyakorlat"
        ]
      },
      
      section2: {
        title: "A Voc2Go megoldása",
        items: [
          "Nincsenek előre gyártott leckék",
          "A tanulás élő beszélgetésekből születik",
          "Minden szó személyes jelentőségű bír, mert a te szavaid",
          "A szókincs saját történetekbe ágyazva rögzül"
        ]
      },
      
      section3: {
        title: "Miért különleges?",
        items: [
          "MI, ami Téged tanul",
          "Valós időben alkalmazkodik",
          "Történetalapú tanulás, jobban emlékszel és élvezetesebb a tanulás",
          "Tanulástudományi alapokon",
          "20+ év oktatási tapasztalattal fejlesztjük"
        ]
      },
      
      section4: {
        title: "Üzleti modell",
        items: [
          "Ingyenes verzió: alap szókincs és gyakorlás",
          "Prémium: személyre szabott tanulás, beszéd- és hallgatási gyakorlat, játékos ismétlés",
          "**élő nyelvtanulás**"
        ]
      },
      
      section5: {
        title: "Piaci lehetőség",
        items: [
          "1,3 milliárd+ felnőtt potenciális angoltanuló világszerte",
          "$60+ milliárdos piac 2027-re",
          "Egyre nagyobb igény a személyre szabott, MI-alapú tanulásra",
          "**Voc2Go indulási piac: 140 millió francia, 40 millió spanyol és 3 millió magyarul beszélő potenciális felhasználó**"
        ]
      },
      
      section6: {
        title: "Miért éri meg befektetni?",
        items: [
          "Egyedi pozíció: történetalapú szókincstanulás",
          "Skálázható megoldás több nyelvre",
          "Ötvözi az MI-t és a bevált tanítási módszereket",
          "Erős visszajelzések, aktív felhasználói elköteleződés"
        ]
      },
      
      tagline: "Voc2Go: A te szavaid. A te stílusod. A te angolod.",
      finalLine: "Csatlakozz hozzánk, és tedd személyessé a nyelvtanulást világszerte!"
    }
  };
  
  // Select content based on current language
  const currentContent = language === 'en' ? content.en : content.hu;
  
  return (
    <section id="vision" className="py-16 sm:py-20 lg:py-24 text-white relative overflow-hidden" style={{
      background: "linear-gradient(135deg, rgba(45, 0, 81, 0.97) 0%, rgba(92, 55, 199, 0.97) 100%)"
    }}>
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="vision-header text-center mb-12 sm:mb-16 lg:mb-20">
          <div className="mb-4 sm:mb-6">
            <span className="inline-block px-4 py-2 bg-gradient-to-r from-teal-400/20 to-purple-600/20 rounded-full border border-teal-400/30 text-teal-300 text-sm font-medium tracking-wide uppercase">
              {language === 'en' ? "Our Vision" : "Víziónk"}
            </span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 sm:mb-8 leading-tight">
            <span className="block text-center" style={{ color: "#44d1c6" }}>
              {getContentText('vision-title', language === 'en' ? "Reinventing learning vocabulary" : "Újragondoljuk a szókincstanulást")}
            </span>
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <p className="text-lg sm:text-xl lg:text-2xl text-white/90 leading-relaxed font-light">
              {currentContent.subtitle}
            </p>
          </div>
          
          {/* Decorative elements */}
          <div className="flex justify-center items-center gap-4 mt-8 sm:mt-12">
            <div className="w-12 sm:w-16 h-0.5 bg-gradient-to-r from-transparent to-teal-400"></div>
            <div className="w-3 h-3 rounded-full bg-teal-400 animate-pulse"></div>
            <div className="w-12 sm:w-16 h-0.5 bg-gradient-to-l from-transparent to-purple-400"></div>
          </div>
        </div>
        
        {/* Vision Cards Carousel */}
        <VisionCarousel 
          cards={[
            {
              title: getContentText('vision-section1-title', language === 'en' ? "Traditional apps" : "Hagyományos appok"),
              items: [
                getContentText('vision-section1-item1', language === 'en' ? "One-size-fits-all lessons" : "Általános, érdektelen leckék"),
                getContentText('vision-section1-item2', language === 'en' ? "Rote memorization over real understanding" : "Magolás értelmes tanulás helyett"),
                getContentText('vision-section1-item3', language === 'en' ? "Poor retention" : "Nem maradnak meg a szavak"),
                getContentText('vision-section1-item4', language === 'en' ? "Low speaking confidence" : "Kevés beszédgyakorlat")
              ],
              icon: <Star size={30} />,
              bgColor: "rgba(92, 55, 199, 0.15)",
              borderColor: "rgba(92, 55, 199, 0.4)"
            },
            {
              title: getContentText('vision-section2-title', language === 'en' ? "Our Solution" : "A Voc2Go megoldása"),
              items: [
                getContentText('vision-section2-item1', language === 'en' ? "No pre-made lessons" : "Nincsenek előre gyártott leckék"),
                getContentText('vision-section2-item2', language === 'en' ? "Learning happens through real AI conversations" : "A tanulás élő beszélgetésekből születik"),
                getContentText('vision-section2-item3', language === 'en' ? "Vocabulary is based on your life and goals" : "Minden szó személyes jelentőségű bír, mert a te szavaid"),
                getContentText('vision-section2-item4', language === 'en' ? "Words live inside your stories for deeper memory" : "A szókincs saját történetekbe ágyazva rögzül")
              ],
              icon: <BookOpen size={30} />,
              bgColor: "rgba(68, 209, 198, 0.15)",
              borderColor: "rgba(68, 209, 198, 0.4)"
            },
            {
              title: getContentText('vision-section3-title', language === 'en' ? "Why It Works" : "Miért különleges?"),
              items: [
                getContentText('vision-section3-item1', language === 'en' ? "AI That Learns You" : "MI, ami Téged tanul"),
                getContentText('vision-section3-item2', language === 'en' ? "Adapts in real-time to your level and interests" : "Real időben alkalmazkodik szintedhez és érdeklődésedhez"),
                getContentText('vision-section3-item3', language === 'en' ? "Story-Driven Learning – boosts retention and makes it fun" : "Történetalapú tanulás – jobb megjegyzés és szórakozás"),
                getContentText('vision-section3-item4', language === 'en' ? "Built on Proven Language Science" : "Bevált nyelvtudományon alapul"),
                getContentText('vision-section3-item5', language === 'en' ? "From an expert with 20+ years' experience" : "20+ éves szakmai tapasztalat")
              ],
              icon: <Brain size={30} />,
              bgColor: "rgba(255, 117, 24, 0.15)",
              borderColor: "rgba(255, 117, 24, 0.4)"
            },
            {
              title: getContentText('vision-section4-title', language === 'en' ? "Business Model" : "Üzleti modell"),
              items: [
                getContentText('vision-section4-item1', language === 'en' ? "Free: word discovery + basic practice" : "Ingyenes verzió: alap szókincs és gyakorlás"),
                getContentText('vision-section4-item2', language === 'en' ? "Premium: personalized paths, speaking & listening training, smart review" : "Prémium: személyre szabott tanulás, beszéd- és hallgatási gyakorlat, játékos ismétlés"),
                getContentText('vision-section4-item3', language === 'en' ? "B2B: corporate training & educational licensing" : "**élő nyelvtanulás**")
              ],
              icon: <Star size={30} />,
              bgColor: "rgba(92, 55, 199, 0.15)",
              borderColor: "rgba(92, 55, 199, 0.4)"
            },
            {
              title: getContentText('vision-section5-title', language === 'en' ? "Market Opportunity" : "Piaci lehetőség"), 
              items: [
                getContentText('vision-section5-item1', language === 'en' ? "1.5B English learners globally" : "1,3 milliárd+ felnőtt potenciális angoltanuló világszerte"),
                getContentText('vision-section5-item2', language === 'en' ? "$60B+ digital language learning market by 2027" : "$60+ milliárdos piac 2027-re"),
                getContentText('vision-section5-item3', language === 'en' ? "Surging demand for AI-powered personalization" : "Egyre nagyobb igény a személyre szabott, MI-alapú tanulásra"),
                getContentText('vision-section5-item4', language === 'en' ? "" : "**Voc2Go indulási piac: 140 millió francia, 40 millió spanyol és 3 millió magyarul beszélő potenciális felhasználó**")
              ],
              icon: <Users size={30} />,
              bgColor: "rgba(68, 209, 198, 0.15)",
              borderColor: "rgba(68, 209, 198, 0.4)",
              isMarketCard: true
            },
            {
              title: getContentText('vision-section6-title', language === 'en' ? "Why Invest?" : "Miért éri meg befektetni?"),
              items: [
                getContentText('vision-section6-item1', language === 'en' ? "Unique position: story-based vocab learning, not found elsewhere" : "Egyedi pozíció: történetalapú szókincstanulás"),
                getContentText('vision-section6-item2', language === 'en' ? "Scalable across languages & markets" : "Skálázható megoldás több nyelvre"),
                getContentText('vision-section6-item3', language === 'en' ? "Strong early traction and user engagement" : "Erős visszajelzések, aktív felhasználói elköteleződés"),
                getContentText('vision-section6-item4', language === 'en' ? "Tech meets proven pedagogy" : "Ötvözi az MI-t és a bevált tanítási módszereket")
              ],
              icon: <Star size={30} />,
              bgColor: "rgba(255, 117, 24, 0.15)",
              borderColor: "rgba(255, 117, 24, 0.4)"
            },
            {
              title: getContentText('vision-app-preview-title', language === 'en' ? "See Voc2Go in Action" : "Nézd meg a Voc2Go-t működés közben"),
              items: [],
              icon: <BookOpen size={30} />,
              bgColor: "rgba(68, 209, 198, 0.15)",
              borderColor: "rgba(68, 209, 198, 0.4)",
              isImageCard: true,
              imageUrl: "/ProjectGalery2_1280x96_1754547257628.jpg",
              imageAlt: language === 'en' ? "Voc2Go App Preview" : "Voc2Go Alkalmazás Előnézet"
            },
            {
              title: getContentText('vision-mobile-app-title', language === 'en' ? "Mobile Learning Experience" : "Mobil Tanulási Élmény"),
              items: [],
              icon: <BookOpen size={30} />,
              bgColor: "transparent",
              borderColor: "transparent",
              isImageCard: true,
              imageUrl: "/attached_assets/kéz2_1754554020603.png",
              imageAlt: language === 'en' ? "Voc2Go Mobile App Interface" : "Voc2Go Mobil Alkalmazás Felület"
            }
          ]}
        />
        
        {/* Indiegogo Campaign Button */}
        <div className="text-center mt-12 sm:mt-16 lg:mt-20 relative z-30">
          <a 
            href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-5 rounded-full font-bold text-sm sm:text-base lg:text-lg xl:text-xl uppercase tracking-wider border-2 border-white/20 shadow-2xl transition-all duration-300 hover:scale-105 hover:shadow-3xl no-underline"
            style={{
              boxShadow: '0 8px 32px rgba(235, 20, 120, 0.4)',
              textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span className="relative z-10">
              {getContentText('indiegogo-button', language === 'en' ? "Support on Indiegogo" : "Támogass az Indiegogo-n")}
            </span>
          </a>
        </div>
      </div>
      
      {/* Background decorations */}
      <div className="absolute w-96 h-96 sm:w-[500px] sm:h-[500px] lg:w-[600px] lg:h-[600px] rounded-full opacity-60 -top-32 sm:-top-48 lg:-top-52 -right-32 sm:-right-48 lg:-right-52 z-0" 
           style={{
             background: "radial-gradient(circle, rgba(68, 209, 198, 0.15) 0%, rgba(68, 209, 198, 0) 70%)"
           }}>
      </div>
      
      <div className="absolute w-80 h-80 sm:w-96 sm:h-96 lg:w-[500px] lg:h-[500px] rounded-full opacity-60 -bottom-24 sm:-bottom-32 lg:-bottom-36 -left-24 sm:-left-32 lg:-left-36 z-0"
           style={{
             background: "radial-gradient(circle, rgba(92, 55, 199, 0.15) 0%, rgba(92, 55, 199, 0) 70%)"
           }}>
      </div>
      
      {/* Additional floating particles */}
      <div className="absolute top-20 left-1/4 w-2 h-2 bg-teal-400/40 rounded-full animate-pulse"></div>
      <div className="absolute top-40 right-1/3 w-1 h-1 bg-purple-400/60 rounded-full animate-pulse delay-1000"></div>
      <div className="absolute bottom-32 left-1/3 w-1.5 h-1.5 bg-white/30 rounded-full animate-pulse delay-500"></div>
    </section>
  );
};

export default VisionSection;