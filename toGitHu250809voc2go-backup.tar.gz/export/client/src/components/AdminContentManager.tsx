import React, { useState, useEffect } from 'react';
import { Edit3, Save, X, RefreshCw } from 'lucide-react';
import TeamSocialMediaManager from './TeamSocialMediaManager';

interface ContentSection {
  id: number;
  sectionId: string;
  title: string;
  content: string;
  language: string;
  modifiedBy: string;
  lastModified: Date;
}

interface AdminContentManagerProps {
  currentLanguage: 'en' | 'hu';
  onLanguageChange: (language: 'en' | 'hu') => void;
}

const AdminContentManager: React.FC<AdminContentManagerProps> = ({ currentLanguage, onLanguageChange }) => {
  const [contentSections, setContentSections] = useState<ContentSection[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [editData, setEditData] = useState<{ title: string; content: string }>({ title: '', content: '' });
  const [refreshKey, setRefreshKey] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPage, setSelectedPage] = useState<string>('all');

  // Color coding for different sections with language-specific backgrounds
  const getSectionColor = (sectionId: string, language: string) => {
    const baseColors = {
      'hero': '#FF6B6B',
      'about': '#4ECDC4', 
      'features': '#45B7D1',
      'why-choose': '#96CEB4',
      'team': '#FFEAA7',
      'testimonials': '#DDA0DD',
      'faq': '#98D8C8',
      'pricing': '#F7DC6F',
      'learners': '#BB8FCE',
      'vision': '#85C1E9',
      'campaign': '#F8C471',
      'roadmap': '#82E0AA',
      'support': '#F1948A',
      'project': '#AED6F1',
      'contact': '#D7BDE2',
      'feedback': '#A9DFBF',
      'footer': '#FADBD8',
      'newsletter': '#D5E8D4'
    };
    
    // Find base color from section ID
    const baseColor = Object.keys(baseColors).find(key => sectionId.includes(key)) || 'default';
    const color = (baseColors as Record<string, string>)[baseColor] || '#6C757D';
    
    // Language-specific background styling - clearer and more distinct
    if (language === 'hu') {
      // Hungarian content gets darker, more visible background
      return {
        backgroundColor: '#fef3c7', // Light amber background
        border: `3px solid #f59e0b`, // Amber border
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(245, 158, 11, 0.2)'
      };
    } else {
      // English content gets light blue background
      return {
        backgroundColor: '#eff6ff', // Light blue background
        border: `2px solid #3b82f6`, // Blue border
        borderRadius: '6px',
        boxShadow: '0 1px 3px rgba(59, 130, 246, 0.1)'
      };
    }
  };

  // Page categories for filtering with bilingual support
  const pageCategories = {
    'all': currentLanguage === 'hu' ? 'Minden oldal' : 'All Pages',
    'home': currentLanguage === 'hu' ? 'FŐOLDAL' : 'HOME',
    'learners': currentLanguage === 'hu' ? 'TANULÓK' : 'LEARNERS',
    'supporters': currentLanguage === 'hu' ? 'TÁMOGATÓK' : 'SUPPORTERS',
    'project': currentLanguage === 'hu' ? 'PROJEKT' : 'PROJECT',
    'contact': currentLanguage === 'hu' ? 'KAPCSOLAT' : 'CONTACT',
    'missing-hungarian': '🚨 Missing Hungarian',
    'needs-attention': '⚠️ Needs Attention'
  };

  // Map section IDs to page categories
  const getSectionPage = (sectionId: string): string => {
    const sectionPageMap: Record<string, string> = {
      // HOME page sections
      'hero': 'home',
      'hero-title': 'home',
      'hero-subtitle': 'home',
      'hero-main-subtitle': 'home',
      'hero-heading': 'home',
      'about': 'home',
      'about-content': 'home',
      'about-title': 'home',
      'about-description': 'home',
      'features': 'home',
      'features-main': 'home',
      'why-choose': 'home',
      'why-choose-title': 'home',
      'why-choose-heading': 'home',
      'why-choose-description': 'home',
      'team': 'home',
      'team-title': 'home',
      'team-description': 'home',
      'team-button': 'home',
      'testimonials': 'home',
      'testimonials-heading': 'home',
      'testimonials-description': 'home',
      'testimonial-1': 'home',
      'testimonial-2': 'home',
      'testimonial-3': 'home',
      'faq': 'home',
      'faq-title': 'home',
      'faq-heading': 'home',
      'faq-description': 'home',
      'faq-question': 'home',
      'faq-answer': 'home',
      'footer': 'home',
      'coming-soon-badge': 'home',
      'scroll-to-explore': 'home',
      'support-campaign-button': 'home',
      'meet-team-button': 'home',
      
      // LEARNERS page sections
      'learners': 'learners',
      'learners-title': 'learners',
      'learners-benefits': 'learners',
      'learners-testimonials': 'learners',
      'personas': 'learners',
      'persona-': 'learners', // Catches all persona- prefixed sections
      'pay-as-you-go': 'learners',
      'plan-comparison': 'learners',

      'voc-future': 'learners',
      'pricing': 'learners',
      'pricing-title': 'learners',
      'pricing-content': 'learners',
      'who-is-voc2go-for-title': 'learners',
      'who-is-voc2go-for-description': 'learners',
      'contextual-learning': 'learners',
      'ai-learning': 'learners',
      'feature-context': 'learners',

      
      // SUPPORTERS page sections
      'vision': 'supporters',
      'vision-section': 'supporters',
      'campaign': 'supporters',
      'campaign-section': 'supporters',
      'roadmap': 'supporters',
      'support': 'supporters',
      'support-section': 'supporters',
      'countdown': 'supporters',
      'comparison': 'supporters',
      
      // PROJECT page sections
      'project': 'project',
      'project-team': 'project',
      'team-member-': 'project', // Catches all team-member- prefixed sections
      
      // CONTACT page sections
      'contact': 'contact',
      'feedback': 'contact',
      'feedback-section': 'contact',
      
      // Newsletter sections (appear on all pages)
      'newsletter': 'home', // Default to home, but actually shared across all pages
      'newsletter-title': 'home',
      'newsletter-description': 'home', 
      'newsletter-heading': 'home',
      'newsletter-success': 'home',
      'newsletter-thanks': 'home',
      'newsletter-placeholder': 'home',
      'newsletter-button': 'home',
      'newsletter-subscribed': 'home'
    };
    
    // Direct match first
    if (sectionPageMap[sectionId]) {
      return sectionPageMap[sectionId];
    }
    
    // Then check for partial matches (for prefixed sections)
    for (const [key, page] of Object.entries(sectionPageMap)) {
      if (key.endsWith('-') && sectionId.startsWith(key)) {
        return page;
      } else if (sectionId.toLowerCase().includes(key)) {
        return page;
      }
    }
    
    return 'home'; // Default to home if no match found
  };

  // Get status indicator for missing translations
  const getTranslationStatus = (sectionId: string, language: string) => {
    const allSections = contentSections.filter(s => s.sectionId === sectionId);
    const hasEn = allSections.some(s => s.language === 'en' && ((s.content && s.content.trim() !== '') || (s.title && s.title.trim() !== '')));
    const hasHu = allSections.some(s => s.language === 'hu' && ((s.content && s.content.trim() !== '') || (s.title && s.title.trim() !== '')));
    
    if (hasEn && hasHu) {
      return { status: 'complete', label: '✅ Both languages' };
    } else if (language === 'hu' && !hasHu && hasEn) {
      return { status: 'missing', label: '🚨 Missing Hungarian' };
    } else if (language === 'en' && !hasEn && hasHu) {
      return { status: 'missing', label: '🚨 Missing English' };
    } else {
      return { status: 'partial', label: '⚠️ Needs translation' };
    }
  };

  // Website structure organized by menu pages
  const siteStructure = {
    'HOME': {
      'Főoldal Hero (HeroSection.tsx)': [
        { id: 'hero-title', label: 'Main Title', placeholder: 'LEARN ENGLISH' },
        { id: 'hero-subtitle-1', label: 'Subtitle 1', placeholder: 'WORD BY WORD' },
        { id: 'hero-subtitle-2', label: 'Subtitle 2', placeholder: 'STORY BY STORY' },
        { id: 'hero-heading', label: 'Screen Reader Heading', placeholder: 'VOC2GO: AI-Powered Language Learning' },
        { id: 'hero-main-subtitle', label: 'Main Description', placeholder: 'Personalized, Story-Based Learning — Powered by AI & You...' },
        { id: 'hero-subtitle', label: 'Legacy Description', placeholder: 'Build vocabulary through engaging stories...' },
        { id: 'support-campaign-button', label: 'Campaign Button', placeholder: 'Support Our Campaign Now' },
        { id: 'meet-team-button', label: 'Team Button', placeholder: 'Meet Our Expert Team' },
        { id: 'coming-soon-badge', label: 'Coming Soon Badge', placeholder: 'Coming Soon!' },
        { id: 'scroll-to-explore', label: 'Scroll Text', placeholder: 'Scroll to explore' }
      ],
      'Rólunk (AboutSection.tsx)': [
        { id: 'about-title', label: 'About Title', placeholder: 'Revolutionizing language learning through innovation' },
        { id: 'about-content', label: 'About Content', placeholder: 'VOC2GO combines cutting-edge AI technology...' }
      ],
      'Miért válaszd (WhyChooseSection.tsx)': [
        { id: 'why-choose-title', label: 'Section Title', placeholder: 'Why Choose Voc2Go?' },
        { id: 'features-main', label: 'Main Features Text', placeholder: 'Experience the future of language education...' }
      ],
      'Csapat (TeamSection.tsx)': [
        { id: 'team-title', label: 'Team Title', placeholder: 'Built by Language Learning Experts' },
        { id: 'team-description', label: 'Team Description', placeholder: 'Our passionate team brings decades of experience in education, AI, and language learning to create VOC2GO.' },
        { id: 'team-button', label: 'Team Button', placeholder: 'Meet Our Expert Team' }
      ],
      'Visszajelzések (TestimonialsSection.tsx)': [
        { id: 'testimonials-heading', label: 'Testimonials Heading', placeholder: 'What Early Users Say' },
        { id: 'testimonials-description', label: 'Testimonials Description', placeholder: 'Real feedback from beta testers, language researchers, and early adopters...' },
        { id: 'testimonials-stat1-number', label: 'Stat 1 Number', placeholder: '94%' },
        { id: 'testimonials-stat1-label', label: 'Stat 1 Label', placeholder: 'User Satisfaction' },
        { id: 'testimonials-stat2-number', label: 'Stat 2 Number', placeholder: '3x' },
        { id: 'testimonials-stat2-label', label: 'Stat 2 Label', placeholder: 'Faster Learning' },
        { id: 'testimonials-stat3-number', label: 'Stat 3 Number', placeholder: '85%' },
        { id: 'testimonials-stat3-label', label: 'Stat 3 Label', placeholder: 'Retention Rate' },
        { id: 'testimonials-stat4-number', label: 'Stat 4 Number', placeholder: '500+' },
        { id: 'testimonials-stat4-label', label: 'Stat 4 Label', placeholder: 'Beta Testers' },
        { id: 'testimonials-cta-title', label: 'CTA Section Title', placeholder: 'Join 500+ Early Supporters' },
        { id: 'testimonials-cta-description', label: 'CTA Description', placeholder: 'Be part of the language learning revolution...' },
        { id: 'testimonials-cta-button', label: 'CTA Button', placeholder: 'Secure Your Spot Now' },
        { id: 'testimonial-1-name', label: 'Testimonial 1 Name', placeholder: 'Sarah Johnson' },
        { id: 'testimonial-1-role', label: 'Testimonial 1 Role', placeholder: 'English Teacher' },
        { id: 'testimonial-1-text', label: 'Testimonial 1 Text', placeholder: 'VOC2GO has transformed how I teach vocabulary...' },
        { id: 'testimonial-1-improvement', label: 'Testimonial 1 Improvement', placeholder: '40% better retention' },
        { id: 'testimonial-2-name', label: 'Testimonial 2 Name', placeholder: 'Michael Chen' },
        { id: 'testimonial-2-role', label: 'Testimonial 2 Role', placeholder: 'Business Professional' },
        { id: 'testimonial-2-text', label: 'Testimonial 2 Text', placeholder: 'The AI-powered conversations feel natural...' },
        { id: 'testimonial-2-improvement', label: 'Testimonial 2 Improvement', placeholder: 'Confident in meetings' },
        { id: 'testimonial-3-name', label: 'Testimonial 3 Name', placeholder: 'Anna Kovács' },
        { id: 'testimonial-3-role', label: 'Testimonial 3 Role', placeholder: 'University Student' },
        { id: 'testimonial-3-text', label: 'Testimonial 3 Text', placeholder: 'Finally, an app that understands my learning style...' },
        { id: 'testimonial-3-improvement', label: 'Testimonial 3 Improvement', placeholder: '2x faster learning' }
      ],
      'Gyakran Ismételt Kérdések (FAQSection.tsx)': [
        { id: 'faq-heading', label: 'FAQ Heading', placeholder: 'Frequently Asked Questions' },
        { id: 'faq-description', label: 'FAQ Description', placeholder: 'Everything you need to know about VOC2GO and our crowdfunding campaign.' },
        { id: 'faq-question-1', label: 'FAQ Question 1', placeholder: 'How is VOC2GO different from other language learning apps?' },
        { id: 'faq-answer-1', label: 'FAQ Answer 1', placeholder: 'VOC2GO uses AI to create personalized conversations...' },
        { id: 'faq-question-2', label: 'FAQ Question 2', placeholder: 'How does the hour-based access model work?' },
        { id: 'faq-answer-2', label: 'FAQ Answer 2', placeholder: 'You pay for a specific number of premium access hours...' },
        { id: 'faq-question-3', label: 'FAQ Question 3', placeholder: 'When will the app be available?' },
        { id: 'faq-answer-3', label: 'FAQ Answer 3', placeholder: 'We plan to launch the MVP (beta version) within 6 months...' },
        { id: 'faq-question-4', label: 'FAQ Question 4', placeholder: 'What devices will VOC2GO support?' },
        { id: 'faq-answer-4', label: 'FAQ Answer 4', placeholder: 'VOC2GO will be available on iOS and Android smartphones...' },
        { id: 'faq-question-5', label: 'FAQ Question 5', placeholder: 'Is there a refund policy?' },
        { id: 'faq-answer-5', label: 'FAQ Answer 5', placeholder: 'As stated in our campaign terms, all contributions are final...' },
        { id: 'faq-question-6', label: 'FAQ Question 6', placeholder: 'How much content will be available at launch?' },
        { id: 'faq-answer-6', label: 'FAQ Answer 6', placeholder: 'The MVP will include 5,000+ vocabulary words...' },
        { id: 'faq-question-7', label: 'FAQ Question 7', placeholder: 'Can I use VOC2GO offline?' },
        { id: 'faq-answer-7', label: 'FAQ Answer 7', placeholder: 'Yes! While the AI conversation features require internet connectivity...' }
      ],
      'Összehasonlítás (ComparisonSection.tsx)': [
        { id: 'comparison-heading', label: 'Comparison Heading', placeholder: 'Why VOC2GO Beats the Competition' },
        { id: 'comparison-description', label: 'Comparison Description', placeholder: 'See how VOC2GO\'s innovative AI-powered approach compares...' },
        { id: 'comparison-features-header', label: 'Features Header', placeholder: 'Features' },
        { id: 'comparison-platform-1-name', label: 'Platform 1 Name', placeholder: 'VOC2GO' },
        { id: 'comparison-platform-1-price', label: 'Platform 1 Price', placeholder: 'Pay-per-use' },
        { id: 'comparison-platform-1-desc', label: 'Platform 1 Description', placeholder: 'AI-Powered Personal Stories' },
        { id: 'comparison-platform-2-name', label: 'Platform 2 Name', placeholder: 'Traditional Methods' },
        { id: 'comparison-platform-2-price', label: 'Platform 2 Price', placeholder: 'High Cost/Monthly' },
        { id: 'comparison-platform-2-desc', label: 'Platform 2 Description', placeholder: 'Classroom/Books/Apps' },
        { id: 'comparison-feature-1', label: 'Feature 1', placeholder: 'AI-Powered Personalization' },
        { id: 'comparison-feature-2', label: 'Feature 2', placeholder: 'Story-Based Learning' },
        { id: 'comparison-feature-3', label: 'Feature 3', placeholder: 'Real-Time Conversation Practice' },
        { id: 'comparison-feature-4', label: 'Feature 4', placeholder: 'Personalized Vocabulary' },
        { id: 'comparison-feature-5', label: 'Feature 5', placeholder: 'Learning Science Foundation' },
        { id: 'comparison-feature-6', label: 'Feature 6', placeholder: 'Mobile App' },
        { id: 'comparison-feature-7', label: 'Feature 7', placeholder: 'Expert-Led Development' },
        { id: 'comparison-feature-8', label: 'Feature 8', placeholder: 'Learns Your Interests' },
        { id: 'comparison-feature-9', label: 'Feature 9', placeholder: '85%+ Retention Rate' },
        { id: 'comparison-feature-10', label: 'Feature 10', placeholder: 'No Generic Lessons' }
      ],
      'Árazás (PricingSection.tsx)': [
        { id: 'pricing-heading', label: 'Pricing Heading', placeholder: 'Choose Your Plan' },
        { id: 'pricing-title', label: 'Pricing Description', placeholder: 'Pay-per-use model that fits your schedule' },
        { id: 'pricing-content', label: 'Pricing Content', placeholder: 'No subscriptions, no commitments...' }
      ],
      'Hírlevél (NewsletterSection.tsx)': [
        { id: 'newsletter-title', label: 'Newsletter Title', placeholder: 'Stay Updated' },
        { id: 'newsletter-description', label: 'Newsletter Description', placeholder: 'Subscribe to our newsletter for campaign updates' },
        { id: 'newsletter-heading', label: 'Newsletter Heading', placeholder: 'Stay Updated' },
        { id: 'newsletter-success', label: 'Success Message', placeholder: 'Thanks for subscribing!' },
        { id: 'newsletter-thanks', label: 'Thanks Message', placeholder: 'Thanks for subscribing!' },
        { id: 'newsletter-placeholder', label: 'Email Placeholder', placeholder: 'Enter your email' },
        { id: 'newsletter-button', label: 'Subscribe Button', placeholder: 'Subscribe' },
        { id: 'newsletter-subscribed', label: 'Subscribed Text', placeholder: 'Subscribed!' }
      ]
    },
    'LEARNERS': {
      'Tanulók oldal (LearnersSection.tsx)': [
        { id: 'learners', label: 'Learners Title', placeholder: 'For Language Learners' },
        { id: 'learners-benefits', label: 'Benefits Title', placeholder: 'Benefits for Learners' },
        { id: 'learners-testimonials', label: 'Testimonials Title', placeholder: 'What Our Users Say' }
      ],
      'Fizess amennyit használsz (PayAsYouGoSection.tsx)': [
        { id: 'pay-as-you-go-title', label: 'Pay As You Go Title', placeholder: 'Pay as you go / Csak annyit fizetsz, amennyit tanulsz' },
        { id: 'pay-as-you-go-subtitle', label: 'Pay As You Go Subtitle', placeholder: 'No subscription / nincs előfizetés!' },
        { id: 'pay-flexible-title', label: 'Flexible Title', placeholder: 'FLEXIBLE / RUGALMAS' },
        { id: 'pay-flexible-desc', label: 'Flexible Description', placeholder: 'No commitments. Just learn! / Nincs elköteleződés, nincs kötöttség. Akkor tanulsz, amikor neked megfelel!' },
        { id: 'pay-schedule-title', label: 'Schedule Title', placeholder: 'SUITS YOUR SCHEDULE / IGAZODIK AZ IDŐ BEOSZTÁSODHOZ' },
        { id: 'pay-schedule-desc', label: 'Schedule Description', placeholder: 'Perfect for budget-conscious learners, Voc2Go adapts to your schedule and budget. / A Voc2Go rugalmasan alkalmazkodik az életedhez és a költségvetésedhez.' },
        { id: 'pay-pace-title', label: 'Pace Title', placeholder: 'LEARN AT YOUR PACE / A SAJÁT TEMPÓDBAN TANULSZ' },
        { id: 'pay-pace-desc', label: 'Pace Description', placeholder: 'Learn at your own pace, pay as you go, and watch your English skills soar! / Haladj a saját ritmusodban, fizess csak az elvégzett leckékért, és élvezd, ahogy egyre magabiztosabban beszélsz angolul.' }
      ],
      'Kinek való (PersonasSection.tsx)': [
        { id: 'who-is-voc2go-for-title', label: 'Section Title', placeholder: 'Who is Voc2Go for? / Kinek való a Voc2Go?' },
        { id: 'who-is-voc2go-for-description', label: 'Section Description', placeholder: 'Meet our learners - discover how Voc2Go helps people like you...' },
        { id: 'persona-jenci-title', label: 'Jenci - Job Title', placeholder: '3D programmer / 3D programozó' },
        { id: 'persona-jenci-desc', label: 'Jenci - Description', placeholder: 'Wants to work internationally but needs stronger English skills...' },
        { id: 'persona-natasha-title', label: 'Natasha - Job Title', placeholder: 'Legal professional / Jogi szakember' },
        { id: 'persona-natasha-desc', label: 'Natasha - Description', placeholder: 'Excels in legal writing but struggles with English speaking confidence...' },
        { id: 'persona-elisabeth-title', label: 'Elisabeth - Job Title', placeholder: 'Creative designer / Kreatív tervező' },
        { id: 'persona-elisabeth-desc', label: 'Elisabeth - Description', placeholder: 'Feels frustrated when she forgets English vocabulary mid-conversation...' },
        { id: 'persona-lee-title', label: 'Lee - Job Title', placeholder: 'Hospitality worker / Vendéglátásban dolgozik' },
        { id: 'persona-lee-desc', label: 'Lee - Description', placeholder: 'Has basic English but needs an advanced English level for university...' }
      ],
      'Jövőkép (VisionSection.tsx)': [
        { id: 'vision', label: 'Vision Statement', placeholder: 'Reinventing English Learning with AI + User Vocabulary' }
      ],
      'Válaszd a csomagod (PlanComparisonSection.tsx)': [
        { id: 'choose-plan-title', label: 'Choose Plan Title', placeholder: 'Choose Your Plan' },
        { id: 'choose-plan-subtitle', label: 'Choose Plan Subtitle', placeholder: 'Compare our options and find the best fit for your learning journey' },
        { id: 'freemium-title', label: 'Freemium Title', placeholder: 'FREEMIUM' },
        { id: 'freemium-subtitle', label: 'Freemium Subtitle', placeholder: 'Vic tracks your progress and brings up past words to practice' },
        { id: 'freemium-feature-1', label: 'Freemium Feature 1', placeholder: 'DISCOVER NEW WORDS' },
        { id: 'freemium-feature-2', label: 'Freemium Feature 2', placeholder: 'BUILD YOUR WORD BANK' },
        { id: 'freemium-feature-3', label: 'Freemium Feature 3', placeholder: 'GET PRACTICE SESSIONS' },
        { id: 'freemium-feature-4', label: 'Freemium Feature 4', placeholder: 'GET YOUR MEMORY CARD' },
        { id: 'premium-title', label: 'Premium Title', placeholder: 'PREMIUM' },
        { id: 'premium-subtitle', label: 'Premium Subtitle', placeholder: 'Every word you learn is connected to your life' },
        { id: 'premium-feature-1', label: 'Premium Feature 1', placeholder: 'NEW LESSON BUILDS ON WHAT YOU ALREADY LEARNED' },
        { id: 'premium-feature-2', label: 'Premium Feature 2', placeholder: 'YOUR CONVERSATIONS GROW INTO RICHER STORIES' },
        { id: 'premium-feature-3', label: 'Premium Feature 3', placeholder: 'ÉLŐ NYELVTANULÁS' },
        { id: 'premium-feature-4', label: 'Premium Feature 4', placeholder: 'MASTER TRICKY WORDS AND SYNONYMS' },
        { id: 'premium-feature-5', label: 'Premium Feature 5', placeholder: 'CONVERSATION PRACTICE WITH VIC\'S TIPS' },
        { id: 'premium-feature-6', label: 'Premium Feature 6', placeholder: 'AUDIO LESSONS FOR BUSY DAYS' },
        { id: 'plan-recommended-text', label: 'Recommended Text', placeholder: 'RECOMMENDED' },
        { id: 'plan-free-text', label: 'Free Text', placeholder: 'FREE' },
        { id: 'plan-upgrade-text', label: 'Upgrade Text', placeholder: 'UPGRADE NOW' }
      ],
      'Miért választd (WhyChooseSection.tsx)': [
        { id: 'why-choose-title', label: 'Why Choose Title', placeholder: 'Why Choose Voc2Go?' },
        { id: 'why-choose-description', label: 'Why Choose Description', placeholder: 'Voc2Go is built on real stories...' },
        { id: 'key-question-1', label: 'Key Question 1', placeholder: 'Is it easy to use?' },
        { id: 'key-question-2', label: 'Key Question 2', placeholder: 'Do I remember what I learn?' },
        { id: 'key-question-3', label: 'Key Question 3', placeholder: 'Are all my senses involved?' },
        { id: 'key-question-4', label: 'Key Question 4', placeholder: 'Is this relevant to me?' },
        { id: 'key-question-5', label: 'Key Question 5', placeholder: 'Will this make me curious?' },
        { id: 'voc2go-answers', label: 'Voc2Go Answers', placeholder: 'Voc2Go answers these with interactive AI...' },
        { id: 'our-promise-title', label: 'Our Promise Title', placeholder: 'Our Promise' },
        { id: 'our-promise-description', label: 'Our Promise Description', placeholder: 'With Voc2Go, you don\'t just learn...' },
        { id: 'support-mission-button', label: 'Support Mission Button', placeholder: 'Support Our Mission' }
      ]
    },
    'SUPPORTERS': {
      'Kampány (CampaignSection.tsx)': [
        { id: 'campaign', label: 'Campaign Title', placeholder: 'Join Our Indiegogo Campaign' }
      ],
      'Fejlesztési (RoadmapSection.tsx)': [
        { id: 'roadmap', label: 'Roadmap Title', placeholder: 'Development Roadmap' }
      ],
      'Támogatás (SupportSection.tsx)': [
        { id: 'support-heading', label: 'Support Section Heading', placeholder: 'Support Voc2Go\'s Development' },
        { id: 'support-description', label: 'Support Description', placeholder: 'We\'ve designed the full learning journey and built a talented creative + development team...' },
        { id: 'support-levels-title', label: 'Support Levels Title', placeholder: 'Support Levels' },
        { id: 'support-tier-1-title', label: 'Tier 1 Title', placeholder: 'Community Supporter' },
        { id: 'support-tier-1-desc', label: 'Tier 1 Description', placeholder: 'Name in credits + private group invite' },
        { id: 'support-tier-1-price', label: 'Tier 1 Price', placeholder: '$5' },
        { id: 'support-tier-1-limit', label: 'Tier 1 Limit', placeholder: 'limitless' },
        { id: 'support-tier-2-title', label: 'Tier 2 Title', placeholder: 'Supporter' },
        { id: 'support-tier-2-desc', label: 'Tier 2 Description', placeholder: '15 hours premium access during MVP' },
        { id: 'support-tier-2-price', label: 'Tier 2 Price', placeholder: '$100' },
        { id: 'support-tier-2-limit', label: 'Tier 2 Limit', placeholder: 'Pay for usage hours' },
        { id: 'support-tier-3-title', label: 'Tier 3 Title', placeholder: 'Early Supporter' },
        { id: 'support-tier-3-desc', label: 'Tier 3 Description', placeholder: '30 hours premium access during MVP' },
        { id: 'support-tier-3-price', label: 'Tier 3 Price', placeholder: '$200' },
        { id: 'support-tier-3-limit', label: 'Tier 3 Limit', placeholder: 'Pay for usage hours' },
        { id: 'support-tier-4-title', label: 'Tier 4 Title', placeholder: 'VIP Access' },
        { id: 'support-tier-4-desc', label: 'Tier 4 Description', placeholder: '75 hours premium access + first invite to full version' },
        { id: 'support-tier-4-price', label: 'Tier 4 Price', placeholder: '$500' },
        { id: 'support-tier-4-limit', label: 'Tier 4 Limit', placeholder: 'Pay for usage hours' },
        { id: 'support-tier-5-title', label: 'Tier 5 Title', placeholder: 'Impact Partner' },
        { id: 'support-tier-5-desc', label: 'Tier 5 Description', placeholder: '120 hours + 10 gift licenses (30h each) + early feature access + roadmap input' },
        { id: 'support-tier-5-price', label: 'Tier 5 Price', placeholder: '$1,000' },
        { id: 'support-tier-5-limit', label: 'Tier 5 Limit', placeholder: '15 pieces' }
      ]
    },
    'PROJECT': {
      'Csapat információ (TeamInformationSection.tsx)': [
        { id: 'project-team', label: '👥 Main Team Title', placeholder: 'Meet Our Team' },
        { id: 'team-title', label: '🎯 Team Section Header', placeholder: 'Built by Language Learning Experts' },
        { id: 'team-description', label: '📝 Team Overview', placeholder: 'Our passionate team brings decades of experience...' },
        { id: 'team-content', label: '👨‍💼 Team Composition', placeholder: 'Our diverse team of educators, developers...' }
      ],
      'Csapat műveletek (TeamActionsSection.tsx)': [
        { id: 'team-button', label: '🔗 Primary Team Button', placeholder: 'Meet Our Expert Team' },
        { id: 'meet-team-button', label: '👋 Secondary Team Button', placeholder: 'Meet Our Team' },
        { id: 'meet-team-btn', label: '⭐ Call-to-Action Button', placeholder: 'Meet Our Expert Team' }
      ],
      'Csapattagok profiljai (TeamMemberProfiles.tsx)': [
        { id: 'member-1-name', label: '👩‍💼 Member 1 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-1-bio', label: '📝 Member 1 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-2-name', label: '👨‍💼 Member 2 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-2-bio', label: '📝 Member 2 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-3-name', label: '👩‍💻 Member 3 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-3-bio', label: '📝 Member 3 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-4-name', label: '👨‍🎨 Member 4 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-4-bio', label: '📝 Member 4 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-5-name', label: '👩‍🏫 Member 5 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-5-bio', label: '📝 Member 5 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-6-name', label: '👨‍💼 Member 6 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-6-bio', label: '📝 Member 6 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-7-name', label: '👩‍🔬 Member 7 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-7-bio', label: '📝 Member 7 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-8-name', label: '👨‍🏫 Member 8 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-8-bio', label: '📝 Member 8 - Biography', placeholder: 'Background, experience, expertise...' },
        { id: 'member-9-name', label: '👩‍💼 Member 9 - Name & Title', placeholder: 'Name - Role/Title' },
        { id: 'member-9-bio', label: '📝 Member 9 - Biography', placeholder: 'Background, experience, expertise...' }
      ],
      'Projekt hírlevél (ProjectNewsletterSection.tsx)': [
        { id: 'newsletter-title', label: '📧 Newsletter Main Title', placeholder: 'Subscribe to our newsletter for updates...' },
        { id: 'newsletter-description', label: '📝 Newsletter Description', placeholder: 'Subscribe to our newsletter for campaign updates' },
        { id: 'newsletter-heading', label: '🔔 Newsletter Heading', placeholder: 'Stay Updated' },
        { id: 'newsletter-success', label: '✅ Success Message', placeholder: 'Thanks for subscribing!' }
      ]
    },
    'CONTACT': {
      'Kapcsolat (ContactSection.tsx)': [
        { id: 'contact-title', label: 'Contact Title', placeholder: 'Ready to start your language learning journey?' }
      ],
      'Visszajelzés (FeedbackSection.tsx)': [
        { id: 'feedback', label: 'Feedback Title', placeholder: 'Send Us Your Thoughts' }
      ]
    },
    'FOOTER': {
      'Lábléc (FooterSection.tsx)': [
        { id: 'footer', label: 'Footer Title', placeholder: 'Contact Information' },
        { id: 'footer-about', label: 'Footer About', placeholder: 'VOC2GO revolutionizes language learning...' }
      ],
      'Hírlevél (NewsletterSection.tsx)': [
        { id: 'newsletter-title', label: 'Newsletter Title', placeholder: 'Subscribe to our newsletter for updates...' }
      ]
    }
  };

  useEffect(() => {
    let isMounted = true;
    
    const fetchData = async () => {
      if (isMounted) {
        await fetchContentSections();
      }
    };
    
    fetchData();
    
    return () => {
      isMounted = false;
    };
  }, [currentLanguage]);

  const fetchContentSections = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/admin/content', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setContentSections(Array.isArray(data.sections) ? data.sections : []);
      } else if (response.status === 401) {
        setError('Authentication required. Please log in again.');
      } else if (response.status >= 500) {
        setError('Server error. Please try again later.');
      } else {
        const errorData = await response.json().catch(() => ({}));
        setError(errorData.error || 'Failed to fetch content sections');
      }
    } catch (err) {
      console.error('Content fetch error:', err);
      if (err instanceof TypeError && err.message.includes('fetch')) {
        setError('Network error. Please check your connection.');
      } else {
        setError('Unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (sectionId: string) => {
    const section = contentSections.find(s => s.sectionId === sectionId && s.language === currentLanguage);
    if (section) {
      setEditingSection(sectionId);
      setEditData({
        title: section.title,
        content: section.content
      });
    } else {
      // Create new section
      const sectionConfig = Object.values(siteStructure)
        .flatMap(menu => Object.values(menu))
        .flat()
        .find(item => item.id === sectionId);
      
      setEditingSection(sectionId);
      setEditData({
        title: sectionConfig?.label || '',
        content: sectionConfig?.placeholder || ''
      });
    }
  };

  const handleSave = async () => {
    if (!editingSection) return;

    try {
      setLoading(true);
      setError(null);
      setSuccessMessage(null);
      
      // Input validation before sending
      if (!editData.title.trim() || !editData.content.trim()) {
        setError('Title and content are required');
        return;
      }
      
      if (editData.title.length > 500) {
        setError('Title is too long (max 500 characters)');
        return;
      }
      
      if (editData.content.length > 50000) {
        setError('Content is too long (max 50000 characters)');
        return;
      }
      
      console.log(`Saving content for section: ${editingSection}, language: ${currentLanguage}`);
      
      const response = await fetch(`/api/admin/content/${editingSection}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          title: editData.title.trim(),
          content: editData.content.trim(),
          language: currentLanguage
        })
      });
      
      console.log(`Save response status: ${response.status}`);

      if (response.ok) {
        console.log('Save successful! Refreshing content...');
        // First refresh the content sections to get latest data
        await fetchContentSections();
        
        // Clear editing state
        setEditingSection(null);
        setEditData({ title: '', content: '' });
        
        // Force a complete component re-render
        setRefreshKey(prev => prev + 1);
        
        // Force refresh the main content cache with language-specific event
        console.log(`Dispatching contentUpdated event for language: ${currentLanguage}`);
        // Dispatch immediately for the current language
        window.dispatchEvent(new CustomEvent('contentUpdated', { 
          detail: { language: currentLanguage } 
        }));
        // Also dispatch for all languages to ensure complete refresh
        window.dispatchEvent(new CustomEvent('contentUpdated', { 
          detail: { language: 'all' } 
        }));
        
        // Show success message temporarily
        setSuccessMessage('Content saved successfully!');
        setTimeout(() => setSuccessMessage(null), 3000);
      } else if (response.status === 401) {
        console.error('Authentication failed - redirecting to admin login');
        setError('⚠️ Authentication failed. Please log into the admin system first.');
        // Check if we can access admin endpoint
        setTimeout(() => {
          if (window.location.pathname !== '/admin') {
            window.location.href = '/admin';
          }
        }, 2000);
      } else if (response.status >= 500) {
        setError('Server error. Please try again later.');
      } else {
        const responseData = await response.json().catch(() => ({}));
        setError(`Failed to save content: ${responseData.error || 'Unknown error'}`);
        console.error('Save failed with status:', response.status, 'Response:', responseData);
      }
    } catch (err) {
      console.error('Save error:', err);
      if (err instanceof TypeError && err.message.includes('fetch')) {
        setError('Network error. Please check your connection.');
      } else {
        setError('Unexpected error occurred. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setEditingSection(null);
    setEditData({ title: '', content: '' });
  };

  const getCurrentContent = (sectionId: string) => {
    const section = contentSections.find(s => s.sectionId === sectionId && s.language === currentLanguage);
    
    // Enhanced debugging for Hungarian content
    if (currentLanguage === 'hu') {
      console.log(`Checking Hungarian content for: ${sectionId}`);
      console.log(`Available sections:`, contentSections.filter(s => s.sectionId === sectionId));
      if (!section) {
        console.log(`Missing Hungarian content for: ${sectionId}`);
      } else {
        console.log(`Found Hungarian content for ${sectionId}:`, section.content);
      }
    }
    
    return section ? section.content : '';
  };

  const renderSectionEditor = (sectionId: string, label: string, placeholder: string) => {
    const isEditing = editingSection === sectionId;
    const currentContent = getCurrentContent(sectionId);
    const sectionStyle = getSectionColor(sectionId, currentLanguage);
    const translationStatus = getTranslationStatus(sectionId, currentLanguage);
    
    // Check if we're viewing Hungarian but only have English content
    const hasOnlyEnglish = currentLanguage === 'hu' && translationStatus.status === 'missing';
    const englishSection = hasOnlyEnglish ? contentSections.find(s => s.sectionId === sectionId && s.language === 'en') : null;

    return (
      <div 
        key={`${sectionId}-${refreshKey}`} 
        className="content-section" 
        data-section-id={sectionId}
        style={{
          ...sectionStyle,
          padding: '16px',
          marginBottom: '16px',
          position: 'relative',
          width: '100%',
          boxSizing: 'border-box',
          overflow: 'hidden',
          transition: 'box-shadow 0.3s ease',
          // Orange highlighting when showing English content in Hungarian view
          ...(hasOnlyEnglish ? {
            backgroundColor: '#fed7aa',
            border: '3px solid #ea580c',
            boxShadow: '0 4px 12px rgba(234, 88, 12, 0.3)'
          } : {})
        }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '12px'
        }}>
          <div>
            <h4 style={{ 
              margin: 0, 
              fontSize: '15px', 
              fontWeight: '700', 
              color: currentLanguage === 'hu' ? '#92400e' : '#1e40af', // Darker colors for better contrast
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              {currentLanguage === 'hu' ? '🇭🇺' : '🇬🇧'} {label}
              <span style={{ 
                fontSize: '11px', 
                padding: '3px 8px', 
                backgroundColor: translationStatus.status === 'complete' ? '#059669' : 
                               translationStatus.status === 'missing' ? '#dc2626' : '#d97706',
                color: 'white',
                borderRadius: '12px',
                fontWeight: '600'
              }}>
                {translationStatus.label}
              </span>
            </h4>
            <small style={{ 
              color: currentLanguage === 'hu' ? '#78350f' : '#1e3a8a', 
              fontSize: '12px',
              fontWeight: '500'
            }}>
              Section ID: {sectionId} | Language: {currentLanguage.toUpperCase()}
            </small>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            {isEditing ? (
              <>
                <button
                  onClick={handleSave}
                  disabled={loading}
                  style={{
                    padding: '6px 12px',
                    background: '#10b981',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <Save size={12} />
                  Save
                </button>
                <button
                  onClick={handleCancel}
                  style={{
                    padding: '6px 12px',
                    background: '#6b7280',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <X size={12} />
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={() => handleEdit(sectionId)}
                style={{
                  padding: '6px 12px',
                  background: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px'
                }}
              >
                <Edit3 size={12} />
                Edit
              </button>
            )}
          </div>
        </div>

        {isEditing ? (
          <textarea
            value={editData.content}
            onChange={(e) => setEditData(prev => ({ ...prev, content: e.target.value }))}
            placeholder={placeholder}
            style={{
              width: '100%',
              minHeight: '100px',
              padding: '12px',
              border: '1px solid #d1d5db',
              borderRadius: '4px',
              fontSize: '14px',
              resize: 'vertical',
              fontFamily: 'inherit',
              boxSizing: 'border-box',
              lineHeight: '1.5',
              wordWrap: 'break-word'
            }}
          />
        ) : (
          <div style={{
            padding: '12px',
            background: hasOnlyEnglish ? '#fff7ed' : '#f9fafb',
            borderRadius: '4px',
            minHeight: '80px',
            maxHeight: '300px',
            fontSize: '14px',
            color: hasOnlyEnglish ? '#ea580c' : '#374151',
            whiteSpace: 'pre-wrap',
            wordWrap: 'break-word',
            overflowWrap: 'break-word',
            wordBreak: 'break-word',
            lineHeight: '1.5',
            overflowY: 'auto',
            border: hasOnlyEnglish ? '2px solid #ea580c' : '1px solid #e5e7eb',
            fontWeight: hasOnlyEnglish ? '600' : 'normal'
          }}>
            {hasOnlyEnglish && englishSection ? (
              <div>
                <div style={{ 
                  fontSize: '12px', 
                  color: '#ea580c', 
                  fontWeight: 'bold', 
                  marginBottom: '12px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  🔶 ENGLISH TEXT TO TRANSLATE:
                </div>
                <div style={{ 
                  fontSize: '14px',
                  backgroundColor: '#fff',
                  padding: '12px',
                  borderRadius: '6px',
                  border: '2px solid #ea580c',
                  marginBottom: '12px',
                  lineHeight: '1.5',
                  color: '#1f2937',
                  fontWeight: '500'
                }}>
                  {englishSection.content}
                </div>
                <div style={{
                  fontSize: '11px',
                  color: '#ea580c',
                  fontStyle: 'italic',
                  opacity: 0.8
                }}>
                  Copy the English text above and translate it to Hungarian, then click Edit to add the translation.
                </div>
              </div>
            ) : currentContent ? (
              <div style={{ 
                width: '100%',
                display: 'block',
                textAlign: 'left'
              }}>
                {currentContent}
              </div>
            ) : (
              <span style={{ 
                color: '#9ca3af', 
                fontStyle: 'italic',
                opacity: 0.6
              }}>
                {currentLanguage === 'hu' ? 
                  `[Magyar tartalom hiányzik: ${sectionId}]` : 
                  placeholder}
              </span>
            )}
          </div>
        )}
        
        {/* Add social media manager for team member bio sections */}
        {sectionId.match(/^member-\d+-bio$/) && !isEditing && (
          <TeamSocialMediaManager
            memberId={sectionId.replace('-bio', '')}
            memberName={sectionId.replace('-bio', '').replace('-', ' ').toUpperCase()}
            language={currentLanguage}
            onSave={(links) => {
              console.log(`Social media links updated for ${sectionId}:`, links);
              // Force a content refresh to show updated status
              setRefreshKey(prev => prev + 1);
            }}
          />
        )}
      </div>
    );
  };

  if (loading && !editingSection) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '200px' }}>
        <RefreshCw className="animate-spin" size={24} />
      </div>
    );
  }

  return (
    <div 
      id="admin-content-container"
      style={{ 
        maxHeight: '70vh', 
        overflowY: 'auto',
        position: 'relative',
        scrollBehavior: 'smooth',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      {error && (
        <div style={{
          background: '#fef2f2',
          border: '1px solid #fca5a5',
          color: '#dc2626',
          padding: '12px',
          borderRadius: '4px',
          marginBottom: '16px'
        }}>
          {error}
        </div>
      )}

      {successMessage && (
        <div style={{
          background: '#f0fdf4',
          border: '1px solid #86efac',
          color: '#15803d',
          padding: '12px',
          borderRadius: '4px',
          marginBottom: '16px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{ fontSize: '16px' }}>✅</span>
          {successMessage}
        </div>
      )}

      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '8px',
        padding: '0 4px'
      }}>
        <h3 style={{ margin: 0, fontSize: '18px', fontWeight: '600', display: 'none' }}>
        </h3>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={() => {
              const container = document.getElementById('admin-content-container');
              if (container) {
                container.scrollTop = 0;
              }
            }}
            style={{
              padding: '6px 12px',
              background: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}
          >
            ↑ Top
          </button>
          <button
            onClick={fetchContentSections}
            disabled={loading}
            style={{
              padding: '6px 12px',
              background: '#6b7280',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '12px',
              display: 'flex',
              alignItems: 'center',
              gap: '4px'
            }}
          >
            <RefreshCw size={12} />
            Refresh
          </button>
        </div>
      </div>

      {/* Page Filters */}
      <div style={{ 
        display: 'flex', 
        gap: '8px', 
        marginBottom: '20px',
        padding: '12px',
        backgroundColor: '#f9fafb',
        borderRadius: '8px',
        flexWrap: 'wrap'
      }}>
        {Object.entries(pageCategories).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setSelectedPage(key)}
            style={{
              padding: '8px 16px',
              fontSize: '13px',
              fontWeight: '500',
              border: selectedPage === key ? '2px solid #3b82f6' : '1px solid #d1d5db',
              borderRadius: '6px',
              backgroundColor: selectedPage === key ? '#3b82f6' : 'white',
              color: selectedPage === key ? 'white' : '#374151',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            {label}
          </button>
        ))}
      </div>
      
      {/* Status Summary */}
      <div style={{ 
        display: 'flex', 
        gap: '16px', 
        fontSize: '12px',
        marginBottom: '16px',
        color: '#6b7280'
      }}>
        <span>✅ Complete: {contentSections.filter(s => {
          const sectionId = s.sectionId;
          const hasEn = contentSections.some(sec => sec.sectionId === sectionId && sec.language === 'en');
          const hasHu = contentSections.some(sec => sec.sectionId === sectionId && sec.language === 'hu');
          return hasEn && hasHu;
        }).length / 2}</span>
        <span style={{ color: '#ef4444' }}>
          ⚠️ Missing: {contentSections.filter(s => {
            const sectionId = s.sectionId;
            const hasEn = contentSections.some(sec => sec.sectionId === sectionId && sec.language === 'en');
            const hasHu = contentSections.some(sec => sec.sectionId === sectionId && sec.language === 'hu');
            return hasEn && !hasHu;
          }).length}
        </span>
      </div>

      {/* Scrollable Content Area */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        {/* Debug info for Hungarian content */}
        {currentLanguage === 'hu' && (
          <div style={{ 
            padding: '12px', 
            background: '#fef3c7', 
            border: '1px solid #f59e0b', 
            borderRadius: '6px',
            marginBottom: '16px',
            fontSize: '12px'
          }}>
            Debug: Showing {contentSections.filter(s => s.language === 'hu').length} Hungarian sections loaded
          </div>
        )}
        
        {Object.entries(siteStructure).map(([menuName, menuSections]) => {
        // Filter sections based on selected page
        if (selectedPage !== 'all' && menuName.toLowerCase() !== selectedPage && 
            selectedPage !== 'missing-hungarian' && selectedPage !== 'needs-attention') {
          return null;
        }
        
        // Get all sections for this menu
        const filteredSections = Object.entries(menuSections);

        if (filteredSections.length === 0) return null;

        return (
          <div key={menuName} style={{ marginBottom: '32px' }}>
            <h3 style={{
              fontSize: '16px',
              fontWeight: '600',
              marginBottom: '16px',
              padding: '8px 12px',
              background: 'linear-gradient(90deg, #5C37C7, #44d1c6)',
              color: 'white',
              borderRadius: '6px'
            }}>
              {menuName} Menu
            </h3>
            
            {filteredSections.map(([sectionName, sectionItems]) => {
              // Get all items for this section
              const filteredItems = sectionItems;

              if (filteredItems.length === 0) return null;

              return (
                <div key={sectionName} style={{ marginBottom: '24px' }}>
                  <h4 style={{
                    fontSize: '14px',
                    fontWeight: '600',
                    marginBottom: '12px',
                    color: '#3b82f6',
                    background: `linear-gradient(90deg, #3b82f620, transparent)`,
                    padding: '8px 12px',
                    borderRadius: '6px',
                    borderLeft: `4px solid #3b82f6`
                  }}>
                    {sectionName}

                  </h4>
                  
                  {filteredItems.map(item => {
                    // Apply special filtering for missing Hungarian and needs attention
                    if (selectedPage === 'missing-hungarian') {
                      const hasEn = contentSections.some(sec => sec.sectionId === item.id && sec.language === 'en');
                      const hasHu = contentSections.some(sec => sec.sectionId === item.id && sec.language === 'hu');
                      if (!(hasEn && !hasHu)) return null; // Only show sections missing Hungarian
                    }
                    
                    if (selectedPage === 'needs-attention') {
                      const hasEn = contentSections.some(sec => sec.sectionId === item.id && sec.language === 'en');
                      const hasHu = contentSections.some(sec => sec.sectionId === item.id && sec.language === 'hu');
                      if (hasEn && hasHu) return null; // Only show sections that need attention
                    }
                    
                    const hasContent = getCurrentContent(item.id);
                    return renderSectionEditor(item.id, item.label, item.placeholder);
                  })}
                </div>
              );
            })}
          </div>
        );
      })}
      
        {/* Fixed Back to Top Button */}
        <div style={{
          position: 'sticky',
          bottom: '10px',
          right: '10px',
          textAlign: 'right',
          marginTop: '20px'
        }}>
          <button
            onClick={() => {
              const container = document.getElementById('admin-content-container');
              if (container) {
                container.scrollTop = 0;
              }
            }}
            style={{
              padding: '8px 16px',
              background: '#5C37C7',
              color: 'white',
              border: 'none',
              borderRadius: '20px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ↑ Back to Top
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminContentManager;