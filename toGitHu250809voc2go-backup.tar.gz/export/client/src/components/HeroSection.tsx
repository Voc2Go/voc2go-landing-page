import React, { useEffect, useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import mockupImage from "@assets/Pubd080125.png";

const HeroSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentTitle, getContentText } = useContent();
  const [isVisible, setIsVisible] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [isAlreadySubscribed, setIsAlreadySubscribed] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Custom validation for Hungarian language
    const emailInput = e.currentTarget.querySelector('input[type="email"]') as HTMLInputElement;
    if (emailInput && !emailInput.validity.valid) {
      if (language === 'hu') {
        if (emailInput.validity.valueMissing) {
          emailInput.setCustomValidity('Kérjük, töltsd ki ezt a mezőt');
        } else if (emailInput.validity.typeMismatch) {
          emailInput.setCustomValidity('Kérjük, adj meg egy érvényes email címet');
        } else {
          emailInput.setCustomValidity('Kérjük, adj meg egy érvényes email címet');
        }
      } else {
        emailInput.setCustomValidity(''); // Reset to default English messages
      }
      emailInput.reportValidity();
      return;
    }
    
    if (!email.trim()) return;

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.trim(),
          source: 'campaign',
          language: language,
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        // New subscription successful
        setIsSubmitted(true);
        setIsAlreadySubscribed(false);
        setSubmitMessage(language === 'en' ? "Thanks for your support!" : "Köszönjük a támogatást!");
        setEmail('');
        setTimeout(() => {
          setIsSubmitted(false);
          setShowEmailForm(false);
        }, 3000);
      } else if (response.status === 409) {
        // Email already subscribed
        setIsSubmitted(true);
        setIsAlreadySubscribed(true);
        setSubmitMessage(language === 'en' ? "You're already subscribed!" : "Már feliratkoztál!");
        setEmail('');
        setTimeout(() => {
          setIsSubmitted(false);
          setShowEmailForm(false);
        }, 3000);
      } else {
        console.error('Campaign subscription error:', data.message || 'Unknown error');
        alert(language === 'en' ? 'Error subscribing. Please try again.' : 'Hiba a feliratkozásban. Kérjük, próbáld újra.');
      }
    } catch (error) {
      console.error('Error submitting email:', error);
      alert(language === 'en' ? 'Network error. Please try again.' : 'Hálózati hiba. Kérjük, próbáld újra.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <>
      {/* Welcome Section - Immediately after header */}
      <section 
        className="video-section" 
        id="welcome" 
        role="banner"
        aria-labelledby="welcome-heading"
        style={{
          paddingTop: '160px', 
          paddingBottom: '20px',
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
          transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        <div className="container">
          <div className="video-content">
            <div className="video-text">
              <h1 
                id="welcome-heading"
                style={{ 
                  lineHeight: '1.4', 
                  fontSize: isMobile ? 'calc(1rem + 1.2vw)' : 'calc(1.2rem + 1vw)',
                  textAlign: 'center',
                  margin: '0',
                  width: '100%',
                  letterSpacing: isMobile ? '1px' : '2px',
                  fontWeight: '700',
                  color: 'white',
                  transform: isVisible ? 'scale(1)' : 'scale(0.95)',
                  transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1) 0.2s',
                  wordWrap: 'break-word',
                  hyphens: 'auto'
                }}
              >
{getContentText('hero-title', language === 'en' ? 'LEARN ENGLISH' : 'SZÓRÓL SZÓRA')}<br />
                {getContentText('hero-subtitle-1', language === 'en' ? 'WORD BY WORD' : 'TÖRTÉNETRŐL TÖRTÉNETRE')}<br />
                {getContentText('hero-subtitle-2', language === 'en' ? 'STORY BY STORY' : 'TANULJ ANGOLUL')}
              </h1>
            </div>
            <div 
              className="video-container"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1) 0.4s',
                width: '100%',
                maxWidth: '100%',
                padding: isMobile ? '0 10px' : '0'
              }}
            >
              <iframe 
                src="https://www.youtube.com/embed/5pNKy7C5USE?si=20BkjAt--wDaZdVp" 
                title={language === 'en' ? "VOC2GO Introduction Video" : "VOC2GO Bemutató Videó"}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                aria-describedby="video-description"
                style={{
                  borderRadius: '12px',
                  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
                  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                  width: '100%',
                  height: isMobile ? 'auto' : undefined,
                  aspectRatio: isMobile ? '16/9' : undefined
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.02)';
                  e.currentTarget.style.boxShadow = '0 12px 40px rgba(0, 0, 0, 0.18)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.12)';
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Hero Section - After the welcome section */}
      <section 
        className="hero-section gradient-primary" 
        id="home" 
        role="main"
        aria-labelledby="hero-heading"
        style={{
          padding: '20px 0 30px',
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
          transition: 'all 1s cubic-bezier(0.4, 0, 0.2, 1) 0.6s'
        }}
      >
        <div className="hero-background-overlay"></div>
        <div className="container" style={{maxWidth: '1000px'}}>
          <div className="hero-content">
            <div className="hero-text">
              {getContentText('hero-heading', '') && (
                <h2 
                  id="hero-heading" 
                  className="sr-only"
                >
                  {getContentText('hero-heading', '')}
                </h2>
              )}
              <p 
                className="hero-subtitle"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
                  transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1) 0.8s',
                  fontSize: isMobile ? '18px' : '20px',
                  lineHeight: '1.6',
                  wordWrap: 'break-word',
                  hyphens: 'auto',
                  padding: isMobile ? '0 10px' : '0'
                }}
              >
                {getContentText('hero-main-subtitle', language === 'en' ? "Personalized, Story-Based Learning — Powered by AI & You. No pre-made lessons — learning happens through real AI conversations based on your life and goals." : "Személyre szabott, történet-alapú tanulás — MI és Te által. Nincs előre gyártott lecke — a tanulás valós MI beszélgetéseken keresztül történik az életed és céljaid alapján.")}
              </p>
              <div 
                className="btn-group"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                  transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1) 1s'
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', alignItems: 'center', width: '100%' }}>
                  <button 
                    className="btn btn-outline-light btn-lg"
                    role="button"
                    style={{
                      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                      outline: 'none'
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.transform = 'scale(1.05)';
                      e.currentTarget.style.outline = '3px solid rgba(255, 255, 255, 0.5)';
                      e.currentTarget.style.outlineOffset = '4px';
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.transform = 'scale(1)';
                      e.currentTarget.style.outline = 'none';
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'scale(1.05) translateY(-2px)';
                      e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'scale(1)';
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                    onClick={() => {
                      // Navigate to PROJECT menu by dispatching custom event
                      const event = new CustomEvent('navigate', { detail: { section: 'project' } });
                      window.dispatchEvent(event);
                    }}
                  >
                    {getContentText('meet-team-button', language === 'en' ? "Meet Our Expert Team" : "Ismerje meg szakértő csapatunkat")}
                  </button>
                  
                  {/* Indiegogo Campaign Button */}
                  <a 
                    href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'inline-block',
                      backgroundColor: '#eb1478',
                      color: 'white',
                      padding: '14px 28px',
                      borderRadius: '50px',
                      textDecoration: 'none',
                      fontWeight: 'bold',
                      fontSize: '1rem',
                      boxShadow: '0 6px 20px rgba(235, 20, 120, 0.4)',
                      transition: 'all 0.3s ease',
                      border: '2px solid rgba(255, 255, 255, 0.2)',
                      textTransform: 'uppercase',
                      letterSpacing: '1px'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'translateY(-2px)';
                      e.currentTarget.style.boxShadow = '0 8px 25px rgba(235, 20, 120, 0.6)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'translateY(0)';
                      e.currentTarget.style.boxShadow = '0 6px 20px rgba(235, 20, 120, 0.4)';
                    }}
                  >
                    {getContentText('indiegogo-button', language === 'en' ? "Support on Indiegogo" : "Támogass az Indiegogo-n")}
                  </a>
                </div>

              </div>
            </div>
            <div 
              className="hero-image"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateX(0) scale(1)' : 'translateX(30px) scale(0.9)',
                transition: 'all 1s cubic-bezier(0.4, 0, 0.2, 1) 1.2s'
              }}
            >
              <div className="phone-mockup">
                <div className="phone-frame"></div>
                <img 
                  src={mockupImage} 
                  alt={language === 'en' 
                    ? "VOC2GO mobile app interface showcasing personalized language learning features" 
                    : "VOC2GO mobilalkalmazás felülete személyre szabott nyelvtanulási funkciókkal"
                  } 
                  className="app-screenshot"
                  loading="eager"
                  style={{
                    transition: 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)'
                  }}
                />
                <div 
                  className="coming-soon-badge"
                  style={{
                    animation: isVisible ? 'pulse 2s infinite' : 'none'
                  }}
                >
                  {getContentText('coming-soon-badge', language === 'en' ? "Coming Soon!" : "Hamarosan!")}
                </div>
              </div>
              <div className="hero-image-decoration"></div>
            </div>
          </div>

        </div>
      </section>
    </>
  );
};

export default HeroSection;