import React, { useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { CheckCircle, Send, MessageSquare, Mail, User, Star } from "lucide-react";

const FeedbackSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    rating: "5"
  });
  const [submitted, setSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Reset custom validation when user types
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
      e.target.setCustomValidity('');
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Custom validation for Hungarian language
    const form = e.target as HTMLFormElement;
    const emailInput = form.querySelector('input[type="email"]') as HTMLInputElement;
    const messageInput = form.querySelector('textarea[name="message"]') as HTMLTextAreaElement;
    
    if (!formData.email.trim()) {
      emailInput.setCustomValidity(language === 'en' ? 'Please fill in this field' : 'Kérjük, töltsd ki ezt a mezőt');
      emailInput.reportValidity();
      setIsLoading(false);
      return;
    }
    
    if (!formData.message.trim()) {
      messageInput.setCustomValidity(language === 'en' ? 'Please fill in this field' : 'Kérjük, töltsd ki ezt a mezőt');
      messageInput.reportValidity();
      setIsLoading(false);
      return;
    }
    
    // Clear custom validation
    emailInput.setCustomValidity('');
    messageInput.setCustomValidity('');
    
    try {
      setError(null);
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          rating: parseInt(formData.rating),
          source: "feedback_form",
          language: language
        }),
      });
      
      if (response.ok) {
        setSubmitted(true);
        setFormData({
          name: "",
          email: "",
          message: "",
          rating: "5"
        });
      } else {
        const errorData = await response.json().catch(() => ({ message: 'Unknown error' }));
        setError(errorData.message || 'Failed to submit feedback. Please try again.');
      }
    } catch (error) {
      console.error('Feedback submission failed:', error);
      setError('Network error. Please check your connection and try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  if (submitted) {
    return (
      <section id="feedback" className="modern-section" style={{ 
        paddingTop: "120px", 
        minHeight: "80vh",
        display: "flex",
        alignItems: "center",
        background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
        color: "white"
      }}>
        <div className="container">
          <div className="success-message" style={{
            textAlign: "center",
            maxWidth: "600px",
            margin: "0 auto",
            padding: "60px 30px",
            borderRadius: "16px",
            background: "rgba(255, 255, 255, 0.05)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.1)",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)"
          }}>
            <div style={{
              width: "80px",
              height: "80px",
              borderRadius: "50%",
              background: "#F7941D",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 30px"
            }}>
              <CheckCircle size={48} color="#fff" />
            </div>
            <h3 style={{ 
              fontSize: "28px", 
              marginBottom: "20px", 
              fontWeight: "bold" 
            }}>{getContentText('feedback-success-title', language === 'en' ? "Thank you for your feedback!" : "Köszönjük a visszajelzést!")}</h3>
            <p style={{ 
              fontSize: "18px", 
              opacity: "0.9", 
              lineHeight: "1.6" 
            }}>{getContentText('feedback-success-message', language === 'en' ? "Your message has been submitted successfully." : "Üzeneted sikeresen elküldve.")}</p>
          </div>
        </div>
      </section>
    );
  }
  
  return (
    <section id="feedback" className="modern-section" style={{ 
      paddingTop: "120px", 
      background: "linear-gradient(135deg, #301A4B 0%, #1D0F2F 100%)",
      color: "white",
      minHeight: "80vh",
      display: "flex",
      alignItems: "center"
    }}>
      <div className="container">
        <div className="section-header" style={{ textAlign: "center", marginBottom: "50px" }}>
          <h2 style={{ 
            fontSize: "40px", 
            fontWeight: "bold", 
            marginBottom: "20px",
            background: "linear-gradient(to right, #F7941D, #44d1c6)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            display: "inline-block"
          }}>{getContentText('feedback-heading', language === 'en' ? "Send Us Your Thoughts" : "Küldd El Gondolataidat")}</h2>
          <p style={{ fontSize: "18px", maxWidth: "600px", margin: "0 auto", opacity: "0.9" }}>{getContentText('feedback-description', language === 'en' ? "We value your feedback to improve our app" : "Nagyra értékeljük a visszajelzéseidet")}</p>
        </div>
        
        <div style={{ 
          maxWidth: "800px", 
          margin: "0 auto",
          display: "flex",
          flexDirection: "column",
          gap: "40px"
        }}>
          <form onSubmit={handleSubmit} className="modern-form" style={{
            padding: "40px",
            borderRadius: "16px",
            background: "rgba(255, 255, 255, 0.1)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.2)",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)"
          }}>
            <div style={{ 
              display: "grid", 
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", 
              gap: "24px",
              marginBottom: "24px"
            }}>
              <div className="form-group" style={{ position: "relative" }}>
                <label htmlFor="name" style={{ 
                  display: "block", 
                  marginBottom: "8px",
                  fontSize: "14px",
                  fontWeight: "500",
                  color: "rgba(255, 255, 255, 0.8)"
                }}>{t("Your Name")} {t("optional")}</label>
                <div style={{ position: "relative" }}>
                  <div style={{ 
                    position: "absolute", 
                    left: "15px", 
                    top: "50%", 
                    transform: "translateY(-50%)",
                    color: "#44d1c6"
                  }}>
                    <User size={18} />
                  </div>
                  <input 
                    type="text" 
                    id="name" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder={t("Enter your name")}
                    style={{
                      width: "100%",
                      padding: "14px 14px 14px 45px",
                      borderRadius: "8px",
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      background: "rgba(255, 255, 255, 0.2)",
                      color: "white",
                      fontSize: "16px",
                      transition: "all 0.3s ease",
                      outline: "none"
                    }}
                  />
                </div>
              </div>
              
              <div className="form-group" style={{ position: "relative" }}>
                <label htmlFor="email" style={{ 
                  display: "block", 
                  marginBottom: "8px",
                  fontSize: "14px",
                  fontWeight: "500",
                  color: "rgba(255, 255, 255, 0.8)"
                }}>{t("Email Address")} *</label>
                <div style={{ position: "relative" }}>
                  <div style={{ 
                    position: "absolute", 
                    left: "15px", 
                    top: "50%", 
                    transform: "translateY(-50%)",
                    color: "#44d1c6"
                  }}>
                    <Mail size={18} />
                  </div>
                  <input 
                    type="email" 
                    id="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder={t("Enter your email")}
                    required
                    style={{
                      width: "100%",
                      padding: "14px 14px 14px 45px",
                      borderRadius: "8px",
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      background: "rgba(255, 255, 255, 0.2)",
                      color: "white",
                      fontSize: "16px",
                      transition: "all 0.3s ease",
                      outline: "none"
                    }}
                  />
                </div>
              </div>
            </div>
            
            <div className="form-group" style={{ marginBottom: "24px" }}>
              <label htmlFor="message" style={{ 
                display: "block", 
                marginBottom: "8px",
                fontSize: "14px",
                fontWeight: "500",
                color: "rgba(255, 255, 255, 0.8)"
              }}>{t("Your Message")} *</label>
              <div style={{ position: "relative" }}>
                <div style={{ 
                  position: "absolute", 
                  left: "15px", 
                  top: "15px",
                  color: "#44d1c6"
                }}>
                  <MessageSquare size={18} />
                </div>
                <textarea 
                  id="message" 
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder={t("Enter your message or suggestion")}
                  rows={5}
                  required
                  style={{
                    width: "100%",
                    padding: "14px 14px 14px 45px",
                    borderRadius: "8px",
                    border: "1px solid rgba(255, 255, 255, 0.3)",
                    background: "rgba(255, 255, 255, 0.2)",
                    color: "white",
                    fontSize: "16px",
                    transition: "all 0.3s ease",
                    outline: "none",
                    resize: "vertical",
                    minHeight: "120px"
                  }}
                ></textarea>
              </div>
            </div>
            
            <div className="form-group" style={{ marginBottom: "30px" }}>
              <label htmlFor="rating" style={{ 
                display: "block", 
                marginBottom: "8px",
                fontSize: "14px",
                fontWeight: "500",
                color: "rgba(255, 255, 255, 0.8)"
              }}>{t("How excited are you about VOC2GO?")} *</label>
              <div style={{ position: "relative" }}>
                <div style={{ 
                  position: "absolute", 
                  left: "15px", 
                  top: "50%", 
                  transform: "translateY(-50%)",
                  color: "#44d1c6"
                }}>
                  <Star size={18} />
                </div>
                <select 
                  id="rating" 
                  name="rating"
                  value={formData.rating}
                  onChange={handleChange}
                  required
                  style={{
                    width: "100%",
                    padding: "14px 14px 14px 45px",
                    borderRadius: "8px",
                    border: "1px solid rgba(255, 255, 255, 0.3)",
                    background: "rgba(255, 255, 255, 0.2)",
                    color: "white",
                    fontSize: "16px",
                    transition: "all 0.3s ease",
                    outline: "none",
                    appearance: "none",
                    WebkitAppearance: "none",
                    MozAppearance: "none",
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E")`,
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "right 15px center",
                    backgroundSize: "16px"
                  }}
                >
                  <option value="5">{t("Very Excited")}</option>
                  <option value="4">{t("Excited")}</option>
                  <option value="3">{t("Somewhat Excited")}</option>
                  <option value="2">{t("Slightly Excited")}</option>
                  <option value="1">{t("Not Excited")}</option>
                </select>
              </div>
            </div>
            
            {error && (
              <div style={{
                padding: "12px 16px",
                backgroundColor: "rgba(239, 68, 68, 0.2)",
                border: "1px solid rgba(239, 68, 68, 0.3)",
                borderRadius: "8px",
                color: "#ef4444",
                fontSize: "14px",
                marginBottom: "16px"
              }}>
                {error}
              </div>
            )}
            
            <button 
              type="submit" 
              disabled={isLoading}
              style={{
                background: "linear-gradient(to right, #F7941D, #e78100)",
                color: "white",
                border: "none",
                borderRadius: "8px",
                padding: "14px 30px",
                fontSize: "16px",
                fontWeight: "600",
                cursor: isLoading ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "10px",
                width: "100%",
                transition: "all 0.3s ease",
                boxShadow: "0 8px 20px rgba(247, 148, 29, 0.3)",
                opacity: isLoading ? 0.7 : 1
              }}
            >
              <Send size={18} />
              {isLoading ? t("Submitting...") : t("Submit Feedback")}
            </button>
          </form>
          
          <div style={{ 
            display: "flex", 
            justifyContent: "center", 
            gap: "20px", 
            alignItems: "center",
            flexWrap: "wrap"
          }}>
            <a href="mailto:voc2go@gmail.com" style={{ 
              color: "white", 
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              opacity: 0.8,
              transition: "opacity 0.3s ease"
            }}>
              <Mail size={18} />
              voc2go@gmail.com
            </a>
            <span style={{ color: "rgba(255, 255, 255, 0.3)" }}>•</span>
            <div style={{ 
              display: "flex",
              gap: "15px"
            }}>
              {/* Social media icons would go here */}
              <a href="#" style={{ 
                width: "36px", 
                height: "36px", 
                borderRadius: "50%", 
                background: "rgba(255, 255, 255, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                transition: "all 0.3s ease"
              }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
              </a>
              <a href="#" style={{ 
                width: "36px", 
                height: "36px", 
                borderRadius: "50%", 
                background: "rgba(255, 255, 255, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                transition: "all 0.3s ease"
              }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
              </a>

            </div>
          </div>
          
          {/* Indiegogo Campaign Button */}
          <div style={{ 
            textAlign: 'center', 
            marginTop: '60px',
            paddingBottom: '20px'
          }}>
            <a 
              href="https://www.indiegogo.com/projects/--3255198/coming_soon/x/25942494"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'inline-block',
                backgroundColor: '#eb1478',
                color: 'white',
                padding: '18px 36px',
                borderRadius: '50px',
                textDecoration: 'none',
                fontWeight: 'bold',
                fontSize: '1.2rem',
                boxShadow: '0 8px 25px rgba(235, 20, 120, 0.4)',
                transition: 'all 0.3s ease',
                border: '2px solid rgba(255, 255, 255, 0.2)',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-3px)';
                e.currentTarget.style.boxShadow = '0 12px 35px rgba(235, 20, 120, 0.6)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 8px 25px rgba(235, 20, 120, 0.4)';
              }}
            >
              {getContentText('indiegogo-button', language === 'en' ? "Support on Indiegogo" : "Támogass az Indiegogo-n")}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeedbackSection;