import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Users } from "lucide-react";

const TeamSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();

  const handleTeamClick = () => {
    // Navigate to PROJECT menu where the real team details are shown
    const event = new CustomEvent('navigate', { detail: 'project' });
    window.dispatchEvent(event);
  };

  return (
    <section id="team" style={{
      padding: "60px 0",
      background: "linear-gradient(135deg, rgba(245, 245, 247, 1) 0%, rgba(255, 255, 255, 1) 100%)",
      position: "relative"
    }}>
      <div className="container" style={{ maxWidth: "800px", margin: "0 auto", padding: "0 20px", textAlign: "center" }}>
        <h2 style={{ 
          fontSize: "2.5rem", 
          marginBottom: "20px",
          background: "linear-gradient(90deg, #5C37C7, #44d1c6)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          fontWeight: "bold"
        }}>
          {getContentText('team-title', language === 'en' ? "Built by Language Learning Experts" : "Nyelvtanulási szakértők által készítve")}
        </h2>
        
        <p style={{ 
          fontSize: "1.2rem", 
          margin: "0 auto 40px",
          color: "#666",
          lineHeight: "1.6",
          maxWidth: "600px"
        }}>
          {getContentText('team-description', language === 'en' 
            ? "Our passionate team brings decades of experience in education, AI, and language learning to create VOC2GO."
            : "Szenvedélyes csapatunk évtizedes tapasztalatot hoz az oktatásban, MI-ben és nyelvtanulásban a VOC2GO megalkotásához."
          )}
        </p>

        <button
          onClick={handleTeamClick}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "12px",
            padding: "16px 32px",
            background: "#FF7518",
            color: "white",
            border: "none",
            borderRadius: "12px",
            fontSize: "1.1rem",
            fontWeight: "600",
            cursor: "pointer",
            transition: "all 0.3s ease",
            boxShadow: "0 4px 20px rgba(255, 117, 24, 0.3)"
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "translateY(-2px)";
            e.currentTarget.style.boxShadow = "0 6px 25px rgba(255, 117, 24, 0.4)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "translateY(0)";
            e.currentTarget.style.boxShadow = "0 4px 20px rgba(255, 117, 24, 0.3)";
          }}
        >
          <Users size={20} />
          {getContentText('team-button', language === 'en' ? "Meet Our Expert Team" : "Ismerje meg szakértő csapatunkat")}
        </button>
      </div>
    </section>
  );
};

export default TeamSection;