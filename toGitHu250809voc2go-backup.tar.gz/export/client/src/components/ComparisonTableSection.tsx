import React from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import { Check, X, Star } from "lucide-react";

const ComparisonTableSection: React.FC = () => {
  const { language } = useLanguage();
  const { getContentText } = useContent();

  const features = [
    {
      feature: getContentText('comparison-feature-1', language === 'en' ? "AI-Powered Personalization" : "MI-alapú személyre szabás"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-2', language === 'en' ? "Story-Based Learning" : "Történet-alapú tanulás"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-3', language === 'en' ? "Real-Time Conversation Practice" : "Valós idejű beszélgetésgyakorlat"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-4', language === 'en' ? "Personalized Vocabulary" : "Személyre szabott szókincs"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-5', language === 'en' ? "Learning Science Foundation" : "Tanulástudomány alapok"),
      voc2go: true,
      traditional: true
    },
    {
      feature: getContentText('comparison-feature-6', language === 'en' ? "Mobile App" : "Mobil alkalmazás"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-7', language === 'en' ? "Expert-Led Development" : "Szakértő által vezetett fejlesztés"),
      voc2go: true,
      traditional: true
    },
    {
      feature: getContentText('comparison-feature-8', language === 'en' ? "Learns Your Interests" : "Megtanulja az érdeklődését"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-9', language === 'en' ? "85%+ Retention Rate" : "85%+ megjegyzési arány"),
      voc2go: true,
      traditional: false
    },
    {
      feature: getContentText('comparison-feature-10', language === 'en' ? "No Generic Lessons" : "Nincsenek általános leckék"),
      voc2go: true,
      traditional: false
    }
  ];

  const platforms = [
    { 
      name: getContentText('comparison-platform-1-name', "VOC2GO"), 
      highlight: true, 
      price: getContentText('comparison-platform-1-price', language === 'en' ? "Pay-per-use" : "Használat szerint"),
      description: getContentText('comparison-platform-1-desc', language === 'en' 
        ? "AI-Powered Personal Stories" 
        : "MI-alapú személyes történetek")
    },
    { 
      name: getContentText('comparison-platform-2-name', language === 'en' ? "Traditional Methods" : "Hagyományos módszerek"), 
      highlight: false, 
      price: getContentText('comparison-platform-2-price', language === 'en' ? "High Cost/Monthly" : "Magas költség/Havi"),
      description: getContentText('comparison-platform-2-desc', language === 'en' 
        ? "Classroom/Books/Apps" 
        : "Osztályterem/Könyvek/Alkalmazások")
    }
  ];

  const CheckIcon = ({ checked }: { checked: boolean }) => (
    checked ? (
      <Check size={20} style={{ color: "#4CAF50" }} />
    ) : (
      <X size={20} style={{ color: "#f44336" }} />
    )
  );

  return (
    <section id="comparison">
      {/* Comparison section removed */}
    </section>
  );
};

export default ComparisonTableSection;