import React, { useEffect, useRef, useState } from "react";
import { useLanguage } from "../context/LanguageContext";
import { useContent } from "../hooks/useContent";
import cafeImageS4 from "@assets/S4.jpg";

const VocFutureSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getContentText } = useContent();
  const [isInView, setIsInView] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Content managed through admin system
  const appName = getContentText('voc-future-app-name', "VOC2GO");
  const slogan = getContentText('voc-future-slogan', language === 'en' 
    ? "YOUR WORDS, YOUR STYLE, YOUR ENGLISH" 
    : "A TE SZAVAID, A TE STÍLUSOD, A TE ANGOLOD!");
  
  const description = getContentText('voc-future-description', language === 'en'
    ? "Let's shape the future of language learning together! Join us and help rethink how the world learns languages! Support our campaign on Indiegogo!"
    : "Formáljuk együtt a nyelvtanulás jövőjét. Csatlakozz hozzánk, és segíts újragondolni a nyelvtanulást mindenhol a világon! Támogasd kampányunkat az Indiegogón!");

  // Animation for section entrance
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.2 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <div 
      ref={sectionRef}
      className="voc-future-section"
      style={{ 
        marginTop: '0',
        backgroundColor: '#5C37C7', // Purple background to match site theme
        padding: '60px 0',
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translateY(0)' : 'translateY(30px)',
        transition: 'opacity 0.8s ease-out, transform 0.8s ease-out'
      }}
    >
      <div 
        className="container"
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '40px',
          flexWrap: 'wrap'
        }}
      >
        <div 
          className="content-column"
          style={{
            flex: '1',
            minWidth: '300px',
            maxWidth: '500px',
            padding: '0 20px'
          }}
        >
          <div className="title-container" style={{ textAlign: 'left', marginBottom: '20px' }}>
            <h2 
              style={{ 
                fontSize: '28px',
                fontWeight: 'bold',
                marginBottom: '8px',
                color: 'white',
                textTransform: 'uppercase',
              }}
            >
              {appName}
            </h2>
            <p 
              style={{ 
                fontSize: '18px',
                fontWeight: 'bold',
                color: 'white',
                letterSpacing: '1px',
                textTransform: 'uppercase',
                marginTop: '0'
              }}
            >
              {slogan}
            </p>
          </div>
          <p 
            style={{ 
              fontSize: '16px',
              lineHeight: '1.5',
              color: 'white',
              marginBottom: '30px',
              textAlign: 'left',
              maxWidth: '400px'
            }}
          >
            {description}
          </p>
          <button 
            onClick={() => {
              // Navigate to supporters page
              window.dispatchEvent(new CustomEvent('navigate', { detail: 'supporters' }));
            }}
            className="btn with-shadow"
            style={{
              display: 'inline-block',
              backgroundColor: '#FF7518',
              color: 'white',
              padding: '12px 24px',
              borderRadius: '30px',
              textDecoration: 'none',
              fontWeight: 'bold',
              boxShadow: '0 4px 10px rgba(255, 117, 24, 0.3)',
              transition: 'all 0.3s ease',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            {getContentText('voc-future-button', language === 'en' ? "Join Our Campaign" : "Csatlakozz a kampányunkhoz")}
          </button>
        </div>
        
        <div 
          className="image-column"
          style={{
            flex: '1',
            minWidth: '300px',
            position: 'relative'
          }}
        >
          <img 
            src={cafeImageS4} 
            alt="Voc2Go Community" 
            style={{
              width: '100%',
              borderRadius: '12px',
              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.15)'
            }}
          />
          <div 
            className="image-decoration"
            style={{
              position: 'absolute',
              bottom: '-20px',
              right: '-20px',
              width: '150px',
              height: '150px',
              background: 'linear-gradient(45deg, #5C37C7, rgba(92, 55, 199, 0.3))',
              clipPath: 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)',
              zIndex: -1
            }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default VocFutureSection;