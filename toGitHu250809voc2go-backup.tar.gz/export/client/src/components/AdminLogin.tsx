import React, { useState } from "react";
import { X, Eye, EyeOff, User, Lock, Settings } from "lucide-react";

interface AdminLoginProps {
  onClose: () => void;
  onLogin: (credentials: { loginName: string; password: string }) => void;
  isLoading?: boolean;
  error?: string;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onClose, onLogin, isLoading, error }) => {
  const [loginName, setLoginName] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginName.trim() && password.trim()) {
      onLogin({ loginName: loginName.trim(), password });
    }
  };

  const inputStyle = (fieldName: string) => ({
    width: "100%",
    padding: "12px 16px 12px 40px",
    border: focusedField === fieldName ? "2px solid #5C37C7" : "2px solid rgba(0, 0, 0, 0.1)",
    borderRadius: "8px",
    fontSize: "16px",
    outline: "none",
    backgroundColor: "#fff",
    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
    transform: focusedField === fieldName ? "scale(1.02)" : "scale(1)",
    boxShadow: focusedField === fieldName ? "0 4px 12px rgba(92, 55, 199, 0.15)" : "0 2px 8px rgba(0, 0, 0, 0.1)"
  });

  return (
    <div 
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
        backdropFilter: "blur(4px)"
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        style={{
          background: "white",
          padding: "32px",
          borderRadius: "16px",
          width: "100%",
          maxWidth: "400px",
          margin: "20px",
          boxShadow: "0 20px 60px rgba(0, 0, 0, 0.2)",
          position: "relative",
          animation: "slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
        }}
      >
        <style>
          {`
            @keyframes slideIn {
              from {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
              }
              to {
                opacity: 1;
                transform: translateY(0) scale(1);
              }
            }
          `}
        </style>
        
        <button
          onClick={onClose}
          aria-label="Close admin login"
          style={{
            position: "absolute",
            top: "16px",
            right: "16px",
            background: "transparent",
            border: "none",
            cursor: "pointer",
            padding: "8px",
            borderRadius: "50%",
            transition: "all 0.3s ease",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = "rgba(0, 0, 0, 0.1)";
            e.currentTarget.style.transform = "rotate(90deg)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = "transparent";
            e.currentTarget.style.transform = "rotate(0deg)";
          }}
        >
          <X size={20} color="#666" />
        </button>

        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <div 
            style={{
              width: "60px",
              height: "60px",
              background: "linear-gradient(135deg, #5C37C7, #44d1c6)",
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 16px",
              animation: "pulse 2s infinite"
            }}
          >
            <Settings size={28} color="white" />
          </div>
          <h2 style={{ 
            margin: "0 0 8px", 
            color: "#2D0051",
            fontSize: "24px",
            fontWeight: "700"
          }}>
            Admin Access
          </h2>
          <p style={{ 
            margin: 0, 
            color: "#666",
            fontSize: "14px"
          }}>
            Enter your credentials to access the admin panel
          </p>
        </div>

        {error && (
          <div 
            style={{
              padding: "12px 16px",
              backgroundColor: "#FEF2F2",
              border: "1px solid #FCA5A5",
              borderRadius: "8px",
              marginBottom: "16px",
              color: "#B91C1C",
              fontSize: "14px",
              textAlign: "center"
            }}
            role="alert"
            aria-live="polite"
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "20px", position: "relative" }}>
            <label 
              htmlFor="loginName"
              style={{
                display: "block",
                marginBottom: "8px",
                fontWeight: "600",
                color: "#374151",
                fontSize: "14px"
              }}
            >
              Login Name
            </label>
            <div style={{ position: "relative" }}>
              <User 
                size={18} 
                color="#9CA3AF" 
                style={{
                  position: "absolute",
                  left: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  zIndex: 1
                }}
              />
              <input
                id="loginName"
                type="text"
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                onFocus={() => setFocusedField("loginName")}
                onBlur={() => setFocusedField(null)}
                placeholder="Enter your login name"
                required
                disabled={isLoading}
                style={inputStyle("loginName")}
                autoComplete="username"
              />
            </div>
          </div>

          <div style={{ marginBottom: "24px", position: "relative" }}>
            <label 
              htmlFor="password"
              style={{
                display: "block",
                marginBottom: "8px",
                fontWeight: "600",
                color: "#374151",
                fontSize: "14px"
              }}
            >
              Password
            </label>
            <div style={{ position: "relative" }}>
              <Lock 
                size={18} 
                color="#9CA3AF" 
                style={{
                  position: "absolute",
                  left: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  zIndex: 1
                }}
              />
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onFocus={() => setFocusedField("password")}
                onBlur={() => setFocusedField(null)}
                placeholder="Enter your password"
                required
                disabled={isLoading}
                style={inputStyle("password")}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                style={{
                  position: "absolute",
                  right: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  padding: "4px",
                  borderRadius: "4px",
                  transition: "all 0.2s ease"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "rgba(0, 0, 0, 0.05)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "transparent";
                }}
              >
                {showPassword ? <EyeOff size={18} color="#9CA3AF" /> : <Eye size={18} color="#9CA3AF" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !loginName.trim() || !password.trim()}
            style={{
              width: "100%",
              padding: "12px",
              backgroundColor: isLoading || !loginName.trim() || !password.trim() 
                ? "#D1D5DB" 
                : "#5C37C7",
              color: "white",
              border: "none",
              borderRadius: "8px",
              fontSize: "16px",
              fontWeight: "600",
              cursor: isLoading || !loginName.trim() || !password.trim() ? "not-allowed" : "pointer",
              transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              transform: "scale(1)",
              outline: "none"
            }}
            onMouseEnter={(e) => {
              if (!isLoading && loginName.trim() && password.trim()) {
                e.currentTarget.style.backgroundColor = "#4C1D95";
                e.currentTarget.style.transform = "scale(1.02) translateY(-1px)";
                e.currentTarget.style.boxShadow = "0 8px 20px rgba(92, 55, 199, 0.3)";
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = isLoading || !loginName.trim() || !password.trim() 
                ? "#D1D5DB" 
                : "#5C37C7";
              e.currentTarget.style.transform = "scale(1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            onFocus={(e) => {
              e.currentTarget.style.outline = "2px solid rgba(92, 55, 199, 0.5)";
              e.currentTarget.style.outlineOffset = "2px";
            }}
            onBlur={(e) => {
              e.currentTarget.style.outline = "none";
            }}
          >
            {isLoading ? (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                <div 
                  style={{
                    width: "16px",
                    height: "16px",
                    border: "2px solid rgba(255, 255, 255, 0.3)",
                    borderTop: "2px solid white",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite"
                  }}
                />
                <span>Signing in...</span>
              </div>
            ) : (
              "Sign In"
            )}
          </button>
        </form>

        <style>
          {`
            @keyframes pulse {
              0%, 100% { transform: scale(1); }
              50% { transform: scale(1.05); }
            }
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}
        </style>
      </div>
    </div>
  );
};

export default AdminLogin;