export const colors = {
  primary: {
    dark: '#2D0051',
    DEFAULT: '#5C37C7',
    light: '#C3B7E7'
  },
  teal: {
    dark: '#44A492',
    DEFAULT: '#44d1c6',
    light: '#C4F0EC'
  },
  orange: {
    dark: '#E85C00',
    DEFAULT: '#FF7518',
    light: '#FFA866'
  },
  secondary: {
    blue: '#40A7E8',
    navy: '#375DC7',
    red: '#E83A26',
    green: '#B8D430',
    yellow: '#F5D132',
    pine: '#2D7A89',
    turquoise: '#4FBDB7',
    magenta: '#C23A95'
  }
};
