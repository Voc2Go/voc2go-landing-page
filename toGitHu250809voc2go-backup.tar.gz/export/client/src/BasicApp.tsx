import React, { useState } from 'react';
import logoPath from './assets/logo.png';
import backgroundPath from './assets/background.png';

const BasicApp: React.FC = () => {
  const [language, setLanguage] = useState<'en' | 'hu'>('en');

  const translations = {
    en: {
      title: "VOC2GO - Learn Languages on the Go",
      subtitle: "Making vocabulary acquisition fun, easy, and effective with AI-powered learning techniques.",
      joinCampaign: "Join Our Campaign",
      learnMore: "Learn More",
      emailAddress: "Email Address",
      subscribe: "Subscribe",
      contact: "Contact",
      email: "Email: hello@voc2go.com",
      copyright: "© 2023 VOC2GO. All rights reserved.",
      aboutTitle: "About VOC2GO",
      aboutText: "VOC2GO is a language learning app that helps you acquire vocabulary faster and more effectively. Our AI-powered technology makes learning new words fun and engaging.",
      featuresTitle: "Key Features",
      feature1: "Personalized learning experience",
      feature2: "AI-powered vocabulary acquisition",
      feature3: "Learn anytime, anywhere",
      feature4: "Track your progress",
      campaignTitle: "Support Our Indiegogo Campaign",
      campaignText: "Help us bring VOC2GO to more language learners worldwide. Subscribe to get notified when our campaign launches.",
      notifyMe: "Notify me about the campaign"
    },
    hu: {
      title: "VOC2GO - Tanulj Nyelveket Útközben",
      subtitle: "A szókincstanulás szórakoztatóvá, könnyűvé és hatékonnyá tétele AI-alapú technikákkal.",
      joinCampaign: "Csatlakozz a Kampányhoz",
      learnMore: "Tudj Meg Többet",
      emailAddress: "Email Cím",
      subscribe: "Feliratkozás",
      contact: "Kapcsolat",
      email: "Email: hello@voc2go.com",
      copyright: "© 2023 VOC2GO. Minden jog fenntartva.",
      aboutTitle: "A VOC2GO-ról",
      aboutText: "A VOC2GO egy nyelvtanuló alkalmazás, amely segít gyorsabban és hatékonyabban elsajátítani a szókincset. AI-alapú technológiánk szórakoztatóvá és vonzóvá teszi az új szavak tanulását.",
      featuresTitle: "Főbb Jellemzők",
      feature1: "Személyre szabott tanulási élmény",
      feature2: "AI-alapú szókincsfejlesztés",
      feature3: "Tanulj bárhol, bármikor",
      feature4: "Kövesd a fejlődésed",
      campaignTitle: "Támogasd az Indiegogo Kampányunkat",
      campaignText: "Segíts, hogy a VOC2GO több nyelvtanulóhoz eljuthasson világszerte. Iratkozz fel, hogy értesülj a kampány indulásáról.",
      notifyMe: "Értesítést kérek a kampányról"
    }
  };

  const t = (key: keyof typeof translations.en): string => {
    return translations[language][key];
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hu' : 'en');
  };

  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [subscribeMessage, setSubscribeMessage] = useState<{text: string, isError: boolean} | null>(null);
  
  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubscribeMessage(null);
    
    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, consent: true }),
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSubscribeMessage({ text: 'Thank you for subscribing! We will notify you when the campaign launches.', isError: false });
        setEmail('');
      } else {
        setSubscribeMessage({ text: data.message || 'Failed to subscribe. Please try again.', isError: true });
      }
    } catch (error) {
      setSubscribeMessage({ text: 'Network error. Please check your connection and try again.', isError: true });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Define some common theme colors for the application
  const themeColors = {
    primaryDark: '#2D0051',
    primary: '#5C37C7',
    primaryLight: '#8F74E8',
    teal: '#44d1c6',
    tealLight: '#7EEAE2',
    orange: {
      DEFAULT: '#FF7518',
      dark: '#E85C00',
      light: '#FFA866'
    },
    glass: 'rgba(255, 255, 255, 0.1)',
    glassBorder: 'rgba(255, 255, 255, 0.2)',
    textLight: 'rgba(255, 255, 255, 0.85)',
    success: '#42d578',
    error: '#ff5757'
  };

  return (
    <div style={{ 
      fontFamily: "'Inter', sans-serif", 
      margin: 0, 
      padding: 0,
      backgroundColor: '#2D0051',
      minHeight: '100vh',
      minWidth: '100vw',
      color: 'white',
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0
    }}>
      <div style={{ 
        maxWidth: '1200px', 
        margin: '0 auto', 
        padding: '0 20px'
      }}>
        {/* Header */}
        <header style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          padding: '20px 0',
          flexWrap: 'wrap',
          gap: '15px' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <img 
              src={logoPath} 
              alt="VOC2GO Logo" 
              style={{ 
                height: '60px', 
                marginRight: '15px' 
              }} 
            />
          </div>
          <nav style={{
            display: 'flex',
            alignItems: 'center',
            gap: '25px',
            flexGrow: 1,
            justifyContent: 'center'
          }}>
            {language === 'en' ? (
              <>
                <a href="#" style={{ 
                  color: '#44d1c6', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0',
                  borderBottom: '2px solid #44d1c6'
                }}>HOME</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>LEARNERS</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>SUPPORTERS</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>VOC2GO PROJECT</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>CONTACT</a>
              </>
            ) : (
              <>
                <a href="#" style={{ 
                  color: '#44d1c6', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0',
                  borderBottom: '2px solid #44d1c6'
                }}>FŐOLDAL</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>TANULÓK</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>TÁMOGATÓK</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>VOC2GO PROJEKT</a>
                <a href="#" style={{ 
                  color: 'white', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  padding: '5px 0'
                }}>KAPCSOLAT</a>
              </>
            )}
          </nav>
          <div>
            <button 
              onClick={toggleLanguage}
              style={{ 
                padding: '8px 15px', 
                borderRadius: '20px', 
                border: `1px solid ${themeColors.glassBorder}`, 
                background: themeColors.glass, 
                color: 'white',
                cursor: 'pointer',
                fontWeight: 'bold'
              }}
            >
              {language === 'en' ? 'ANGOL' : 'EN'}
            </button>
          </div>
        </header>

        {/* Hero */}
        <section style={{ 
          padding: '60px 0', 
          textAlign: 'center',
          marginBottom: '40px'
        }}>
          <div style={{ maxWidth: '800px', margin: '0 auto', padding: '0 15px' }}>
            <h1 style={{ 
              fontFamily: "'Poppins', sans-serif", 
              fontSize: 'clamp(2rem, 5vw, 3.2rem)', 
              marginBottom: '20px',
              fontWeight: 'bold',
              lineHeight: '1.2'
            }}>
              {language === 'en' ? (
                <>
                  LEARN ENGLISH<br />
                  WORD BY WORD<br />
                  STORY BY STORY
                </>
              ) : (
                <>
                  SZÓRÓL SZÓRA<br />
                  TÖRTÉNETRŐL TÖRTÉNETRE<br />
                  TANULJ ANGOLUL
                </>
              )}
            </h1>

            
            {/* Video section */}
            <div style={{
              width: '100%',
              maxWidth: '700px',
              margin: '0 auto 40px',
              borderRadius: '12px',
              overflow: 'hidden',
              boxShadow: `0 10px 30px rgba(${parseInt(themeColors.primaryDark.substring(1, 3), 16)}, 
                ${parseInt(themeColors.primaryDark.substring(3, 5), 16)}, 
                ${parseInt(themeColors.primaryDark.substring(5, 7), 16)}, 0.4)`
            }}>
              <div style={{
                position: 'relative',
                paddingBottom: '56.25%', /* 16:9 aspect ratio */
                height: 0,
                overflow: 'hidden'
              }}>
                <iframe 
                  src="https://www.youtube.com/embed/5pNKy7C5USE"
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    border: 'none'
                  }}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="VOC2GO Introduction"
                />
              </div>
            </div>
            
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              gap: '20px',
              flexWrap: 'wrap',
              marginBottom: '50px'
            }}>
              <a 
                href="#campaign" 
                style={{ 
                  background: `linear-gradient(135deg, #FF7518 0%, #E85C00 100%)`, 
                  color: 'white', 
                  padding: '15px 30px', 
                  borderRadius: '50px', 
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
                  transition: 'transform 0.2s, box-shadow 0.2s'
                }}
              >
                {t('joinCampaign')}
              </a>
              <a 
                href="#about" 
                style={{ 
                  background: themeColors.glass, 
                  color: 'white', 
                  padding: '15px 30px', 
                  borderRadius: '50px', 
                  textDecoration: 'none',
                  border: `2px solid #FFA866`,
                  fontWeight: 'bold',
                  backdropFilter: 'blur(5px)',
                  transition: 'transform 0.2s, box-shadow 0.2s'
                }}
              >
                {t('learnMore')}
              </a>
            </div>
            
            {/* Learning scenarios section */}
            <div style={{
              marginTop: '60px',
              marginBottom: '60px'
            }}>
              <h2 style={{
                fontFamily: "'Poppins', sans-serif",
                fontSize: 'clamp(1.8rem, 4vw, 2.2rem)',
                textAlign: 'center',
                marginBottom: '50px'
              }}>
                {language === 'en' ? 'Learn English Anywhere, Anytime' : 'Tanulj Angolul Bárhol, Bármikor'}
              </h2>
              
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                gap: '30px',
                marginTop: '30px'
              }}>
                {/* Card 1 - Café */}
                <div style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderRadius: '15px',
                  overflow: 'hidden',
                  border: `1px solid ${themeColors.glassBorder}`,
                  transition: 'transform 0.3s',
                  boxShadow: '0 5px 15px rgba(0, 0, 0, 0.2)'
                }}>
                  <div style={{
                    height: '200px',
                    background: 'linear-gradient(rgba(92, 55, 199, 0.3), rgba(92, 55, 199, 0.5))',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden',
                    position: 'relative',
                    borderRadius: '8px 8px 0 0',
                  }}>
                    <div style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.4))`,
                      zIndex: 1,
                    }}></div>
                    <div style={{
                      width: '100%',
                      height: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      zIndex: 2,
                    }}>
                      <span style={{
                        color: '#44d1c6', 
                        fontSize: '18px', 
                        fontWeight: 'bold',
                        padding: '10px 20px',
                        background: 'rgba(0, 0, 0, 0.6)',
                        borderRadius: '4px',
                        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
                      }}>
                        {language === 'en' ? 'Friends in a Café' : 'Barátok a kávézóban'}
                      </span>
                    </div>
                  </div>
                  <div style={{padding: '20px'}}>
                    <h3 style={{marginBottom: '10px'}}>{language === 'en' ? 'With Friends' : 'Barátokkal'}</h3>
                    <p style={{color: 'rgba(255, 255, 255, 0.8)', lineHeight: '1.6'}}>
                      {language === 'en' 
                        ? 'Learn over coffee with friends, discussing topics in English' 
                        : 'Tanulj kávézás közben barátaiddal, témákat megvitatva angolul'}
                    </p>
                  </div>
                </div>
                
                {/* Card 2 - Library/Reading */}
                <div style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderRadius: '15px',
                  overflow: 'hidden',
                  border: `1px solid ${themeColors.glassBorder}`,
                  transition: 'transform 0.3s',
                  boxShadow: '0 5px 15px rgba(0, 0, 0, 0.2)'
                }}>
                  <div style={{
                    height: '200px',
                    background: 'linear-gradient(rgba(92, 55, 199, 0.3), rgba(92, 55, 199, 0.5))',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden',
                    position: 'relative',
                    borderRadius: '8px 8px 0 0',
                  }}>
                    <div style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.4))`,
                      zIndex: 1,
                    }}></div>
                    <div style={{
                      width: '100%',
                      height: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      zIndex: 2,
                    }}>
                      <span style={{
                        color: '#44d1c6', 
                        fontSize: '18px', 
                        fontWeight: 'bold',
                        padding: '10px 20px',
                        background: 'rgba(0, 0, 0, 0.6)',
                        borderRadius: '4px',
                        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
                      }}>
                        {language === 'en' ? 'Reading in the Library' : 'Olvasás a könyvtárban'}
                      </span>
                    </div>
                  </div>
                  <div style={{padding: '20px'}}>
                    <h3 style={{marginBottom: '10px'}}>{language === 'en' ? 'While Reading' : 'Olvasás Közben'}</h3>
                    <p style={{color: 'rgba(255, 255, 255, 0.8)', lineHeight: '1.6'}}>
                      {language === 'en' 
                        ? 'Enhance your vocabulary and comprehension through guided reading' 
                        : 'Fejleszd a szókincsedet és a szövegértésedet irányított olvasással'}
                    </p>
                  </div>
                </div>
                
                {/* Card 3 - Cooking */}
                <div style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderRadius: '15px',
                  overflow: 'hidden',
                  border: `1px solid ${themeColors.glassBorder}`,
                  transition: 'transform 0.3s',
                  boxShadow: '0 5px 15px rgba(0, 0, 0, 0.2)'
                }}>
                  <div style={{
                    height: '200px',
                    background: 'linear-gradient(rgba(92, 55, 199, 0.3), rgba(92, 55, 199, 0.5))',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden',
                    position: 'relative',
                    borderRadius: '8px 8px 0 0',
                  }}>
                    <div style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.4))`,
                      zIndex: 1,
                    }}></div>
                    <div style={{
                      width: '100%',
                      height: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      zIndex: 2,
                    }}>
                      <span style={{
                        color: '#44d1c6', 
                        fontSize: '18px', 
                        fontWeight: 'bold',
                        padding: '10px 20px',
                        background: 'rgba(0, 0, 0, 0.6)',
                        borderRadius: '4px',
                        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
                      }}>
                        {language === 'en' ? 'Cooking and Learning' : 'Főzés és tanulás'}
                      </span>
                    </div>
                  </div>
                  <div style={{padding: '20px'}}>
                    <h3 style={{marginBottom: '10px'}}>{language === 'en' ? 'While Cooking' : 'Főzés Közben'}</h3>
                    <p style={{color: 'rgba(255, 255, 255, 0.8)', lineHeight: '1.6'}}>
                      {language === 'en' 
                        ? 'Learn culinary terms and follow recipes in English' 
                        : 'Tanulj konyhai kifejezéseket és kövess angol recepteket'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Why VOC2GO is Different */}
        <section id="about" style={{ 
          marginBottom: '60px', 
          padding: 'clamp(20px, 5vw, 40px)', 
          background: '#2D0051', 
          borderRadius: '20px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
          border: `1px solid ${themeColors.glassBorder}`
        }}>
          <h2 style={{ 
            fontFamily: "'Poppins', sans-serif", 
            textAlign: 'center', 
            marginBottom: '30px',
            fontSize: 'clamp(1.8rem, 4vw, 2.2rem)'
          }}>
            {language === 'en' ? 'Why VOC2GO is Different' : 'Miért más a VOC2GO?'}
          </h2>
          
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '25px',
            marginTop: '30px'
          }}>
            <div style={{
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '25px',
              borderRadius: '15px',
              border: `1px solid ${themeColors.glassBorder}`,
              transition: 'transform 0.2s',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ 
                minWidth: '40px', 
                height: '40px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                color: 'white'
              }}>1</div>
              <div>
                <h4 style={{ 
                  marginBottom: '10px', 
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: '1.1rem',
                  color: '#44d1c6'
                }}>
                  {language === 'en' ? 'Learn Like a Native' : 'Tanulj Anyanyelvi Szinten'}
                </h4>
                <p style={{ color: themeColors.textLight, lineHeight: '1.6' }}>
                  {language === 'en' 
                    ? 'Absorb grammar naturally through context rather than memorising rules'
                    : 'Úgy tanulsz, mint az anyanyelvedet, könnyedén! Természetesen fejlődik az angolod, szabályok magolása nélkül.'}
                </p>
              </div>
            </div>
            
            <div style={{
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '25px',
              borderRadius: '15px',
              border: `1px solid ${themeColors.glassBorder}`,
              transition: 'transform 0.2s',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ 
                minWidth: '40px', 
                height: '40px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                color: 'white'
              }}>2</div>
              <div>
                <h4 style={{ 
                  marginBottom: '10px', 
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: '1.1rem',
                  color: '#44d1c6'
                }}>
                  {language === 'en' ? 'Personalised Learning' : 'Személyre Szabott Tanulás'}
                </h4>
                <p style={{ color: themeColors.textLight, lineHeight: '1.6' }}>
                  {language === 'en' 
                    ? 'Content adapts to your interests, pace, and progress'
                    : 'Rád szabjuk a tanulásodat! A leckék hozzád igazodnak, az érdeklődésedhez és a tempódhoz.'}
                </p>
              </div>
            </div>
            
            <div style={{
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '25px',
              borderRadius: '15px',
              border: `1px solid ${themeColors.glassBorder}`,
              transition: 'transform 0.2s',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ 
                minWidth: '40px', 
                height: '40px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                color: 'white'
              }}>3</div>
              <div>
                <h4 style={{ 
                  marginBottom: '10px', 
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: '1.1rem',
                  color: '#44d1c6'
                }}>
                  {language === 'en' ? 'Bite-Sized Sessions' : 'Könnyen Emészthető Leckék'}
                </h4>
                <p style={{ color: themeColors.textLight, lineHeight: '1.6' }}>
                  {language === 'en' 
                    ? 'Fit learning into your busy schedule with flexible 30-minute sessions'
                    : 'Rövid és könnyen napirendedbe illeszthető gyakorlást nyújtunk, napi 30 perc is elég a fejlődéshez.'}
                </p>
              </div>
            </div>
            
            <div style={{
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '25px',
              borderRadius: '15px',
              border: `1px solid ${themeColors.glassBorder}`,
              transition: 'transform 0.2s',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ 
                minWidth: '40px', 
                height: '40px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                color: 'white'
              }}>4</div>
              <div>
                <h4 style={{ 
                  marginBottom: '10px', 
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: '1.1rem',
                  color: '#44d1c6'
                }}>
                  {language === 'en' ? 'Retention That Sticks' : 'Hosszú Távú Emlékezet'}
                </h4>
                <p style={{ color: themeColors.textLight, lineHeight: '1.6' }}>
                  {language === 'en' 
                    ? 'Each session creates custom learning cards with vocabulary, story highlights, and memory-boosting images'
                    : 'Megmarad a tudásod, mert tanulókártyák, történetek és képes memóriakártyákat adunk.'}
                </p>
              </div>
            </div>
            
            <div style={{
              background: 'rgba(255, 255, 255, 0.05)',
              padding: '25px',
              borderRadius: '15px',
              border: `1px solid ${themeColors.glassBorder}`,
              transition: 'transform 0.2s',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ 
                minWidth: '40px', 
                height: '40px',
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: 'bold',
                color: 'white'
              }}>5</div>
              <div>
                <h4 style={{ 
                  marginBottom: '10px', 
                  fontFamily: "'Poppins', sans-serif",
                  fontSize: '1.1rem',
                  color: '#44d1c6'
                }}>
                  {language === 'en' ? 'Life Currency' : 'Életbeli Érték'}
                </h4>
                <p style={{ color: themeColors.textLight, lineHeight: '1.6' }}>
                  {language === 'en' 
                    ? 'Just like money in your wallet, English opens doors and creates opportunities wherever you go'
                    : 'Az angolod lesz a valutád, hiszen új ajtókat nyit és lehetőségeket teremt bárhol a világban!'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Campaign */}
        <section id="campaign" style={{ 
          marginBottom: '60px', 
          padding: 'clamp(20px, 5vw, 40px)', 
          background: '#2D0051', 
          borderRadius: '20px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
          border: `1px solid ${themeColors.glassBorder}`
        }}>
          <h2 style={{ 
            fontFamily: "'Poppins', sans-serif", 
            textAlign: 'center', 
            marginBottom: '30px',
            fontSize: 'clamp(1.8rem, 4vw, 2.2rem)'
          }}>
            {t('campaignTitle')}
          </h2>
          <p style={{
            fontSize: '1.1rem',
            lineHeight: '1.7',
            marginBottom: '30px',
            textAlign: 'center',
            color: themeColors.textLight
          }}>
            {t('campaignText')}
          </p>
          <form onSubmit={handleSubscribe} style={{ maxWidth: '500px', margin: '0 auto' }}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold' }}>
                {t('emailAddress')}
              </label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isSubmitting}
                placeholder="you@example.com"
                style={{ 
                  width: '100%', 
                  padding: '15px', 
                  borderRadius: '10px', 
                  border: `1px solid ${themeColors.glassBorder}`,
                  background: 'rgba(255, 255, 255, 0.05)',
                  color: 'white',
                  boxSizing: 'border-box',
                  fontSize: '1rem'
                }}
              />
            </div>
            
            {subscribeMessage && (
              <div style={{ 
                padding: '12px', 
                marginBottom: '20px', 
                borderRadius: '8px',
                backgroundColor: subscribeMessage.isError ? 'rgba(255, 87, 87, 0.1)' : 'rgba(66, 213, 120, 0.1)',
                borderLeft: `4px solid ${subscribeMessage.isError ? themeColors.error : themeColors.success}`,
                color: 'white'
              }}>
                {subscribeMessage.text}
              </div>
            )}
            
            <button 
              type="submit"
              disabled={isSubmitting}
              style={{ 
                background: isSubmitting 
                  ? `rgba(92, 55, 199, 0.7)` 
                  : `linear-gradient(135deg, ${themeColors.primary} 0%, ${themeColors.teal} 100%)`, 
                color: 'white', 
                padding: '15px 25px', 
                borderRadius: '50px', 
                border: 'none',
                width: '100%',
                fontWeight: 'bold',
                cursor: isSubmitting ? 'default' : 'pointer',
                fontSize: '1rem',
                boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                transition: 'transform 0.2s, box-shadow 0.2s'
              }}
            >
              {isSubmitting ? (
                <span style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ 
                    width: '18px', 
                    height: '18px', 
                    border: '3px solid rgba(255, 255, 255, 0.3)',
                    borderTop: '3px solid white',
                    borderRadius: '50%',
                    marginRight: '10px',
                    animation: 'spin 1s linear infinite'
                  }}></span>
                  Submitting...
                </span>
              ) : t('notifyMe')}
            </button>
            
            <style>
              {`
                @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
                }
                
                a:hover, button:hover:not(:disabled) {
                  transform: translateY(-2px);
                  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
                }
                
                a:active, button:active:not(:disabled) {
                  transform: translateY(1px);
                }
                
                div[style*="transition: transform"] {
                  transition: transform 0.2s ease-in-out;
                }
                
                div[style*="transition: transform"]:hover {
                  transform: translateY(-5px);
                }
              `}
            </style>
          </form>
        </section>

        {/* Footer */}
        <footer style={{ 
          borderTop: `1px solid ${themeColors.glassBorder}`, 
          padding: '30px 0',
          marginTop: '40px'
        }}>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            flexWrap: 'wrap',
            marginBottom: '20px'
          }}>
            <div>
              <img 
                src={logoPath} 
                alt="VOC2GO Logo" 
                style={{ 
                  height: '40px', 
                  marginBottom: '15px' 
                }} 
              />
            </div>
            <div>
              <h4 style={{ fontFamily: "'Poppins', sans-serif" }}>{t('contact')}</h4>
              <p style={{ color: themeColors.textLight }}>{t('email')}</p>
            </div>
          </div>
          <p style={{ 
            textAlign: 'center', 
            marginTop: '30px', 
            color: 'rgba(255, 255, 255, 0.7)', 
            fontSize: '0.9rem' 
          }}>
            {t('copyright')}
          </p>
        </footer>
      </div>
    </div>
  );
};

export default BasicApp;