import React, { useState, useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { LanguageProvider } from "./context/LanguageContext";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import FeaturesSection from "./components/FeaturesSection";
import AppScreenshotsSection from "./components/AppScreenshotsSection";
import PlanComparisonSection from "./components/PlanComparisonSection";
import VocFutureSection from "./components/VocFutureSection";
import LearnersSection from "./components/LearnersSection";
import PayAsYouGoSection from "./components/PayAsYouGoSection";
import PersonasSection from "./components/PersonasSection";
import VocCampaignSection from "./components/VocCampaignSection";
import ProjectTeamSection from "./components/ProjectTeamSection";
import OurTeamSection from "./components/OurTeamSection";
import CampaignSection from "./components/CampaignSection";
import RoadmapSection from "./components/RoadmapSection";
import FeedbackSection from "./components/FeedbackSection";
import WhyChooseSection from "./components/WhyChooseSection";
import TeamSection from "./components/TeamSection";
import TestimonialsSection from "./components/TestimonialsSection";
import CountdownTimer from "./components/CountdownTimer";
import ComparisonTableSection from "./components/ComparisonTableSection";
import FAQSection from "./components/FAQSection";
import SupportSection from "./components/SupportSection";
import CampaignButtonSection from "./components/CampaignButtonSection";
import MobileTestPage from "./components/MobileTestPage";
import AdminTestPanel from "./components/AdminTestPanel";
import TestSummary from "./components/TestSummary";
import VisionSection from "./components/VisionSection";
import Footer from "./components/Footer";
import AdminOverlay from "./components/AdminOverlay";
import AdminLogin from "./components/AdminLogin";
import AdminPanel from "./components/AdminPanel";

// Import styles
import "./styles/main.css";
import "./styles/admin-overlay.css";

function App() {
  const [showAdmin, setShowAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminLoginLoading, setAdminLoginLoading] = useState(false);
  const [adminLoginError, setAdminLoginError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState("home");
  const [showMobileTest, setShowMobileTest] = useState(false);
  const [showAdminTest, setShowAdminTest] = useState(false);
  
  const handleOpenAdmin = () => {
    setShowAdminLogin(true);
  };
  
  const handleCloseAdminLogin = () => {
    setShowAdminLogin(false);
    setAdminLoginError(null);
  };

  const handleAdminLogin = async (credentials: { loginName: string; password: string }) => {
    setAdminLoginLoading(true);
    setAdminLoginError(null);
    
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(credentials)
      });

      if (response.ok) {
        setShowAdminLogin(false);
        setShowAdminPanel(true);
      } else {
        const data = await response.json();
        setAdminLoginError(data.error || 'Login failed');
      }
    } catch (error) {
      setAdminLoginError('Network error. Please try again.');
    } finally {
      setAdminLoginLoading(false);
    }
  };

  const handleCloseAdminPanel = () => {
    setShowAdminPanel(false);
  };
  
  // Function to handle hash changes for navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      
      // Scroll to top when changing pages
      window.scrollTo(0, 0);
      
      if (hash === "campaign") {
        setCurrentPage("supporters");
      } else if (hash === "plans" || hash === "features" || hash === "learners") {
        setCurrentPage("learners");
      } else if (hash === "voc2go-project" || hash === "roadmap") {
        setCurrentPage("project");
      } else if (hash === "feedback") {
        setCurrentPage("contact");
      } else {
        setCurrentPage("home");
      }
    };
    
    // Add keyboard shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'm') {
        e.preventDefault();
        setShowMobileTest(true);
      }
      if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        setShowAdminTest(true);
      }
    };
    
    // Set initial page based on hash
    handleHashChange();
    
    // Listen for hash changes and custom navigation events
    const handleNavigate = (e: CustomEvent) => {
      setCurrentPage(e.detail);
    };
    
    window.addEventListener("hashchange", handleHashChange);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("navigate", handleNavigate as EventListener);
    
    return () => {
      window.removeEventListener("hashchange", handleHashChange);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("navigate", handleNavigate as EventListener);
    };
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <div className="voc2go-app">
        <Header />
        <main>
          {/* HOME menu content */}
          {(currentPage === "home") && (
            <>
              <HeroSection />
              <WhyChooseSection />
              <TeamSection />
              <TestimonialsSection />
              <ComparisonTableSection />
              <FAQSection />
              <PlanComparisonSection />
              <OurTeamSection />
              <VocFutureSection />
            </>
          )}
          
          {/* LEARNERS menu content */}
          {(currentPage === "learners") && (
            <>
              <LearnersSection />
            </>
          )}
          
          {/* SUPPORTERS menu content */}
          {(currentPage === "supporters") && (
            <>
              <VisionSection />
              <div style={{ padding: "0 20px" }}>
                <CountdownTimer />
              </div>
              <SupportSection />
            </>
          )}
          
          {/* PROJECT menu content */}
          {(currentPage === "project") && (
            <>
              <ProjectTeamSection />
              <CampaignButtonSection />
            </>
          )}
          
          {/* CONTACT menu content */}
          {(currentPage === "contact") && (
            <>
              <FeedbackSection />
            </>
          )}
        </main>
        <Footer onAdminClick={handleOpenAdmin} />
        
        {/* Admin overlay appears when showAdmin is true */}
        {showAdmin && <AdminOverlay onClose={() => setShowAdmin(false)} />}
        
        {/* Mobile Test Page */}
        {showMobileTest && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            background: 'white',
            zIndex: 10000,
            overflow: 'auto'
          }}>
            <div style={{
              position: 'sticky',
              top: 0,
              background: 'white',
              padding: '10px 20px',
              borderBottom: '1px solid #ddd',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <h3>Mobile Responsivity Test</h3>
              <button 
                onClick={() => setShowMobileTest(false)}
                style={{
                  background: '#f44336',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Close
              </button>
            </div>
            <MobileTestPage />
          </div>
        )}

        {/* Admin Test Panel */}
        {showAdminTest && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            background: 'white',
            zIndex: 10000,
            overflow: 'auto'
          }}>
            <div style={{
              position: 'sticky',
              top: 0,
              background: 'white',
              padding: '10px 20px',
              borderBottom: '1px solid #ddd',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <h3>Admin Functionality Test</h3>
              <button 
                onClick={() => setShowAdminTest(false)}
                style={{
                  background: '#f44336',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Close
              </button>
            </div>
            <AdminTestPanel />
          </div>
        )}

        {/* Admin Login Modal */}
        {showAdminLogin && (
          <AdminLogin
            onClose={handleCloseAdminLogin}
            onLogin={handleAdminLogin}
            isLoading={adminLoginLoading}
            error={adminLoginError}
          />
        )}

        {/* Admin Panel */}
        {showAdminPanel && (
          <AdminPanel onClose={handleCloseAdminPanel} />
        )}

        {/* Development Testing Tools */}
        {process.env.NODE_ENV === 'development' && <TestSummary />}
      </div>
    </LanguageProvider>
  </QueryClientProvider>
  );
}

export default App;
