import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define available languages
type Language = 'en' | 'hu';

// Define translations interface
interface TranslationDictionary {
  [key: string]: string;
}

// Define the context structure
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

// Translations for both languages
const translations: Record<Language, TranslationDictionary> = {
  en: {
    // Navigation
    "Features": "Features",
    "Roadmap": "Roadmap",
    "Campaign": "Campaign",
    "Feedback": "Feedback",
    "Support Us": "Support Us",
    "Support Our Campaign": "Support Our Campaign",
    
    // Hero Section
    "Learn Languages on the Go": "Learn Languages on the Go",
    "VOC2GO makes vocabulary acquisition fun, easy, and effective with AI-powered learning techniques.": 
      "VOC2GO makes vocabulary acquisition fun, easy, and effective with AI-powered learning techniques.",
    "Join Our Campaign": "Join Our Campaign",
    "Learn More": "Learn More",
    "Coming Soon!": "Coming Soon!",
    
    // Features Section
    "Why Choose VOC2GO?": "Why Choose VOC2GO?",
    "Discover how our app makes language learning effective and enjoyable": 
      "Discover how our app makes language learning effective and enjoyable",
    "AI-Powered Learning": "AI-Powered Learning",
    "Our AI adapts to your learning style and creates personalized study plans": 
      "Our AI adapts to your learning style and creates personalized study plans",
    "Real-Life Contexts": "Real-Life Contexts",
    "Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios": 
      "Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios",
    "Spaced Repetition": "Spaced Repetition",
    "Our scientifically-proven system ensures you remember words for the long term": 
      "Our scientifically-proven system ensures you remember words for the long term",
    "Progress Tracking": "Progress Tracking",
    "Track your learning journey with detailed statistics and achievements": 
      "Track your learning journey with detailed statistics and achievements",
    
    // Screenshots Section
    "App Screenshots": "App Screenshots",
    "Take a sneak peek at VOC2GO's intuitive interface": "Take a sneak peek at VOC2GO's intuitive interface",
    "Café Scene": "Café Scene",
    "Learn vocabulary in a virtual café environment": "Learn vocabulary in a virtual café environment",
    "Library Mode": "Library Mode",
    "Browse through categories and learn at your own pace": "Browse through categories and learn at your own pace",
    "Cooking Context": "Cooking Context",
    "Master kitchen-related terms through interactive lessons": "Master kitchen-related terms through interactive lessons",
    
    // Campaign Section
    "Join Our Indiegogo Campaign": "Join Our Indiegogo Campaign",
    "Help us bring VOC2GO to life and get exclusive rewards": "Help us bring VOC2GO to life and get exclusive rewards",
    "Early Bird Access": "Early Bird Access",
    "Get the app before everyone else": "Get the app before everyone else",
    "Premium Supporter": "Premium Supporter",
    "Lifetime access to premium features": "Lifetime access to premium features",
    "Language Bundle": "Language Bundle",
    "Access to all language packs": "Access to all language packs",
    "Limited to first 100 backers": "Limited to first 100 backers",
    "Only 50 spots available": "Only 50 spots available",
    "Unlimited availability": "Unlimited availability",
    
    // Roadmap Section
    "Development Roadmap": "Development Roadmap",
    "Our journey to create the ultimate language learning app": "Our journey to create the ultimate language learning app",
    "Research Phase": "Research Phase",
    "Researching effective learning methods and user needs": "Researching effective learning methods and user needs",
    "Completed": "Completed",
    "Development Phase": "Development Phase",
    "Building the core features and user interface": "Building the core features and user interface",
    "In Progress": "In Progress",
    "Testing Phase": "Testing Phase",
    "Beta testing with real users to improve the experience": "Beta testing with real users to improve the experience",
    "Planned": "Planned",
    "Launch Phase": "Launch Phase",
    "Official release and marketing campaign": "Official release and marketing campaign",
    
    // Testimonials Section
    "User Feedback": "User Feedback",
    "What our beta testers are saying": "What our beta testers are saying",
    "VOC2GO has revolutionized how I learn new words. The contextual learning is brilliant!": 
      "VOC2GO has revolutionized how I learn new words. The contextual learning is brilliant!",
    "The app's adaptive system feels like having a personal language tutor in my pocket.": 
      "The app's adaptive system feels like having a personal language tutor in my pocket.",
    "I've tried many language apps, but VOC2GO's approach to vocabulary acquisition is unique and effective.": 
      "I've tried many language apps, but VOC2GO's approach to vocabulary acquisition is unique and effective.",
    "Software Developer": "Software Developer",
    "Language Teacher": "Language Teacher",
    "University Student": "University Student",
    
    // Newsletter Section
    "Stay Updated": "Stay Updated",
    "Subscribe to our newsletter for campaign updates": "Subscribe to our newsletter for campaign updates",
    "Email Address": "Email Address",
    "Subscribe": "Subscribe",
    "Thanks for subscribing!": "Thanks for subscribing!",
    
    // Footer
    "Contact": "Contact",
    "Email: hello@voc2go.com": "Email: hello@voc2go.com",
    "Follow Us": "Follow Us",
    "Legal": "Legal",
    "Terms of Use": "Terms of Use",
    "Privacy Policy": "Privacy Policy",
    "Cookie Policy": "Cookie Policy",
    "© 2025 Voc2Go by Circular Innovation Hub. All rights reserved.": "© 2025 Voc2Go by Circular Innovation Hub. All rights reserved.",
    
    // Admin Content Management
    "Content": "Content",
    "Content Management": "Content Management",
    "Manage Content": "Manage Content",
    "English": "English",
    "Hungarian": "Hungarian",
    "Save Changes": "Save Changes",
    "Cancel": "Cancel",
    "Website Content": "Website Content",
    "Manage and edit content for different sections of your website in both English and Hungarian.": "Manage and edit content for different sections of your website in both English and Hungarian.",
    "Hero Section": "Hero Section",
    "Edit main headline, subheadline, and call-to-action buttons": "Edit main headline, subheadline, and call-to-action buttons",
    "Features Section": "Features Section",
    "Edit feature headings, descriptions, and benefits": "Edit feature headings, descriptions, and benefits",
    "Vision Section": "Vision Section",
    "Edit vision statement, market information, and goals": "Edit vision statement, market information, and goals",
    "Campaign Section": "Campaign Section",
    "Edit campaign details, rewards, and pricing": "Edit campaign details, rewards, and pricing",
    "Edit": "Edit",
    "Manage All Content": "Manage All Content",
    "Language Settings": "Language Settings",
    "Manage translations and language options for your website.": "Manage translations and language options for your website.",
    "Current languages supported": "Current languages supported",
    "Manage Translations": "Manage Translations",
    "Website published successfully!": "Website published successfully!"
  },
  hu: {
    // Navigation
    "Features": "Funkciók",
    "Roadmap": "Ütemterv",
    "Campaign": "Kampány",
    "Feedback": "Visszajelzés",
    "Support Us": "Támogass Minket",
    "Support Our Campaign": "Támogasd a Kampányunkat",
    "Legal": "Jogi információk",
    "Terms of Use": "Felhasználási Feltételek",
    "Privacy Policy": "Adatvédelmi Szabályzat",
    "Cookie Policy": "Süti Szabályzat",
    
    // Contact Form
    "Send Us Your Thoughts": "Küldd El Gondolataidat",
    "We value your feedback to improve our app": "Nagyra értékeljük a visszajelzéseidet",
    "Your Name": "Neved",
    "Email Address": "Email Cím",
    "Your Message": "Üzeneted",
    "How excited are you about VOC2GO?": "Mennyire vagy lelkes?",
    "optional": "opcionális",
    "Enter your name": "Add meg a neved",
    "Enter your email": "Add meg az email címed",
    "Enter your message or suggestion": "Add meg üzeneted vagy javaslatod",
    "Very Excited": "Nagyon",
    "Excited": "Lelkes",
    "Somewhat Excited": "Valamennyire", 
    "Slightly Excited": "Kicsit",
    "Not Excited": "Nem mozgat meg",
    "Submit Feedback": "Visszajelzés Küldése",
    "Thank you for your feedback!": "Köszönjük a visszajelzést!",
    "Your message has been submitted successfully.": "Üzeneted sikeresen elküldve.",
    
    // Form validation messages
    "Please fill in this field": "Kérjük, töltsd ki ezt a mezőt",
    "Please enter a valid email address": "Kérjük, adj meg egy érvényes email címet",
    "This field is required": "Ez a mező kötelező",
    
    // Hero Section
    "Learn Languages on the Go": "Tanulj Nyelveket Útközben",
    "VOC2GO makes vocabulary acquisition fun, easy, and effective with AI-powered learning techniques.": 
      "Voc2Go szórakoztató, könnyű és hatékony szókincs tanuló társ, MI segítséggel.",
    "Revolutionary AI-powered English vocabulary learning through personalized stories and real conversations. Experience 3x faster learning with 85% retention rate.": 
      "Forradalmi MI-alapú angol szókincstanulás személyre szabott történeteken és valós beszélgetéseken keresztül. Tapasztaljon 3x gyorsabb tanulást 85%-os megjegyzési aránnyal.",
    "Join Our Campaign": "Csatlakozz a Kampányhoz",
    "Support Our Campaign Now": "Támogasd a Kampányunkat Most",
    "Meet Our Team": "Ismerje meg csapatunkat",
    "Learn More": "Tudj Meg Többet",
    "Coming Soon!": "Hamarosan!",
    
    // Features Section
    "Why Choose VOC2GO?": "Miért Válaszd a VOC2GO-t?",
    "Discover how our app makes language learning effective and enjoyable": 
      "Fedezd fel, hogyan teszi applikációnk hatékonnyá és élvezetessé a nyelvtanulást",
    "AI-Powered Learning": "AI-Alapú Tanulás",
    "Our AI adapts to your learning style and creates personalized study plans": 
      "Az AI-nk alkalmazkodik a tanulási stílusodhoz és személyre szabott tanulási tervet készít",
    "Real-Life Contexts": "Valós Élethelyzetek",
    "Learn vocabulary in meaningful contexts like cafés, libraries, and travel scenarios": 
      "Tanulj szókincset értelmes környezetben, mint kávézók, könyvtárak és utazási helyzetek",
    "Spaced Repetition": "Időzített Ismétlés",
    "Our scientifically-proven system ensures you remember words for the long term": 
      "Tudományosan bizonyított rendszerünk biztosítja, hogy hosszú távon emlékezz a szavakra",
    "Progress Tracking": "Haladás Követése",
    "Track your learning journey with detailed statistics and achievements": 
      "Kövesd tanulási utadat részletes statisztikákkal és eredményekkel",
    
    // Screenshots Section
    "App Screenshots": "Alkalmazás Képernyőképek",
    "Take a sneak peek at VOC2GO's intuitive interface": "Vess egy pillantást a VOC2GO intuitív felületére",
    "Café Scene": "Kávézó Jelenet",
    "Learn vocabulary in a virtual café environment": "Tanulj szókincset egy virtuális kávézó környezetben",
    "Library Mode": "Könyvtár Mód",
    "Browse through categories and learn at your own pace": "Böngéssz a kategóriák között és tanulj a saját tempódban",
    "Cooking Context": "Főzési Környezet",
    "Master kitchen-related terms through interactive lessons": "Sajátítsd el a konyhával kapcsolatos kifejezéseket interaktív leckéken keresztül",
    
    // Campaign Section
    "Join Our Indiegogo Campaign": "Csatlakozz az Indiegogo Kampányunkhoz",
    "Help us bring VOC2GO to life and get exclusive rewards": "Segíts életre kelteni a VOC2GO-t és szerezz exkluzív jutalmakat",
    "Visit Our Indiegogo Page": "Látogasd meg az Indiegogo Oldalunkat",
    "Give Us Feedback": "Adj Visszajelzést",
    "Early Bird Access": "Korai Hozzáférés",
    "Get the app before everyone else": "Kapd meg az alkalmazást mindenki más előtt",
    "Premium Supporter": "Prémium Támogató",
    "Lifetime access to premium features": "Élethosszig tartó hozzáférés a prémium funkciókhoz",
    "Language Bundle": "Nyelvi Csomag",
    "Access to all language packs": "Hozzáférés minden nyelvi csomaghoz",
    "Limited to first 100 backers": "Az első 100 támogatóra korlátozva",
    "Only 50 spots available": "Csak 50 hely elérhető",
    "Unlimited availability": "Korlátlan elérhetőség",
    
    // Roadmap Section
    "Development Roadmap": "Fejlesztési Ütemterv",
    "Our journey to create the ultimate language learning app": "Utunk a tökéletes nyelvtanuló alkalmazás létrehozásához",
    "Research Phase": "Kutatási Szakasz",
    "Researching effective learning methods and user needs": "Hatékony tanulási módszerek és felhasználói igények kutatása",
    "Completed": "Befejezve",
    "Development Phase": "Fejlesztési Szakasz",
    "Building the core features and user interface": "Alapfunkciók és felhasználói felület kiépítése",
    "In Progress": "Folyamatban",
    "Testing Phase": "Tesztelési Szakasz",
    "Beta testing with real users to improve the experience": "Béta tesztelés valódi felhasználókkal a tapasztalat javítására",
    "Planned": "Tervezett",
    "Launch Phase": "Indítási Szakasz",
    "Official release and marketing campaign": "Hivatalos kiadás és marketing kampány",
    
    // Testimonials Section
    "User Feedback": "Felhasználói Visszajelzések",
    "What our beta testers are saying": "Mit mondanak a béta tesztelőink",
    "VOC2GO has revolutionized how I learn new words. The contextual learning is brilliant!": 
      "A VOC2GO forradalmasította, ahogyan új szavakat tanulok. A kontextuális tanulás briliáns!",
    "The app's adaptive system feels like having a personal language tutor in my pocket.": 
      "Az alkalmazás adaptív rendszere olyan, mintha egy személyes nyelvtanár lenne a zsebemben.",
    "I've tried many language apps, but VOC2GO's approach to vocabulary acquisition is unique and effective.": 
      "Sok nyelvi alkalmazást kipróbáltam már, de a VOC2GO szókincselsajátítási megközelítése egyedi és hatékony.",
    "Software Developer": "Szoftverfejlesztő",
    "Language Teacher": "Nyelvtanár",
    "University Student": "Egyetemi Hallgató",
    
    // Newsletter Section
    "Stay Updated": "Maradj Naprakész",
    "Subscribe to our newsletter for campaign updates": "Iratkozz fel hírlevelünkre a kampányfrissítésekért",
    "Subscribe to our newsletter for campaign updates and be the first to know when we launch": "Iratkozz fel hírlevelünkre a kampány frissítéseiért és légy az első, aki értesül az indulásról",
    "Enter your email address": "Add meg az email címed",
    "Subscribe": "Feliratkozás",
    "Thanks for subscribing!": "Köszönjük a feliratkozást!",
    
    // Footer
    "Contact": "Kapcsolat",
    "Email: hello@voc2go.com": "Email: voc2go@gmail.com",
    "Follow Us": "Kövess Minket",
    "© 2023 VOC2GO. All rights reserved.": "© 2023 VOC2GO. Minden jog fenntartva.",
    
    // Admin Content Management
    "Content": "Tartalom",
    "Content Management": "Tartalom Kezelés",
    "Manage Content": "Tartalom Kezelése",
    "English": "Angol",
    "Hungarian": "Magyar",
    "Save Changes": "Változtatások Mentése",
    "Cancel": "Mégse",
    "Website Content": "Weboldal Tartalma",
    "Manage and edit content for different sections of your website in both English and Hungarian.": "Kezeld és szerkeszd a weboldal különböző részeinek tartalmát angol és magyar nyelven.",
    "Hero Section": "Főoldal Szekció",
    "Edit main headline, subheadline, and call-to-action buttons": "Főcím, alcím és akciógombok szerkesztése",
    "Features Section": "Funkciók Szekció",
    "Edit feature headings, descriptions, and benefits": "Funkciók címeinek, leírásainak és előnyeinek szerkesztése",
    "Vision Section": "Jövőkép Szekció",
    "Edit vision statement, market information, and goals": "Jövőkép, piaci információk és célok szerkesztése",
    "Campaign Section": "Kampány Szekció",
    "Edit campaign details, rewards, and pricing": "Kampány részleteinek, jutalmainak és árazásának szerkesztése",
    "Edit": "Szerkesztés",
    "Manage All Content": "Összes Tartalom Kezelése",
    "Language Settings": "Nyelvi Beállítások",
    "Manage translations and language options for your website.": "Kezelje a weboldal fordításait és nyelvi beállításait.",
    "Current languages supported": "Jelenleg támogatott nyelvek",
    "Manage Translations": "Fordítások Kezelése",
    "Website published successfully!": "A weboldal sikeresen publikálva!"
  }
};

// Create the context with default values
const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key) => key,
});

// Provider component
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  // Translation function
  const t = (key: string): string => {
    const langTranslations = translations[language];
    return langTranslations[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook for using the language context
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Export translations for use outside the context if needed
export { translations };