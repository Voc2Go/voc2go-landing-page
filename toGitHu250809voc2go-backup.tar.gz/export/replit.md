# Voc2Go Landing Page

## Overview
Voc2Go is a comprehensive bilingual (English/Hungarian) language learning application with a feature-rich landing page supporting an Indiegogo crowdfunding campaign. The application provides a modern, interactive experience featuring advanced content management, team social media integration, newsletter subscriptions, feedback collection, and robust administrative controls. Built with cutting-edge web technologies, it serves as both a campaign platform and foundation for future expansion into a full-fledged AI-powered language learning ecosystem.

## User Preferences
Preferred communication style: Simple, everyday language. Concise responses without wordy instructions.

## System Architecture

### Frontend
- **Technology Stack**: React with TypeScript, Tailwind CSS for styling, Vite for build processes.
- **State Management**: Context API for global state and language switching.
- **Data Fetching**: TanStack Query for efficient API interactions.
- **UI/UX**: Utilizes Shadcn/UI for components, emphasizes responsive design with a mobile-first approach, smooth animations, and accessibility (ARIA-compliant, keyboard navigation).

### Backend
- **Technology Stack**: Express.js with TypeScript.
- **API**: RESTful API design.
- **Authentication**: JWT for secure admin access with centralized token management.
- **Security**: Secure JWT utility (`server/utils/jwt.js`) prevents hardcoded secrets and enforces production environment validation.
- **File Management**: Handles media file uploads.
- **Cross-Origin**: CORS enabled for client-server communication.

### Data Layer
- **ORM**: Drizzle ORM for type-safe database operations.
- **Database**: PostgreSQL, specifically using Neon for serverless hosting.
- **Schema**: Shared schema (`shared/schema.ts`) for consistent data types across frontend and backend.

### Key Features
- **Bilingual Support**: Comprehensive English/Hungarian language toggle with dynamic content switching.
- **Advanced Admin Panel**: Full-featured content management system with:
  - Hungarian naming conventions for intuitive interface
  - Content filtering by page and section
  - Live preview functionality
  - Team member social media management (8 platforms)
  - Secure authentication with JWT tokens
- **Team Social Media Integration**: Complete management system supporting:
  - Instagram, Facebook, LinkedIn, Behance, Ko-fi
  - Pinterest, X (Twitter), Website links
  - Authentic brand icons and colors
  - Conditional display (only shows platforms with saved links)
- **Campaign Management**: Presentation and tracking of crowdfunding campaign details.
- **Newsletter System**: Email collection with duplicate prevention and integrated content management.
- **Feedback & Support**: System for user feedback and support queries.
- **Media Management**: Functionality for image upload and storage.
- **Branding**: Consistent "Voc2Go" branding across the application.
- **SEO & Marketing**: Comprehensive optimization including Open Graph, Twitter meta tags, JSON-LD structured data, and targeted content for search engines and campaign promotion.

## External Dependencies

### Core Technologies
- **React 18**: Frontend library.
- **TypeScript**: For type safety across the application.
- **Tailwind CSS**: Utility-first CSS framework.
- **Drizzle ORM**: Database toolkit.
- **Express.js**: Backend web framework.

### Third-Party Services
- **Neon Database**: Serverless PostgreSQL hosting.
- **Notion API**: For content management integration.

### Development Tools
- **Vite**: Build tool and development server.
- **ESBuild**: Fast JavaScript bundler.
- **PostCSS**: CSS processing.
- **Zod**: Schema validation.

## Recent Updates (August 2025)

### Security Enhancements (✓ Complete)
- **JWT Security**: Implemented centralized JWT utility (`server/utils/jwt.js`) to prevent hardcoded secrets and enforce secure token management.
- **Environment Security**: Added `.env.example` template and production environment validation.
- **Authentication**: Updated all auth routes and middleware to use secure JWT utility.

### Performance & Stability Fixes (✓ Complete)
- **Memory Leak Prevention**: Fixed timeout cleanup in `App.tsx` to prevent memory accumulation.
- **Race Condition Fix**: Resolved interval management in `PlanComparisonSection.tsx` to prevent timing issues.
- **Error Handling**: Enhanced AdminPanel with comprehensive API error handling and user feedback.

### Code Quality Improvements (✓ Complete)
- **LSP Diagnostics**: Resolved all TypeScript errors and variable scoping issues.
- **Type Safety**: Improved type definitions and null safety checks.
- **Documentation**: Added comprehensive security documentation (`SECURITY.md`).

### Complete Social Media Management System (✓ Fully Operational)
- **8-Platform Support**: Instagram, Facebook, LinkedIn, Behance, Ko-fi, Pinterest, X (Twitter), and Website links
- **Database Schema**: `team_member_socials` table with proper column structure and relationships
- **RESTful API**: Complete CRUD endpoints (`/api/team-socials`) with validation and error handling
- **Bilingual Admin Interface**: Hungarian/English language support with intuitive form controls
- **Smart Display Logic**: Icons appear only for platforms with valid, saved links (conditional rendering)
- **Authentic Branding**: Official brand icons (SiBehance, FaPinterest, FaXTwitter) with accurate brand colors
- **User Experience**: 48px circular icons, 20px spacing, smooth hover effects, proper centering
- **Data Validation**: Enhanced filtering to prevent empty or invalid link display
- **Admin Panel Integration**: Seamless save/load functionality with real-time updates

### Development Environment (✓ Stable)
- **Environment Configuration**: Proper `.env` setup with secure defaults and production requirements
- **Error Boundaries**: Robust error handling across all frontend components
- **Database Migrations**: Clean schema updates with proper column additions
- **Testing**: Application running smoothly with comprehensive bug resolution