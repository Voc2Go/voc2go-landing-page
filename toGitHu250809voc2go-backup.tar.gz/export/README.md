# Voc2Go - AI-Powered Language Learning Platform

A comprehensive bilingual (English/Hungarian) language learning application landing page built with modern web technologies, featuring advanced content management, team social media integration, and robust administrative controls.

![Voc2Go Logo](./attached_assets/JoV2VLogo240815.png)

## 🌟 Key Features

### 🌐 Complete Social Media Management System
- **8 Platform Integration**: Instagram, Facebook, LinkedIn, Behance, Ko-fi, Pinterest, X (Twitter), Website links
- **Authentic Brand Icons**: Official platform icons with accurate brand colors
- **Smart Display Logic**: Icons only appear when links are saved
- **Admin Management**: Full CRUD operations through bilingual interface

### 🗣️ Bilingual Content Management
- **Dynamic Language Switching**: Real-time English/Hungarian toggle
- **Admin Panel**: Content management with Hungarian naming conventions
- **Live Preview**: Real-time content preview before publishing
- **Section-based Organization**: Manage content by page sections

### 🔐 Security & Authentication
- **JWT Authentication**: Secure token-based authentication system
- **Environment Security**: Production-ready security configurations
- **Input Validation**: Comprehensive data validation with Zod schemas

### 📱 Modern Tech Stack
- **Frontend**: React 18 + TypeScript + Tailwind CSS + Shadcn/UI
- **Backend**: Express.js + TypeScript + Drizzle ORM
- **Database**: PostgreSQL with Neon serverless hosting
- **Development**: Vite for fast builds and hot reload

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Environment variables configured

### Installation
```bash
# Install dependencies
npm install

# Configure environment variables
cp .env.example .env
# Edit .env with your database credentials and secrets

# Start development server
npm run dev
```

### Environment Variables
```env
DATABASE_URL="postgresql://user:password@host:port/database"
JWT_SECRET="your-secure-jwt-secret-key"
NODE_ENV="development"
PORT=5000
```

## 🏗️ Project Structure

```
├── client/                     # React frontend application
│   ├── src/
│   │   ├── components/         # React components
│   │   ├── context/           # React contexts (Language, etc.)
│   │   ├── pages/             # Route components
│   │   └── lib/               # Utilities and configurations
├── server/                     # Express.js backend
│   ├── routes/                # API route definitions
│   ├── utils/                 # Server utilities (JWT, etc.)
│   └── storage.ts             # Data access layer
├── shared/                     # Shared types and schemas
│   └── schema.ts              # Drizzle database schema
├── docs/                      # Comprehensive documentation
└── attached_assets/           # Project assets and images
```

## 🗃️ Database Schema

### Core Tables
- **content_sections**: Bilingual content management
- **team_member_socials**: Team social media links (8 platforms)
- **admin_users**: Administrative access control

## 📚 Documentation

- [**Features Documentation**](./FEATURES.md) - Complete feature overview
- [**Technical Architecture**](./TECHNICAL_ARCHITECTURE.md) - System architecture details
- [**API Documentation**](./API_DOCUMENTATION.md) - Complete API reference
- [**Development Guide**](./DEVELOPMENT.md) - Development workflow
- [**Content Management**](./SITE_CONTENT_DOCUMENTATION.md) - Content system guide
- [**Security Documentation**](./SECURITY.md) - Security implementation

## 🛠️ Available Scripts

```bash
npm run dev              # Start development server
npm run build           # Build for production
npm run db:push         # Push database schema changes
npm run db:studio       # Open database management interface
npm run type-check      # TypeScript compilation check
```

## 🌍 Supported Languages

- **English**: Full content support with professional messaging
- **Hungarian**: Complete localization with cultural adaptation

## 👥 Team Social Media Integration

The application supports comprehensive social media management for team members:

| Platform | Icon | Brand Color | Features |
|----------|------|-------------|----------|
| Instagram | 📷 | #E4405F | Photo/video sharing |
| Facebook | 📘 | #1877F2 | Social networking |
| LinkedIn | 💼 | #0A66C2 | Professional networking |
| Behance | 🎨 | #1769FF | Creative portfolio |
| Ko-fi | ❤️ | #FF5E5B | Creator support |
| Pinterest | 📌 | #E60023 | Visual discovery |
| X (Twitter) | 🐦 | #000000 | Microblogging |
| Website | 🔗 | #6366F1 | Personal websites |

## 🔧 Admin Panel Features

- **Hungarian Interface**: Intuitive admin panel with Hungarian naming
- **Content Management**: Live editing with preview functionality
- **Team Management**: Complete social media link management
- **Security**: JWT-based authentication with secure token handling

## 🎯 Campaign Integration

Built specifically to support an Indiegogo crowdfunding campaign with:
- Campaign progress tracking
- Backer benefit presentation
- Timeline and milestone display
- Call-to-action optimization

## 📊 Project Statistics

- **Development Time**: 3+ months intensive development
- **Total Components**: 50+ React components
- **API Endpoints**: 10+ RESTful endpoints
- **Documentation Pages**: 6 comprehensive guides
- **Database Tables**: 3 main tables with proper relationships
- **Supported Platforms**: 8 social media platforms

## 🚀 Deployment

### Replit (Current)
The application is optimized for Replit deployment with:
- Integrated development environment
- Automatic builds and deployments
- Environment variable management
- Database integration

### Other Platforms
The application can be deployed on:
- Vercel
- Netlify
- Railway
- Any Node.js hosting platform

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is part of the Voc2Go language learning platform campaign.

## 🎉 Achievements

- ✅ Complete 8-platform social media management system
- ✅ Bilingual content management with live preview
- ✅ Secure JWT authentication implementation
- ✅ Responsive design with modern UI components
- ✅ Comprehensive documentation suite
- ✅ Type-safe full-stack architecture
- ✅ Production-ready security measures

## 📞 Support

For support and questions, please refer to the comprehensive documentation or create an issue in this repository.

---

**Built with ❤️ for language learning enthusiasts worldwide**