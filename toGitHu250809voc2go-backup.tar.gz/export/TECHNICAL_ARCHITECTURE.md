# Voc2Go Technical Architecture Documentation

## System Overview
Voc2Go is built as a full-stack web application using modern TypeScript technologies with a focus on type safety, performance, and maintainability.

## Architecture Pattern
**Monolithic Full-Stack Application** with clear separation of concerns:
- Frontend: React SPA with TypeScript
- Backend: Express.js API server
- Database: PostgreSQL with Drizzle ORM
- Deployment: Replit with integrated development environment

## Frontend Architecture

### Core Technologies
- **React 18**: Component-based UI with functional components and hooks
- **TypeScript**: Full type safety and developer experience
- **Vite**: Fast build tool and development server
- **Tailwind CSS**: Utility-first styling with responsive design
- **Shadcn/UI**: High-quality component library

### State Management
- **Context API**: Global state for language switching and user preferences
- **TanStack Query**: Server state management with caching and synchronization
- **Local State**: React hooks for component-specific state

### Data Fetching Strategy
- **TanStack Query**: Efficient data fetching with:
  - Automatic caching and invalidation
  - Background refetching
  - Optimistic updates
  - Error handling and retries

### Component Structure
```
client/src/
├── components/          # Reusable UI components
│   ├── SocialMediaIcons.tsx        # Team social media display
│   ├── TeamSocialMediaManager.tsx  # Admin social media management
│   ├── AdminContentManager.tsx     # Content management interface
│   └── ProjectTeamSection.tsx      # Team member showcase
├── context/            # React context providers
├── hooks/              # Custom React hooks
├── pages/              # Route components
└── lib/                # Utility functions and configurations
```

### Routing
- **Wouter**: Lightweight routing library
- **Client-side routing**: Single-page application with dynamic route handling

## Backend Architecture

### Core Technologies
- **Express.js**: Web framework for Node.js
- **TypeScript**: Type-safe server-side development
- **Drizzle ORM**: Type-safe database toolkit
- **Zod**: Schema validation and type inference

### API Design
**RESTful API** with consistent patterns:
- `GET /api/content` - Retrieve application content
- `GET /api/team-socials/:memberId` - Get team member social links
- `PUT /api/team-socials/:memberId` - Update team member social links
- `POST /api/admin/login` - Admin authentication
- `GET /api/admin/me` - Admin user information

### Middleware Stack
1. **CORS**: Cross-origin resource sharing configuration
2. **JSON Parser**: Request body parsing
3. **JWT Authentication**: Secure route protection
4. **Error Handling**: Centralized error management
5. **Logging**: Request/response logging

### Security Implementation
```typescript
// JWT utility with environment-based secret management
const JWT_SECRET = process.env.JWT_SECRET || generateSecureDefault();

// Centralized token validation
export function verifyToken(token: string): AdminUser | null {
  // Implementation with proper error handling
}
```

## Database Architecture

### Technology Stack
- **PostgreSQL**: Primary relational database
- **Neon**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Type-safe database operations
- **Drizzle Kit**: Database migrations and introspection

### Schema Design
```sql
-- Core content management
CREATE TABLE content_sections (
  id SERIAL PRIMARY KEY,
  section_id VARCHAR(255) NOT NULL,
  content_en TEXT,
  content_hu TEXT,
  page_id VARCHAR(100),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Team social media links
CREATE TABLE team_member_socials (
  id SERIAL PRIMARY KEY,
  member_id VARCHAR(255) NOT NULL UNIQUE,
  instagram TEXT,
  facebook TEXT,
  linkedin TEXT,
  behance TEXT,
  kofi TEXT,
  pinterest TEXT,
  twitter TEXT,
  website TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Admin users
CREATE TABLE admin_users (
  id SERIAL PRIMARY KEY,
  login_name VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Data Access Layer
```typescript
// Storage interface for consistent data operations
interface IStorage {
  // Content operations
  getAllContent(): Promise<ContentSection[]>;
  updateContent(id: number, content: Partial<ContentSection>): Promise<ContentSection>;
  
  // Social media operations
  getTeamMemberSocials(memberId: string): Promise<TeamMemberSocials | undefined>;
  updateTeamMemberSocials(memberId: string, socials: Partial<TeamMemberSocials>): Promise<TeamMemberSocials>;
  
  // Admin operations
  validateAdminCredentials(username: string, password: string): Promise<AdminUser | undefined>;
}
```

## File Structure

```
project-root/
├── client/                     # Frontend application
│   ├── src/
│   │   ├── components/         # React components
│   │   ├── context/           # React context providers
│   │   ├── hooks/             # Custom hooks
│   │   ├── lib/               # Utilities and configurations
│   │   └── pages/             # Route components
│   └── package.json
├── server/                     # Backend application
│   ├── routes/                # API route handlers
│   ├── utils/                 # Server utilities
│   ├── storage.ts             # Data access layer
│   └── index.ts               # Server entry point
├── shared/                     # Shared types and schemas
│   └── schema.ts              # Drizzle schema definitions
├── prisma/                    # Database configurations
├── docs/                      # Project documentation
└── package.json               # Root dependencies
```

## Development Workflow

### Environment Setup
1. **Environment Variables**: Secure configuration management
2. **Database Connection**: Automatic connection validation
3. **Development Server**: Hot reload with Vite and nodemon
4. **Type Checking**: Continuous TypeScript validation

### Build Process
1. **Frontend Build**: Vite compiles React application
2. **Backend Compilation**: TypeScript compilation with tsx
3. **Asset Optimization**: Automatic code splitting and optimization
4. **Type Generation**: Drizzle generates database types

### Deployment Strategy
- **Replit Platform**: Integrated development and hosting
- **Automatic Deployments**: Git-based deployment pipeline
- **Environment Management**: Secure secret management
- **Database Migrations**: Automated schema updates

## Performance Optimizations

### Frontend
- **Code Splitting**: Automatic route-based splitting
- **Image Optimization**: Optimized asset loading
- **Bundle Analysis**: Webpack bundle optimization
- **Caching Strategy**: Browser and service worker caching

### Backend
- **Connection Pooling**: Database connection optimization
- **Response Caching**: Strategic API response caching
- **Compression**: Gzip compression for responses
- **Rate Limiting**: API protection against abuse

### Database
- **Index Strategy**: Optimized database indexes
- **Query Optimization**: Efficient database queries
- **Connection Management**: Proper connection lifecycle
- **Backup Strategy**: Automated database backups

## Security Considerations

### Authentication & Authorization
- **JWT Tokens**: Stateless authentication
- **Password Hashing**: bcrypt for secure password storage
- **Session Management**: Secure session handling
- **Role-based Access**: Admin-only route protection

### Data Protection
- **Input Validation**: Comprehensive input sanitization
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Content sanitization
- **CSRF Protection**: Cross-site request forgery prevention

### Infrastructure Security
- **Environment Variables**: Secure configuration management
- **HTTPS Enforcement**: Secure communication
- **CORS Configuration**: Proper cross-origin policies
- **Error Handling**: Secure error messages

## Monitoring & Maintenance

### Logging
- **Application Logs**: Comprehensive logging strategy
- **Error Tracking**: Centralized error management
- **Performance Monitoring**: Application performance tracking
- **Database Monitoring**: Query performance analysis

### Development Tools
- **TypeScript**: Compile-time error detection
- **ESLint**: Code quality enforcement
- **Prettier**: Consistent code formatting
- **Drizzle Studio**: Database management interface

This architecture provides a robust, scalable foundation for the Voc2Go application with clear separation of concerns, type safety, and modern development practices.