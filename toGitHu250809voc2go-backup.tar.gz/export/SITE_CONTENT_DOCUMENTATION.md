# Voc2Go Site Content Documentation

## Content Management System

The Voc2Go application features a comprehensive bilingual content management system that allows administrators to manage all site content dynamically through a user-friendly interface.

## Content Structure

### Bilingual Architecture
All content in the application supports both English and Hungarian languages:
- **English Content**: `contentEn` field in database
- **Hungarian Content**: `contentHu` field in database
- **Dynamic Language Switching**: Users can toggle between languages instantly
- **Admin Interface**: Content can be edited in both languages simultaneously

### Content Organization
Content is organized hierarchically by:
1. **Page ID**: Groups content by application pages (e.g., "home", "team", "admin")
2. **Section ID**: Specific content sections within pages (e.g., "hero-title", "about-content")
3. **Content ID**: Unique identifier for each content piece

## Core Site Sections

### 1. Hero Section
**Purpose**: Main landing area with primary messaging
**Content Elements**:
- Hero title and subtitle
- Call-to-action buttons
- Background imagery
- Value proposition messaging

### 2. About Section
**Purpose**: Detailed information about Voc2Go platform
**Content Elements**:
- Platform overview
- Key features and benefits
- Learning methodology explanation
- Technology highlights

### 3. Team Section
**Purpose**: Team member profiles with social media integration
**Content Elements**:
- Individual team member bios
- Professional backgrounds
- Social media links (8 platforms)
- Team member photos

**Social Media Platforms Supported**:
- Instagram
- Facebook 
- LinkedIn
- Behance
- Ko-fi
- Pinterest
- X (Twitter)
- Website links

### 4. Features Section
**Purpose**: Detailed feature breakdown
**Content Elements**:
- AI-powered learning features
- Personalization capabilities
- Interactive story-based learning
- Progress tracking features

### 5. Pricing Section
**Purpose**: Subscription plans and pricing information
**Content Elements**:
- Plan comparison tables
- Feature breakdowns by tier
- Pricing information
- Call-to-action buttons

### 6. Campaign Section
**Purpose**: Crowdfunding campaign promotion
**Content Elements**:
- Campaign goals and objectives
- Funding progress
- Backer benefits
- Timeline and milestones

### 7. FAQ Section
**Purpose**: Common questions and answers
**Content Elements**:
- Learning-related questions
- Technical support queries
- Billing and subscription information
- Platform capabilities

### 8. Newsletter Section
**Purpose**: Email collection and communication
**Content Elements**:
- Newsletter signup forms
- Subscription benefits
- Content preview
- Privacy information

## Content Types

### 1. Static Text Content
Standard text content that appears throughout the site:
```json
{
  "sectionId": "hero-title",
  "contentEn": "Revolutionize Your English Learning",
  "contentHu": "Forradalmasítsd az Angol Tanulásod",
  "pageId": "home"
}
```

### 2. Rich HTML Content
Content that includes HTML formatting and styling:
```json
{
  "sectionId": "about-description",
  "contentEn": "<p>Voc2Go leverages <strong>artificial intelligence</strong> to create personalized learning experiences...</p>",
  "contentHu": "<p>A Voc2Go <strong>mesterséges intelligenciát</strong> használ személyre szabott tanulási élmények létrehozására...</p>",
  "pageId": "about"
}
```

### 3. Configuration Content
JSON-formatted content for complex data structures:
```json
{
  "sectionId": "pricing-plans",
  "contentEn": "[{\"name\":\"Basic\",\"price\":\"$9.99\",\"features\":[\"Core Learning\",\"Progress Tracking\"]}]",
  "contentHu": "[{\"name\":\"Alapcsomag\",\"price\":\"$9.99\",\"features\":[\"Alapvető Tanulás\",\"Haladás Követése\"]}]",
  "pageId": "pricing"
}
```

## Content Management Features

### 1. Live Preview
- Real-time preview of content changes
- Side-by-side comparison of English and Hungarian versions
- Immediate visual feedback before publishing

### 2. Section-Based Editing
- Content organized by page sections
- Easy navigation between different content areas
- Bulk editing capabilities

### 3. Version Control
- Automatic timestamps for all content changes
- Change tracking and history
- Rollback capabilities for content restoration

### 4. Search and Filter
- Search content by section ID or content text
- Filter by page ID
- Language-specific search capabilities

## Admin Interface

### Navigation Structure
```
Admin Dashboard
├── Tartalom Kezelés (Content Management)
│   ├── Oldal Szűrés (Page Filter)
│   ├── Szekció Szűrés (Section Filter)
│   └── Élő Előnézet (Live Preview)
├── Csapat Kezelés (Team Management)
│   ├── Tagok Listája (Member List)
│   └── Közösségi Média (Social Media)
└── Beállítások (Settings)
    ├── Nyelv Váltás (Language Switch)
    └── Felhasználói Fiók (User Account)
```

### Hungarian Language Interface
The admin interface uses Hungarian naming conventions for intuitive use:
- **Tartalom**: Content
- **Szerkesztés**: Editing
- **Mentés**: Save
- **Előnézet**: Preview
- **Szűrés**: Filter
- **Keresés**: Search

## SEO and Marketing Content

### Meta Tags and Descriptions
- Unique page titles and descriptions
- Open Graph tags for social sharing
- Twitter Card metadata
- JSON-LD structured data

### Marketing Copy
- Campaign-focused messaging
- Call-to-action optimization
- Conversion-oriented content
- Social proof and testimonials

## Content Guidelines

### Writing Style
- **English**: Professional, engaging, benefit-focused
- **Hungarian**: Formal yet accessible, culturally appropriate
- **Consistency**: Maintain brand voice across both languages
- **Clarity**: Clear, concise messaging avoiding technical jargon

### Technical Considerations
- **HTML Validation**: Ensure proper HTML structure
- **Character Encoding**: UTF-8 support for Hungarian characters
- **Length Limits**: Consider responsive design constraints
- **Performance**: Optimize content length for fast loading

### Accessibility
- **Alt Text**: Descriptive alternative text for images
- **Heading Structure**: Proper H1-H6 hierarchy
- **Link Text**: Descriptive link text for screen readers
- **Color Contrast**: Sufficient contrast for readability

## Future Enhancements

### Planned Features
- **Media Library**: Integrated image and video management
- **Content Scheduling**: Timed content publication
- **A/B Testing**: Content variation testing
- **Analytics Integration**: Content performance tracking
- **Workflow Management**: Content approval processes

### Integration Possibilities
- **CMS Integration**: Headless CMS for content management
- **Translation Services**: Automated translation assistance
- **Content Optimization**: AI-powered content suggestions
- **Social Media Integration**: Direct social media publishing

This documentation provides comprehensive guidance for managing content within the Voc2Go application, ensuring consistent, high-quality content across both English and Hungarian versions of the site.