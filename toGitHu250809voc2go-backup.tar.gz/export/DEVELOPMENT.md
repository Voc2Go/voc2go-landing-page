# Voc2Go Development Guide

## Quick Start

### Prerequisites
- Node.js 18+ with npm
- PostgreSQL database (Neon serverless recommended)
- Replit account (for deployment)

### Installation & Setup
```bash
# Clone and install dependencies
npm install

# Configure environment variables
cp .env.example .env
# Edit .env with your database credentials and secrets
```

### Environment Configuration
```env
# Database
DATABASE_URL="postgresql://user:password@host:port/database"

# Authentication
JWT_SECRET="your-secure-jwt-secret-key"

# Application
NODE_ENV="development"
PORT=5000

# Optional: External service keys
OPENAI_API_KEY="your-openai-key"
```

### Starting Development Server
```bash
# Runs both frontend and backend concurrently
npm run dev

# Individual services
npm run dev:client    # Frontend only (Vite dev server)
npm run dev:server    # Backend only (Express with tsx)
```

Access the application at `http://localhost:5000`

## Project Structure

```
├── client/                 # React frontend application
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── context/        # React contexts (Language, etc.)
│   │   ├── pages/          # Page components
│   │   └── lib/           # Utilities and configurations
├── server/                 # Express.js backend
│   ├── routes/            # API route definitions
│   ├── middleware/        # Authentication and other middleware
│   ├── utils/             # Utilities (JWT, etc.)
│   └── index.ts           # Server entry point
├── shared/                # Shared types and schemas
├── prisma/                # Database schema and migrations
└── docs/                  # Documentation
```

## Key Development Patterns

### 1. Component Development
- Use TypeScript for all components
- Implement proper error boundaries
- Clean up effects and timers properly
- Follow the established naming conventions

```typescript
// Good - Proper cleanup
useEffect(() => {
  let interval: NodeJS.Timeout | null = null;
  
  if (condition) {
    interval = setInterval(() => {
      // logic
    }, 1000);
  }
  
  return () => {
    if (interval) {
      clearInterval(interval);
    }
  };
}, [dependency]);
```

### 2. API Development
- Use the secure JWT utility for authentication
- Implement proper error handling
- Validate inputs with Zod schemas

```javascript
// Good - Secure authentication
import { createToken, verifyToken } from '../utils/jwt.js';

const token = createToken({ id: user.id, email: user.email });
```

### 3. Database Operations
- Use Drizzle ORM for all database interactions
- Keep shared schema in `shared/schema.ts`
- Use `npm run db:push` for schema changes

## Common Issues & Solutions

### Memory Leaks
- Always clean up intervals, timeouts, and event listeners
- Use proper dependency arrays in useEffect
- Check for race conditions in async operations

### Authentication Issues
- Ensure JWT_SECRET is properly set
- Use the centralized JWT utility
- Check token expiration and refresh logic

### Database Errors
- Verify DATABASE_URL is correct
- Check schema consistency between frontend and backend
- Use the execute SQL tool for debugging

## Testing Guidelines

### Before Making Changes
1. Check current functionality works
2. Run LSP diagnostics to catch type errors
3. Test authentication flows
4. Verify responsive design

### After Making Changes
1. Check for LSP errors and fix them
2. Test affected functionality
3. Verify no memory leaks introduced
4. Update documentation if needed

## Debugging Tools

### Available Tools
- LSP diagnostics for code quality
- Browser console for frontend errors
- Server logs for backend issues
- Database query tool for data debugging

### Common Debug Commands
```bash
# Check for TypeScript errors
npm run type-check

# Database operations
npm run db:push        # Push schema changes
npm run db:generate    # Generate migrations
```

## Security Best Practices

### JWT Token Management
- Never hardcode JWT secrets
- Use environment variables in production
- Set appropriate token expiration times
- Implement proper token refresh logic

### Environment Variables
- Keep secrets in .env (not committed)
- Use .env.example as template
- Validate required variables on startup

### Code Quality
- Fix all LSP diagnostics before deployment
- Use TypeScript strict mode
- Implement proper error boundaries

## Performance Guidelines

### Frontend Performance
- Use React.memo for expensive components
- Implement proper loading states
- Optimize images and assets
- Clean up resources in useEffect

### Backend Performance
- Use database indexes appropriately
- Implement proper caching strategies
- Monitor memory usage
- Handle errors gracefully

## Deployment Checklist

- [ ] All environment variables configured
- [ ] JWT_SECRET set to secure value
- [ ] Database schema is up to date
- [ ] No LSP errors or warnings
- [ ] Authentication flows tested
- [ ] Memory leaks checked and fixed
- [ ] Error handling implemented
- [ ] Documentation updated

## Maintenance Tasks

### Regular Maintenance
- Update dependencies monthly
- Review and fix security vulnerabilities
- Monitor performance metrics
- Update documentation as needed

### When Adding Features
- Update shared schema if needed
- Add proper TypeScript types
- Implement error handling
- Update tests and documentation
- Check for performance impact

## Troubleshooting

### App Won't Start
1. Check environment variables
2. Verify database connection
3. Check for port conflicts
4. Review server logs

### Authentication Issues
1. Verify JWT_SECRET is set
2. Check token expiration
3. Test token creation/verification
4. Review middleware logic

### Database Issues
1. Check DATABASE_URL
2. Verify schema consistency
3. Test database connection
4. Review migration status

### Frontend Issues
1. Check console for errors
2. Verify API endpoints
3. Test responsive design
4. Check memory usage